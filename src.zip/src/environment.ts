export const firebaseConfig = {
  apiKey: "AIzaSyAD3ZsvI-JyJsFymfLFkcMW3yd_2ESRXcQ",
  //authDomain: "domain.firebaseapp.com",
  databaseURL: "https://ribblu-146510.firebaseio.com",
  projectId: "ribblu-146510",
  //storageBucket: "dmaoin.appspot.com",
  messagingSenderId: "911104597391"
};