import { Component, ViewChild, Pipe } from '@angular/core';
import { Nav, Platform, AlertController, ToastController} from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { SigninPage } from "../pages/signin/signin";
import { PopoverController } from 'ionic-angular/components/popover/popover-controller';

// PARENT 
import { LocalNotifications } from '@ionic-native/local-notifications';
import { FirebaseListObservable } from 'angularfire2/database';
import { FirebaseProvider } from '../providers/parent/firebase/firebase';
import { AuthServiceProvider } from '../providers/parent/auth-service/auth-service';
import { BackgroundMode } from '@ionic-native/background-mode';
import { Alert } from 'ionic-angular/umd/components/alert/alert';

import { FCM , NotificationData} from '@ionic-native/fcm';
import { setInterval, setTimeout } from 'timers';

import { FeePage } from './../pages/parent/fee/fee';
import { AttendanceviewPage } from './../pages/parent/attendanceview/attendanceview';
import { NoticeBoardPage } from './../pages/parent/notice-board/notice-board';
import { UserPage } from './../pages/parent/user/user';
import { AdminTeacherMessagePage } from '../pages/admin-teacher-message/admin-teacher-message';



@Pipe({
  name: 'dateFormatPipe',
})

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
    confirmAlert: any;
  @ViewChild(Nav) nav: Nav;

  text1: string;
  showedAlert: boolean;
  rootPage: any = SigninPage;

  response1: FirebaseListObservable<any[]>;
  response2: any;
  response3: any;

  pages: Array<{title: string, component: any}>;

  constructor(
              public platform: Platform, 
              public statusBar: StatusBar, 
              public splashScreen: SplashScreen, 
              public alertCtrl: AlertController, 
              public toastCtrl: ToastController, 
              public popoverCtrl: PopoverController,
              public localNotifications: LocalNotifications,
              public afd: FirebaseProvider,
              public authservice: AuthServiceProvider,
              public backgroundMode: BackgroundMode,
              public fcm: FCM,  
            ) 
    {
        // document.addEventListener('deviceready', () => {
        //     this.backgroundMode.enable();
        // }, false);

        this.platform.ready().then(() => {
            this.statusBar.styleDefault();
            this.splashScreen.hide();
            /*this.NoticeBoardPushNotification();
            this.BusAttendancePushNotification();
            this.FeePushNotification();
            this.AttendancePushNotification();*/
            this.initFCM(); 
        });
        this.initializeApp();
    }

    initFCM()
    {
        this.fcm.onNotification().subscribe((data:NotificationData)=>{
            
        }, (error)=> {
            console.error(error);
        });

    
      this.fcm.onNotification().subscribe((data:NotificationData)=>{
          if(data.wasTapped){

            if(data['noti_identity'] == 'class_attendance'){
                var ucName = data['studentname'].toLowerCase();
                var CapitalizeName = ucName.substring(0,1).toUpperCase()+ucName.substring(1);
                this.nav.push(AttendanceviewPage , {studentname:CapitalizeName, studentid: data['studentid'] });
            }else if(data['noti_identity'] == 'bus_attendance'){
                // this.navCtrl.push(UserPage , {schoolid: schoolid, studentid: studentid, classid: classid, sectionid: sectionid, studentname: studentname, busarea:busarea,busstop:busstop,busincharge:busincharge,schoolname:schoolname });
            }else if(data['noti_identity'] == 'fee'){
                var ucName = data['studentname'].toLowerCase();
                var CapitalizeName = ucName.substring(0,1).toUpperCase()+ucName.substring(1);
                this.nav.push(FeePage , {studentname:CapitalizeName, schoolid: data['schoolid'], studentid: data['studentid'], classid: data['classid'], sectionid: data['sectionid'] });
            }else if(data['noti_identity'] == 'notice'){
                var ucName = data['studentname'].toLowerCase();
                var CapitalizeName = ucName.substring(0,1).toUpperCase()+ucName.substring(1);
                this.nav.push(NoticeBoardPage , {studentname:CapitalizeName,schoolid: data['schoolid'], classid:data['classid'], sectionid:data['sectionid'] });
            }else if(data['noti_identity'] == 'bus_location'){
                // this.nav.push(NoticeBoardPage , {studentname:CapitalizeName,schoolid: data['schoolid'], classid:data['classid'], sectionid:data['sectionid'] });
            }else if(data['noti_identity'] == 'teacher_message'){
                this.nav.push(AdminTeacherMessagePage);
            }else{

            }
            // console.log("Received in background",JSON.stringify(data));
          }else{
            this.localNotifications.schedule({
                id: data['studentid'],
                title: data['title'],
                text: data['body'],
                icon: 'assets/images/icon.png'           
            });
          }
        });
    }

    initializeApp() 
    {
        this.showedAlert = false;
        this.platform.registerBackButtonAction(() => {
            if (this.nav.length() == 1) {
                if (!this.showedAlert) {
                    this.showedAlert = true;
                    this.confirmExitApp();
                } else {
                    this.showedAlert = false;
                    this.confirmAlert.dismiss();
                }
            }else{
                this.nav.pop();
            }
        });
    }
    
    confirmExitApp() 
    {
        this.confirmAlert = this.alertCtrl.create({
            // title: "Quite !",
            message: "Are you sure ? you want to exit.",
            buttons: [
                {
                    text: 'No',
                    handler: () => {
                        this.showedAlert = false;
                        return;
                    }
                },
                {
                    text: 'Yes',
                    handler: () => {
                        this.platform.exitApp();
                    }
                }
            ]
        });
        this.confirmAlert.present();
    }









    /*
    AttendancePushNotification() 
    {
        this.text1 = '';
        this.authservice.postData({'useremail':localStorage.getItem('useremail')}, 'getAllParentChild').then((result)=>{
            if(result['responseData']){
                result['responseData'].forEach(element => {
                this.response1 = this.afd.getStudentAttendance(element.schoolId,element.sid);
                    this.response1.subscribe(res=>{
                        if(res.length != 0){
                            var a = res[0].student.toString().length-8;
                            var studentids = res[0].student.toString().substring(0,a);
                            this.authservice.postData({'studentid':studentids, 'schoolid':element.schoolId}, 'getStudentAndSchoolName').then((result)=>{
                                if(result['response'] == 1){
                                // only getting Capitalize name
                                    var ucName = result['name']['studentname'].toLowerCase();
                                    var studentname1 = ucName.substring(0,1).toUpperCase()+ucName.substring(1);
                                //
                                }
                                if(res[0].status == 'l'){
                                    this.text1 = studentname1+' is on leave today.';
                                }else if(res[0].status == 'p'){
                                    this.text1 = studentname1+' is present today.';
                                }else{
                                    this.text1 = studentname1+' is absent today.';
                                }

                                this.localNotifications.schedule({
                                    id: res[0].$key,
                                    title: 'Attendance Notification !',
                                    text:this.text1,
                                    data:{ name:studentname1 , id:studentids, remark:'attendance' },
                                    icon: 'assets/images/toplogo_parent.png'           
                                });

                                this.afd.deleteStudentAttendance(element.schoolId,studentids);  
                                                                                                
                                // this.localNotifications.on('trigger',()=>{
                                    // this.localNotifications.update({
                                    //     id: res[0].$key,
                                    //    every: 'day',
                                    // });
                                // });

                            });
                        }else{
                            console.log('Attendance not updated yet.');
                        }
                    });
                });
            }
        });
    }

    NoticeBoardPushNotification() 
    {
        this.authservice.postData({'useremail':localStorage.getItem('useremail')}, 'getAllParentChild').then((result)=>{
            if(result['responseData']){
                result['responseData'].forEach(element => {
                    this.response2 = this.afd.GetNoticeBoardPushNotification(element.schoolId,element.sid);
                    this.response2.subscribe(res=>{
                        if(res.length != 0){
                            this.localNotifications.schedule({
                                id: element.schoolId,
                                title: 'School Notice !',
                                text: res[0].notice,
                                data:{ remark:'notice', schoolid:localStorage.getItem('schoolid') },
                                //   every: "minute",
                                icon: 'assets/images/toplogo_parent.png'
                            });
                            this.afd.DeleteNoticeBoardPushNotification(element.schoolId,element.sid); 
                        }else{
                            console.log('Notice not updated yet.');
                        }
                    });
                });
            }
        });
    }

    BusAttendancePushNotification() 
    {
        this.authservice.postData({'useremail':localStorage.getItem('useremail')}, 'getAllParentChild').then((result)=>{
            if(result['responseData']){
                result['responseData'].forEach(element => {
                    var ucName = element.studentname.toLowerCase();
                    var studentname2 = ucName.substring(0,1).toUpperCase()+ucName.substring(1);
                    this.response3 = this.afd.GetBusAttendancePushNotification(element.schoolId,element.sid);
                    this.response3.subscribe(res=>{
                        if(res.length != 0){
                            document.addEventListener('deviceready', ()=> {
                                this.localNotifications.schedule({
                                    id: element.sid,
                                    title: 'Bus Attendance !',
                                    text: studentname2+' is present today.',
                                    led: '37FF00',
                                    data:{ remark:'busattendance', schoolid:localStorage.getItem('schoolid') },
                                    //   every: "minute",
                                    icon: 'assets/images/toplogo_parent.png'
                                });
                                this.afd.DeleteBusAttendancePushNotification(element.schoolId,element.sid); 
                            },false);
                        }else{
                            console.log('Bus attendance not updated yet.');
                        }
                    });
                });
            }
        });
    }

    FeePushNotification() 
    {
        this.authservice.postData({'useremail':localStorage.getItem('useremail')}, 'getAllParentChild').then((result)=>{
            if(result['responseData']){
                result['responseData'].forEach(element => {
                    //   var ucName = element.studentname.toLowerCase();
                    //   var studentname3 = ucName.substring(0,1).toUpperCase()+ucName.substring(1);
                    this.response3 = this.afd.GetFeePushNotification(element.schoolId,element.sid);
                    this.response3.subscribe(res=>{
                        if(res.length != 0){
                            document.addEventListener('deviceready', ()=> {
                                this.localNotifications.schedule({
                                    id: element.sid,
                                    title: ' School Fee Alert !',
                                    text: res[0].title+' of amount Rs '+res[0].amount+' is due for '+res[0].lastdate,
                                    led: '37FF00',
                                    data:{ remark:'fee', schoolid:localStorage.getItem('schoolid') },
                                    //   every: "minute",
                                    icon: 'assets/images/toplogo_parent.png'
                                });
                                this.afd.DeleteFeePushNotification(element.schoolId,element.sid); 
                            },false);
                        }else{
                            console.log('Bus attendance not updated yet.');
                        }
                    });
                });
            }
        });
    }
    */

  
}
