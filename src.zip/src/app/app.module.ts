// parent plugin
import { SchoolTempRegisConfirmationPage } from '../pages/school-temp-regis-confirmation/school-temp-regis-confirmation';
import { AreaListPage } from '../pages/area-list/area-list';
import { ClaimschoolPage } from '../pages/claimschool/claimschool';
import { SchoolslistPage } from '../pages/schoolslist/schoolslist';
import { ForgotpasswordPage } from '../pages/forgotpassword/forgotpassword';
import { SchoolteachersPage } from '../pages/schoolteachers/schoolteachers';
import { SchoolbusesPage } from '../pages/schoolbuses/schoolbuses';
import { AuthServiceProvider as p_AuthServiceProvider} from '../providers/parent/auth-service/auth-service';
import { Network } from '@ionic-native/network';
import { Subscription } from 'rxjs/Subscription';
import { LocalNotifications } from '@ionic-native/local-notifications';
import { BackgroundMode } from '@ionic-native/background-mode';
import { Geolocation } from '@ionic-native/geolocation';
import { Facebook, FacebookLoginResponse } from '@ionic-native/facebook';

// parent pages
import { HomePage as p_HomePage } from './../pages/parent/home/home';
import { LoginPage } from './../pages/parent/login/login';
import { SignupPage } from './../pages/parent/signup/signup';
import { UserPage } from './../pages/parent/user/user';
import { FeePage, paymentWifergation } from './../pages/parent/fee/fee';
import { QueryPage as p_QueryPage} from './../pages/parent/query/query';
import { QueryformPage } from './../pages/parent/queryform/queryform';
import { QuerydetailPage as p_QuerydetailPage } from './../pages/parent/querydetail/querydetail';
import { QueryreplyPage as p_QueryreplyPage} from './../pages/parent/queryreply/queryreply';
import { PasswordPage as p_PasswordPage} from './../pages/parent/password/password';
import { MyprofilePage, EditprofilePage } from './../pages/parent/myprofile/myprofile';
import { AttendanceviewPage as p_AttendanceviewPage} from './../pages/parent/attendanceview/attendanceview';
import { StudentPage } from './../pages/parent/student/student';
import { StudentfeePage } from './../pages/parent/studentfee/studentfee';
import { BusroutePage } from './../pages/parent/busroute/busroute';
import { PayfeePage } from './../pages/parent/payfee/payfee';
import { ExamTermPage } from './../pages/parent/exam-term/exam-term';
import { ReportCardPage } from './../pages/parent/report-card/report-card';
import { NoticeBoardPage as p_NoticeBoardPage} from './../pages/parent/notice-board/notice-board';
import { EmailConfigurationPage } from './../pages/parent/email-configuration/email-configuration';
import { PaymentResponsePage } from './../pages/parent/payment-response/payment-response';
import { PopoverPage as p_PopoverPage} from './../pages/parent/popover/popover';
import { TrackingPage as tracking_test } from './../pages/parent/tracking/tracking';
import { PHandBookPage } from '../pages/parent/p-hand-book/p-hand-book';

/* --------------- PLEASE ADD PAGES AND PLUGIN OF SCHOOLDESK HERE --------------- */

import { PasswordPage } from './../pages/password/password';
import { PopoverPage } from './../pages/popover/popover';
import { ImagePicker } from '@ionic-native/image-picker';
import { GalleryPage } from './../pages/gallery/gallery';
import { AdmissionenquirydetailPage, Addadmissionenquiryreply } from './../pages/admissionenquirydetail/admissionenquirydetail';
import { AdmissionenquiriesPage } from './../pages/admissionenquiries/admissionenquiries';
import { ReplydetailPage, Addreviewreply } from './../pages/replydetail/replydetail';
import { AdmissionalertsPage, Addadmissionalert } from './../pages/admissionalerts/admissionalerts';
import { DatePipe } from '@angular/common';
import { SchoolcalendarPage } from './../pages/schoolcalendar/schoolcalendar';
import { NoticeFormPage } from './../pages/notice-form/notice-form';
import { SkooldeskbookingPage } from './../pages/skooldeskbooking/skooldeskbooking';
import { ExamSchedulePage } from './../pages/exam-schedule/exam-schedule';
import { ExamresultPage } from './../pages/exam-results/exam-results';
import { FileChooser } from '@ionic-native/file-chooser';
import { FileTransfer } from '@ionic-native/file-transfer';
import { FeestructurePage } from './../pages/feestructure/feestructure';
import { ReviewsPage } from './../pages/reviews/reviews';
import { LatestNewsPage, Addnews } from './../pages/latest-news/latest-news';
import { CurriculumPage, Addcurriculum } from './../pages/curriculum/curriculum';
import { SchooladditionalinformationPage } from './../pages/schooladditionalinformation/schooladditionalinformation';
import { SchoolbasicinformationPage } from './../pages/schoolbasicinformation/schoolbasicinformation';
import { SchoolinformationPage } from './../pages/schoolinformation/schoolinformation';
import { InfrastructurePage, AddMoreInfrastructure, InfrastructureInformation } from './../pages/infrastructure/infrastructure';
import { SchoolpanelPage } from './../pages/schoolpanel/schoolpanel';
import { FacilitiesPage, AddFacilities } from './../pages/facilities/facilities';
import { StudentMarksPage } from './../pages/student-marks/student-marks';
import { MysubjectsPage } from './../pages/mysubjects/mysubjects';
import { TeacherClassSectionPage } from './../pages/teacher-class-section/teacher-class-section';
import { TrackingPage } from './../pages/tracking/tracking';
import { AttendanceviewPage } from './../pages/attendanceview/attendanceview';
import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicApp, IonicErrorHandler, IonicModule , ToastController, AlertController, Platform} from 'ionic-angular';
import { HttpModule } from '@angular/http';
import { InAppBrowser } from '@ionic-native/in-app-browser';
// import { Push } from '@ionic-native/push';
import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { ListPage } from '../pages/list/list';
import { SigninPage } from '../pages/signin/signin';
import { AttendancePage } from '../pages/attendance/attendance';
import { BusattendancePage } from '../pages/busattendance/busattendance';
import { MyclassPage } from '../pages/myclass/myclass';
import { MydiaryPage } from '../pages/mydiary/mydiary';
import { QuerydetailPage } from '../pages/querydetail/querydetail';
import { QueryreplyPage } from '../pages/queryreply/queryreply';
import { FeeshomePage } from '../pages/feeshome/feeshome';
import { GeneralizefeesPage } from '../pages/generalizefees/generalizefees';
import { ClassfeesPage } from '../pages/classfees/classfees';
import { QueryPage } from "../pages/query/query";
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { AuthServiceProvider } from '../providers/auth-service/auth-service';
import { TimeAgoPipe } from 'time-ago-pipe';
import { NgCalendarModule  } from "ionic2-calendar";
import { BackgroundGeolocation } from '@ionic-native/background-geolocation';
import { FilePath } from '@ionic-native/file-path';
import { Transfer } from '@ionic-native/transfer';
import { File } from '@ionic-native/file';
import { FileOpener } from '@ionic-native/file-opener';
import { Camera } from '@ionic-native/camera';
import { Crop } from '@ionic-native/crop';
import { SocialSharing } from '@ionic-native/social-sharing';
import { NoticeBoardPage } from '../pages/notice-board/notice-board';
import { SchoolcontactsPage } from '../pages/schoolcontacts/schoolcontacts';
import { SchoolcontactsdetailPage, Addcontactquiryreply } from '../pages/schoolcontactsdetail/schoolcontactsdetail';
import { IonicImageViewerModule } from 'ionic-img-viewer';
import { SpaccountverificationPage } from '../pages/spaccountverification/spaccountverification';

// import { FirebaseListObservable,AngularFireDatabase } from 'angularfire2/database';
import { AngularFireModule } from 'angularfire2';
import { firebaseConfig } from '../environment';
import { AngularFireDatabaseModule } from 'angularfire2/database';
import { AngularFireAuthModule } from 'angularfire2/auth';

import { FirebaseProvider } from '../providers/parent/firebase/firebase';
import { FirebasedbProvider } from '../providers/firebasedb/firebasedb';

import { PCurriculumPage } from './../pages/parent/p-curriculum/p-curriculum';
import { PLatestNewsPage } from '../pages/parent/p-latest-news/p-latest-news';
import { PCalendarPage } from '../pages/parent/p-calendar/p-calendar';
import { PFeeStructurePage } from '../pages/parent/p-fee-structure/p-fee-structure';
import { PExamResultPage } from '../pages/parent/p-exam-result/p-exam-result';
import { PExamSchedulePage } from '../pages/parent/p-exam-schedule/p-exam-schedule';
import { SchoolRegistrationPage } from '../pages/school-registration/school-registration';
import { SchoolsignupPage } from '../pages/schoolsignup/schoolsignup';
import { SchoolclaimconfirmationPage } from '../pages/schoolclaimconfirmation/schoolclaimconfirmation';

import * as ionicGalleryModal from 'ionic-gallery-modal';
import { HAMMER_GESTURE_CONFIG } from '@angular/platform-browser';

import { LazyLoadImageModule } from 'ng-lazyload-image';
import { MyschooltimetablePage } from '../pages/myschooltimetable/myschooltimetable';
import { NoticeBoardTeacherPage } from '../pages/notice-board-teacher/notice-board-teacher';

import { FCM } from '@ionic-native/fcm';

import { HandBookTeacherPage } from './../pages/hand-book-teacher/hand-book-teacher';
import { HandBookFormPage } from './../pages/hand-book-form/hand-book-form';
import { AdminTeacherMessagePage,messageFormModal } from '../pages/admin-teacher-message/admin-teacher-message';
  
/*export const firebaseConfig = {
  apiKey: "AIzaSyAD3ZsvI-JyJsFymfLFkcMW3yd_2ESRXcQ",
  //authDomain: "domain.firebaseapp.com",
  databaseURL: "https://ribblu-146510.firebaseio.com",
  projectId: "ribblu-146510",
  //storageBucket: "dmaoin.appspot.com",
  messagingSenderId: "911104597391"
};*/

@NgModule({
  declarations: [
    ForgotpasswordPage,
    TimeAgoPipe,
    MyApp,
    HomePage,
    ListPage,
    SigninPage,
    AttendancePage,
    BusattendancePage,
    MyclassPage,
    MydiaryPage,
    QuerydetailPage,
    QueryreplyPage,
    FeeshomePage,
    GeneralizefeesPage,
    ClassfeesPage,
    QueryPage,
    AttendanceviewPage,
    TrackingPage,
    TeacherClassSectionPage,
    MysubjectsPage,
    StudentMarksPage,
    FacilitiesPage,
    SchoolpanelPage,
    AddFacilities,
    InfrastructurePage,
    AddMoreInfrastructure,
    InfrastructureInformation,
    SchoolinformationPage,
    SchoolbasicinformationPage,
    SchooladditionalinformationPage,
    CurriculumPage,
    LatestNewsPage,
    ReviewsPage,
    FeestructurePage,
    ExamresultPage,
    ExamSchedulePage,
    Addnews,
    Addcurriculum,
    SkooldeskbookingPage,
    NoticeBoardPage,
    NoticeFormPage,
    SchoolcalendarPage,
    AdmissionalertsPage,
    Addadmissionalert,
    ReplydetailPage,
    Addreviewreply,
    AdmissionenquiriesPage,
    AdmissionenquirydetailPage,
    Addadmissionenquiryreply,
    SchoolcontactsPage,
    SchoolcontactsdetailPage,
    Addcontactquiryreply,
    GalleryPage,
    PopoverPage,
    PasswordPage,
    p_HomePage,p_QueryPage,p_QuerydetailPage,p_PopoverPage,p_NoticeBoardPage,p_AttendanceviewPage,p_PasswordPage,p_QueryreplyPage,
    StudentPage,QueryformPage,FeePage,paymentWifergation,UserPage,SignupPage,MyprofilePage,EditprofilePage,StudentfeePage,BusroutePage,PayfeePage,ExamTermPage,ReportCardPage,EmailConfigurationPage,LoginPage,PaymentResponsePage,
    SchoolbusesPage,
    SchoolteachersPage,
    SpaccountverificationPage,  
    FirebaseProvider,
    FirebasedbProvider,
    PLatestNewsPage,
    PCurriculumPage,PCalendarPage,PFeeStructurePage,PExamSchedulePage,PExamResultPage,
    SchoolslistPage,ClaimschoolPage,SchoolRegistrationPage,AreaListPage,SchoolsignupPage,SchoolclaimconfirmationPage,
    SchoolTempRegisConfirmationPage,
    MyschooltimetablePage,
    NoticeBoardTeacherPage,
    tracking_test,
    HandBookTeacherPage,HandBookFormPage,
    AdminTeacherMessagePage,messageFormModal,
    PHandBookPage,
  ],
  imports: [
    BrowserModule,HttpModule,FormsModule,NgCalendarModule,
    IonicModule.forRoot(MyApp),
    AngularFireModule.initializeApp(firebaseConfig),
    AngularFireDatabaseModule,
    AngularFireAuthModule,
    IonicImageViewerModule,
    ionicGalleryModal.GalleryModalModule,
    LazyLoadImageModule,
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    ListPage,
    SigninPage,
    AttendancePage,
    BusattendancePage,
    MyclassPage,
    MydiaryPage,
    QuerydetailPage,
    QueryreplyPage,
    FeeshomePage,
    GeneralizefeesPage,
    ClassfeesPage,
    QueryPage,
    AttendanceviewPage,
    //FirebasepreviewPage,
    TrackingPage,
    TeacherClassSectionPage,
    MysubjectsPage,
    StudentMarksPage,
    FacilitiesPage,
    SchoolpanelPage,
    AddFacilities,
    InfrastructurePage,
    AddMoreInfrastructure,
    InfrastructureInformation,
    SchoolinformationPage,
    SchoolbasicinformationPage,
    SchooladditionalinformationPage,
    CurriculumPage,
    LatestNewsPage,
    ReviewsPage,
    FeestructurePage,
    ExamresultPage,
    ExamSchedulePage,
    Addnews,
    Addcurriculum,
    SkooldeskbookingPage,
    NoticeBoardPage,
    NoticeFormPage,
    SchoolcalendarPage,
    AdmissionalertsPage,
    Addadmissionalert,
    ReplydetailPage,
    Addreviewreply,
    AdmissionenquiriesPage,
    AdmissionenquirydetailPage,
    Addadmissionenquiryreply,
    SchoolcontactsPage,
    SchoolcontactsdetailPage,
    Addcontactquiryreply,
    GalleryPage,
    PopoverPage,
    PasswordPage,
    p_HomePage,p_QueryPage,p_QuerydetailPage,p_PopoverPage,p_NoticeBoardPage,p_AttendanceviewPage,p_PasswordPage,p_QueryreplyPage,
    StudentPage,QueryformPage,FeePage,paymentWifergation,UserPage,SignupPage,MyprofilePage,EditprofilePage,StudentfeePage,BusroutePage,PayfeePage,ExamTermPage,ReportCardPage,EmailConfigurationPage,LoginPage,PaymentResponsePage,
    SchoolbusesPage,
    SchoolteachersPage,
    SpaccountverificationPage,
    ForgotpasswordPage,   
    PCurriculumPage,PCalendarPage,PLatestNewsPage,PFeeStructurePage,PExamSchedulePage,PExamResultPage,
    SchoolslistPage,ClaimschoolPage,SchoolRegistrationPage,AreaListPage,SchoolsignupPage,
    SchoolclaimconfirmationPage, SchoolTempRegisConfirmationPage,
    MyschooltimetablePage,
    NoticeBoardTeacherPage, 
    tracking_test,  
    HandBookTeacherPage,HandBookFormPage,
    AdminTeacherMessagePage,messageFormModal,
    PHandBookPage,
  ],
  providers: [
    StatusBar,
    SplashScreen,
    AuthServiceProvider,InAppBrowser,
    FirebaseProvider,
    FirebasedbProvider,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    Geolocation,
    BackgroundGeolocation,
    File,
    FilePath,
    Transfer,
    FileTransfer,
    FileChooser,
    FileOpener,
    Transfer,
    Camera,
    Crop,
    SocialSharing,
    DatePipe,
    ImagePicker,
    p_AuthServiceProvider,
    BackgroundMode, Network,Facebook,
    {provide: HAMMER_GESTURE_CONFIG,useClass: ionicGalleryModal.GalleryModalHammerConfig},
    FCM,LocalNotifications,
  ]
})

export class AppModule {
  
    connectSubscription: Subscription;
    disconnectSubscription: Subscription;
    networkStatus: string;
  
    constructor( 
                public network:Network, 
                public toastCtrl:ToastController,
                public alertCtrl: AlertController, 
                public statusBar: StatusBar, 
                public splashScreen: SplashScreen,
                public platform: Platform,
               )
    {
      platform.ready().then(() => {
        // watch network for a disconnect
        this.disconnectSubscription = this.network.onDisconnect().subscribe(data => {
          this.networkStatus = data.type;
          let toast = this.toastCtrl.create({ message: 'Could not connect to internet.', 'cssClass':'toastText', duration: 15000 });
          toast.present();
        });
  
        // watch network for a connection
        this.connectSubscription = this.network.onConnect().subscribe(data => {
          this.networkStatus = data.type;
          let toast = this.toastCtrl.create({ message: 'Connecting...', 'cssClass':'toastText', duration: 5000 });
          toast.present();
        });
  
        statusBar.styleDefault();
        splashScreen.hide();
      });
    }
  
    ionViewDidLoad()
    {
    }
  
    ionViewWillLeave()
    {
      this.disconnectSubscription.unsubscribe();
      this.connectSubscription.unsubscribe();
    }
    
    
  
  
  }
