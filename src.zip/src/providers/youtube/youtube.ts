import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class YoutubeProvider {

  apiKey = 'AIzaSyBdakA7zm42zaPFCe4yg1D10q-I4cLERk0';

  constructor(public http: Http) {
    console.log('Hello YoutubeProvider Provider');
  }

  getAllYoutubeVideos(channel) {
    return this.http.get('https://www.googleapis.com/youtube/v3/search?key=' + this.apiKey + '&channelId=' + channel + '&part=snippet,id&maxResults=20&type=video&order=date')
    .map((res) => {
      return res.json()['items'];
    })
  }

}
