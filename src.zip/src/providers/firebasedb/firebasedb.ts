import { global } from './../../app/global';
import { ToastController } from 'ionic-angular';
import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { AngularFireDatabase, FirebaseListObservable } from 'angularfire2/database'
import { BackgroundGeolocation, BackgroundGeolocationConfig, BackgroundGeolocationResponse } from '@ionic-native/background-geolocation';
import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';


@Pipe({
  name: 'dateFormatPipe',
})

@Injectable()
export class FirebasedbProvider {

  constructor(
                public http: Http, 
                public aFD: AngularFireDatabase, 
                public backgroundGeolocation: BackgroundGeolocation, 
                public toastCtrl: ToastController
              ) 
  {
    console.log('Hello FirebasedbProvider Provider'); 
  }

  getData(){
    return this.aFD.list('/locations-' + window.localStorage.getItem('schoolid') + '/');
  }

  addItem(name) {
    this.aFD.list('/locations-' + window.localStorage.getItem('schoolid') + '/').push(name);
  }
 
  removeItem(id) {
    this.aFD.list('/locations-' + window.localStorage.getItem('schoolid') + '/').remove(id);
  }

  startTracking(){

    let toast: any;

    /*toast = this.toastCtrl.create({
        message: "start tracking",
        duration: 5000
      });
    toast.present();*/

    let config = {
      desiredAccuracy: 0,
      stationaryRadius: 2,
      distanceFilter: 1, 
      debug: true,
      interval: 1000 
    };
  
    this.backgroundGeolocation.configure(config).subscribe((location) => {
  
      console.log('BackgroundGeolocation:  ' + location.latitude + ',' + location.longitude);
  
      // Run update inside of Angular's zone
      this.addItem({
        lat: location.latitude,
        long: location.longitude,
        busid: global.busId
      });

      /*toast = this.toastCtrl.create({
        message: location.latitude + " " + location.longitude,
        duration: 5000
      });
      toast.present();*/
  
    }, (err) => {
  
      console.log(err);
  
    });

    this.backgroundGeolocation.changePace(true);
  
    // Turn ON the background-geolocation system.
    this.backgroundGeolocation.start();
  }

  stopTracking(){
    this.backgroundGeolocation.stop();
  }

  public getBusRoute(schoolid,busid) 
  {
      return this.aFD.list('locations-'+schoolid, {
        query: {
          orderByChild:'busid',
          equalTo:parseInt(busid) //startAt: { value: 'some-value', key: 'some-key' }.
        }
      });
  }

  public addBusRoute(schoolid,data) 
  {
    this.aFD.list('locations-'+schoolid).push(data);
  }
 
  public deleteBusRoute(schoolid,busid) 
  {
    var ref = this.aFD.list('locations-'+schoolid, {
      preserveSnapshot: true,
      query: {
        orderByChild:'busid',
        equalTo:busid
      }
    });
    ref.subscribe(snapshots=>{
      snapshots.forEach(snapshot => {
        snapshot.ref.remove();
      });
    })
  }

  public AttendancePushMessage(schoolid,studentArray)
  {
    var datePipe = new DatePipe("en-US");
    let currentDate = datePipe.transform(Date.now(), 'ddMMyyyy');
    
    // insert student attendance
    studentArray.forEach(element => {
      if(element.abReason == ''){
        var st = 'p'; // p = present
      }else if(element.abReason !== 'Absent'){
        var st = 'l'; // l = leave
      }else{
        var st = 'a'; // a = absent  
      }
      this.aFD.list('/attendance-'+schoolid).push({ 
        'student': parseInt(element.studentid+currentDate), 
        'status': st
      });
    });
  }

  public NoticePushMessage(schoolid,notice,studentArray)
  {
    var datePipe = new DatePipe("en-US");
    let currentDate = datePipe.transform(Date.now(), 'ddMMyyyy');
    studentArray.forEach(element => {      
      this.aFD.list('/NoticeBoard-'+schoolid).push({ 
        'notice': notice, 
        'student': parseInt(element.sid+currentDate)
      });
    });
  }

  public BusAttendancePushMessage(schoolid,studentArray)
  {
    var datePipe = new DatePipe("en-US");
    let currentDate = datePipe.transform(Date.now(), 'ddMMyyyy');
    // insert student bus attendance
    studentArray.forEach(element => {
      this.aFD.list('/BusAttendance-'+schoolid).push({ 
        'student': parseInt(element+currentDate)
      });
    });
  }


  public GeneralizeFeePushNotification(schoolid,title,amount,lastdate,studentArray)
  {
    var datePipe = new DatePipe("en-US");
    let currentDate = datePipe.transform(Date.now(), 'ddMMyyyy');
    studentArray.forEach(element => {
          this.aFD.list('/Fee-'+schoolid).push({ 
            'studentid': parseInt(element.sid+currentDate),
            'title': title,
            'amount': parseInt(amount),
            'lastdate': lastdate,        
          });
    });
  }




}
