var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import { global } from "../../app/global";
var AuthServiceProvider = (function () {
    function AuthServiceProvider(http) {
        this.http = http;
        console.log('Hello AuthServiceProvider Provider');
    }
    // starts //
    AuthServiceProvider.prototype.postData = function (postedData, methodName) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var headers = new Headers();
            var api = global.apiUrl;
            if (postedData != null) {
                _this.http.post(api + methodName, JSON.stringify(postedData), { headers: headers }).subscribe(function (res) {
                    resolve(res.json());
                }, function (err) {
                    reject(err);
                });
            }
            else {
                _this.http.get(api + methodName).subscribe(function (res) {
                    resolve(res.json());
                }, function (err) {
                    reject(err);
                });
            }
        });
    };
    return AuthServiceProvider;
}());
AuthServiceProvider = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [Http])
], AuthServiceProvider);
export { AuthServiceProvider };
//# sourceMappingURL=auth-service.js.map