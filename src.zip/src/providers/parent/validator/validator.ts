import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';

@Injectable()
export class ValidatorProvider {

  constructor() {
    console.log('Hello ValidatorProvider Provider');
  }

}
