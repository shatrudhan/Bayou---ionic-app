
import { Injectable,Pipe } from '@angular/core';
import { AngularFireDatabase } from 'angularfire2/database';
import { DatePipe } from '@angular/common';


@Pipe({
  name: 'dateFormatPipe',
})

@Injectable()
export class FirebaseProvider {
 
  constructor( 
              public afd: AngularFireDatabase
            )
   {
    
   }
 
  public getBusRoute(schoolid,busid) 
  {
      return this.afd.list('locations-'+schoolid, {
        query: {
          orderByChild:'busid',
          equalTo:parseInt(busid) //startAt: { value: 'some-value', key: 'some-key' }.
        }
      });
  }
  
  public addBusRoute(schoolid,data) 
  {
    this.afd.list('locations-'+schoolid).push(data);
  }
 
  public deleteBusRoute(schoolid,busid) 
  {
    var ref = this.afd.list('locations-'+schoolid, {
      preserveSnapshot: true,
      query: {
        orderByChild:'busid',
        equalTo:busid
      }
    });
    ref.subscribe(snapshots=>{
      snapshots.forEach(snapshot => {
        snapshot.ref.remove();
      });
    })
  }

  // STUDENT CLASS ATTENDANCE NOTIFICATION

  public getStudentAttendance(school_id,student_id)
  {
    var datePipe = new DatePipe("en-US");
    var currentDate = datePipe.transform(Date.now(), 'ddMMyyyy');

     return this.afd.list('/attendance-'+school_id, {
       query: {
         orderByChild: 'student',
         equalTo: parseInt(student_id+currentDate)
       }
     });
  }
  public deleteStudentAttendance(school_id,student_id)
  {
    var datePipe = new DatePipe("en-US");
    let currentDate = datePipe.transform(Date.now(), 'ddMMyyyy');

    var ref = this.afd.list('/attendance-'+school_id, {
      preserveSnapshot: true,
      query: {
        orderByChild: 'student',
        equalTo: parseInt(student_id+currentDate)
      }
    });
    ref.subscribe(snapshots=>{
      snapshots.forEach(snapshot => {
        snapshot.ref.remove();
      });
    })
  }

  // NOTICE BOARD NOTIFICATION

  public GetNoticeBoardPushNotification(school_id,student_id)
  {
    var datePipe = new DatePipe("en-US");
    var currentDate = datePipe.transform(Date.now(), 'ddMMyyyy');
     return this.afd.list('/NoticeBoard-'+school_id, {
       query: {
         orderByChild: 'student',
         equalTo: parseInt(student_id+currentDate)
       }
     }).map((array) => array.reverse());
  }
  public DeleteNoticeBoardPushNotification(school_id,student_id)
  {
    var datePipe = new DatePipe("en-US");
    let currentDate = datePipe.transform(Date.now(), 'ddMMyyyy');
    var ref = this.afd.list('/NoticeBoard-'+school_id, {
      preserveSnapshot: true,
      query: {
        orderByChild: 'student',
        equalTo: parseInt(student_id+currentDate)
      }
    });
    ref.subscribe(snapshots=>{
      snapshots.forEach(snapshot => {
        snapshot.ref.remove();
      });
    })
  }

  // BUS ATTENDANCE NOTIFICATION

  public GetBusAttendancePushNotification(school_id,student_id)
  {
    var datePipe = new DatePipe("en-US");
    var currentDate = datePipe.transform(Date.now(), 'ddMMyyyy');
     return this.afd.list('/BusAttendance-'+school_id, {
       query: {
         orderByChild: 'student',
         equalTo: parseInt(student_id+currentDate)
       }
     }).map((array) => array.reverse());
  }
  public DeleteBusAttendancePushNotification(school_id,student_id)
  {
    var datePipe = new DatePipe("en-US");
    let currentDate = datePipe.transform(Date.now(), 'ddMMyyyy');
    var ref = this.afd.list('/BusAttendance-'+school_id, {
      preserveSnapshot: true,
      query: {
        orderByChild: 'student',
        equalTo: parseInt(student_id+currentDate)
      }
    });
    ref.subscribe(snapshots=>{
      snapshots.forEach(snapshot => {
        snapshot.ref.remove();
      });
    })
  }

  // FEE NOTIFICATION

  public GetFeePushNotification(school_id,student_id)
  {
    var datePipe = new DatePipe("en-US");
    var currentDate = datePipe.transform(Date.now(), 'ddMMyyyy');
     return this.afd.list('/Fee-'+school_id, {
       query: {
         orderByChild: 'studentid',
         equalTo: parseInt(student_id+currentDate)
       }
     }).map((array) => array.reverse());
  }
  public DeleteFeePushNotification(school_id,student_id)
  {
    var datePipe = new DatePipe("en-US");
    let currentDate = datePipe.transform(Date.now(), 'ddMMyyyy');
    var ref = this.afd.list('/Fee-'+school_id, {
      preserveSnapshot: true,
      query: {
        orderByChild: 'studentid',
        equalTo: parseInt(student_id+currentDate)
      }
    });
    ref.subscribe(snapshots=>{
      snapshots.forEach(snapshot => {
        snapshot.ref.remove();
      });
    })
  }



}