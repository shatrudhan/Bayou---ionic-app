import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, ToastController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { ReplydetailPage } from '../replydetail/replydetail';

/**
 * Generated class for the ReviewsPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-reviews',
  templateUrl: 'reviews.html',
})
export class ReviewsPage {

  schoolName: string;
  selectedItem: any;
  icons: string[];
  items: Array<{name: string,emailid: string, comment: string, reviewid: number, rating: any}>;
  myLoadingControl: any;
  loader: any;
  responseData: any;
  postData: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public loadingCtrl: LoadingController, public authservice: AuthServiceProvider, public toastCtrl: ToastController) {
    // If we navigated to this page, we will have an item available as a nav param
    this.selectedItem = navParams.get('item');
    this.loader
    this.myLoadingControl = loadingCtrl;

    // Let's populate this page with some filler content for funzies
    this.icons = ['flask', 'wifi', 'beer', 'football', 'basketball', 'paper-plane',
    'american-football', 'boat', 'bluetooth', 'build'];

    this.items = [];
    this.schoolName = localStorage.getItem('schoolname');
    /*for (let i = 1; i < 11; i++) {
      this.items.push({
        title: 'Item ' + i,
        note: 'This is item #' + i,
        icon: this.icons[Math.floor(Math.random() * this.icons.length)],
        srno: i
      });
    }*/
    this.postData = {teacherid: window.localStorage.getItem('teacherid'), schoolid: window.localStorage.getItem('schoolid')};
    this.loadPeriods();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ReviewsPage');
  }

  loadPeriods(){
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {
      this.authservice.postData(this.postData, 'reviews/get').then((result)=>{
  		this.responseData = result;
  		console.log(this.responseData);
     if(this.responseData['response'] == 1){
          this.items = this.responseData['reviews'];
        }
        this.loader.dismiss();
  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismiss();
  	  });
    });
  }

  itemTapped(cmtId){
    this.navCtrl.push(ReplydetailPage, {reviewid: cmtId});
  }

}
