import { ToastController } from 'ionic-angular/components/toast/toast-controller';
import { LoadingController } from 'ionic-angular/components/loading/loading-controller';
import { SchoolpanelPage } from './../schoolpanel/schoolpanel';
import { Component } from '@angular/core';
import { NavController, NavParams, AlertController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';

/**
 * Generated class for the SpaccountverificationPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-spaccountverification',
  templateUrl: 'spaccountverification.html',
})
export class SpaccountverificationPage {

  schoolName: string;
  postData: any;
  loader: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public myLoadingControl: LoadingController, public authservice: AuthServiceProvider, public toastCtrl: ToastController, public alertCtrl: AlertController) {
    this.schoolName = window.localStorage.getItem('schoolname');
    this.postData = {loginid: window.localStorage.getItem('useremail')};
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SpaccountverificationPage');
  }

  skipScreen()
  {
    this.navCtrl.setRoot(SchoolpanelPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
  }

  resendLink(){
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {

     this.authservice.postData(this.postData, "resendactivationlink").then((result)=>{
  		//this.responseData = result;
  		//console.log(this.responseData);
  		if(result['response'] == 1){
        let alert = this.alertCtrl.create({
          title: 'Successfully Sent!',
          subTitle: 'Verification email has been sent successfully.Please check your registered email id',
          buttons: [
            {
              text: 'Ok',
              handler: () => {                
                this.loader.dismiss();
                this.navCtrl.setRoot(SchoolpanelPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
              }
            }
          ]
        });
        alert.present();
        this.loader.dismiss();
  		}else{
        this.loader.dismiss();
  		}
  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismiss();
  	  });
    });
  }

}
