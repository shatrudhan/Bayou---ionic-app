import { AuthServiceProvider } from '../../../providers/auth-service/auth-service';
import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer';
import { FileChooser } from '@ionic-native/file-chooser';
import { FilePath } from '@ionic-native/file-path';

import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, ToastController, ActionSheetController, AlertController, Platform } from 'ionic-angular';
import { File } from '@ionic-native/file';
import { global } from '../../../app/global';
import { FileOpener } from '@ionic-native/file-opener';
import { TransferObject, Transfer } from '@ionic-native/transfer';

@Component({
  selector: 'page-p-fee-structure',
  templateUrl: 'p-fee-structure.html',
})
export class PFeeStructurePage {
  schoolName: any;
  loader: any;
  myLoadingCtrl: any;
  postData: any;
  items: Array<{doctitle: string, docpath: string, docid: number, extension: string}>;
  schoolid: any;
  storageDirectory: string = '';
  schoolname: any;
  studentname: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public loadingCtrl: LoadingController, public authservice: AuthServiceProvider, public toastCtrl: ToastController, public fileTransfer: FileTransfer, public filePath: FilePath, public myFile: File, public actionSheetCtrl: ActionSheetController, public fileChooser: FileChooser, public alertCtrl: AlertController, public fileOpener:FileOpener, public platform:Platform) {
    this.myLoadingCtrl = loadingCtrl;    
    this.studentname = this.navParams.get('studentname'); 
    this.schoolid = this.navParams.get('schoolid');  
    this.schoolname = this.navParams.get('schoolname');        
    this.postData = {schoolid: this.schoolid, doctype: 'F', docid: 0};
    this.items = [];
    this.getInformation();    
  }

  getInformation()
  {
      this.loader = this.myLoadingCtrl.create({
        content : "Please wait.."
      });
  
      this.loader.present().then(() => {
        
        this.authservice.postData(this.postData, 'documents/get').then((result)=>{
          
          if(result['response'] == 1){
            this.items = result['documents'];
          } 
          else
          {
            let toast = this.toastCtrl.create({
                message: 'Sorry! unable to process your request',
                duration: 3000
              });
            toast.present();
          }
  
          this.loader.dismiss();       
  
        },(err)=> {
            //alert('failled '+err);
            let toast = this.toastCtrl.create({
                message: err,
                duration: 3000
              });
            toast.present();
            this.loader.dismiss();
        });
        //this.loader.dismiss();
      });
  }

  fileOpen(filepath,extension)
  {
      var filename = filepath.substring(filepath.lastIndexOf('/') + 1, filepath.length );
      const fileTransfer: FileTransferObject = this.fileTransfer.create();
      const imageLocation = global.apiBaseUrl+'backoffice/uploads/school-'+this.schoolid+'/'+filename;

      fileTransfer.download(encodeURI(filepath), this.storageDirectory + filename).then((entry) => 
      {
        this.fileOpener.open(this.storageDirectory + filename, global.getMIMEtype(extension)).then(() => 
        console.log('File is opened'))
        .catch(e => console.log('Error openening file', e));
      }, (error) => {
        const alertFailure = this.alertCtrl.create({
          title: `Download Failed !`,
          subTitle: `${filename} failed to download.`,
          buttons: ['Ok']
        });
        alertFailure.present();
      });      
  }
  
  ionViewDidLoad() {
    console.log('ionViewDidLoad PFeeStructurePage');
  }

}
