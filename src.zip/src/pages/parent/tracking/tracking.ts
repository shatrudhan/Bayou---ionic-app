import { Component, ViewChild, ElementRef, NgZone } from '@angular/core';
import { NavController, Platform, NavParams, ToastController, ViewController } from 'ionic-angular';
import { FirebaseProvider } from './../../../providers/parent/firebase/firebase';
import { Geolocation } from '@ionic-native/geolocation';

declare var google;

@Component({
  selector: 'page-tracking',
  templateUrl: 'tracking.html',
})
export class TrackingPage {
  schoolid: any;
  studentid: any;
  busid: any;

  long: any;
  lat: any;
  cLong: any;
  cLat: any;

  @ViewChild('map') mapElement: ElementRef;
  map:any;
  marker:any;

  constructor(
              public navCtrl: NavController,
              public navParams: NavParams,
              public toastCtrl: ToastController,
              public platform: Platform, 
              public viewCtrl: ViewController, 
              public geolocation: Geolocation,
              public firebaseProvider: FirebaseProvider,
              public ngZOne:NgZone
  ) 
  {
    this.geolocation.getCurrentPosition().then((position) => {
      var lat = position.coords.latitude;
      var long = position.coords.longitude;
      this.loadMap(lat,long);
    });
  }

  ionViewDidLoad() 
  {
    console.log('ionViewDidLoad TrackingPage');
    this.busid = this.navParams.get('busid');
    this.studentid = this.navParams.get('studentid');
    this.schoolid = this.navParams.get('schoolid');    
  }

  removeDatabaseData()
  {
    this.firebaseProvider.deleteBusRoute(this.schoolid,parseInt(this.busid));
  }

  loadMap(lat,long)
  {
    
    this.platform.ready() .then(() => {
      
        // MAP
        let latLong = new google.maps.LatLng(lat,long);
        let mapOptions = {
          center: latLong,
          zoom: 15,
          mapTypeId: google.maps.MapTypeId.ROADMAP
        }
      this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
      
      var panPoint = new google.maps.LatLng(lat,long);
      this.map.panTo(panPoint);

      // ONCLICK ADDING NEW POSITION
      new google.maps.event.addListener(this.map, 'click', (event) => {
        let loc = {lat:event.latLng.lat(),long:event.latLng.lng(),busid:parseInt(this.busid)}
        this.firebaseProvider.addBusRoute(this.schoolid,loc);
      });
    
      // MAKE NEW MARKER
      this.firebaseProvider.getBusRoute(this.schoolid,this.busid).subscribe(res=>{
        new google.maps.Marker({
          map: this.map,
          draggable: true,       
          animation: google.maps.Animation.DROP,
          position: {lat: res[res.length-1].lat, lng: res[res.length-1].long}       
        });
      });
  
    });

  }



}
