import { AuthServiceProvider } from '../../../providers/auth-service/auth-service';
import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer';
import { FileChooser } from '@ionic-native/file-chooser';
import { FilePath } from '@ionic-native/file-path';

import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, ToastController, ActionSheetController, AlertController, Platform } from 'ionic-angular';
import { File } from '@ionic-native/file';
import { global } from '../../../app/global';
import { FileOpener } from '@ionic-native/file-opener';
import { TransferObject, Transfer } from '@ionic-native/transfer';

declare var cordova: any;

@Component({
  selector: 'page-p-exam-schedule',
  templateUrl: 'p-exam-schedule.html',
})
export class PExamSchedulePage {

  schoolName: any;
  loader: any;
  myLoadingCtrl: any;
  postData: any;
  items: Array<{doctitle: string, docpath: string, documentid: number, extension: string}>;
  schoolid: any;
  storageDirectory: string = '';

  constructor(public navCtrl: NavController, public navParams: NavParams, public loadingCtrl: LoadingController, public authservice: AuthServiceProvider, public toastCtrl: ToastController, public fileTransfer: FileTransfer, public filePath: FilePath, public myFile: File, public actionSheetCtrl: ActionSheetController, public fileChooser: FileChooser, public alertCtrl: AlertController, public fileOpener:FileOpener, public platform:Platform) {
    this.schoolName = this.navParams.get('schoolname');
    this.schoolid = this.navParams.get('schoolid');
    this.myLoadingCtrl = loadingCtrl;
    this.postData = {schoolid: this.navParams.get('schoolid'), doctype: 'E', documentid: 0};
    
    this.items = [];
    this.platform.ready().then(() => {
      if(!this.platform.is('cordova')) {
        return false;
      }
      if (this.platform.is('ios')) {
        this.storageDirectory = cordova.file.documentsDirectory;
      }
      else if(this.platform.is('android')) {
        this.storageDirectory = cordova.file.externalDataDirectory ;
      }
      else {
        // exit otherwise, but we could add further types here e.g. Windows
        return false;
      }
    });
    this.getInformation();
  }

  getInformation(){
    
        this.loader = this.myLoadingCtrl.create({
          content : "Please wait.."
        });
    
        this.loader.present().then(() => {
          
          this.authservice.postData(this.postData, 'documents/get').then((result)=>{
            
            if(result['response'] == 1){
              this.items = result['documents'];
              // this.items.push({
              //   doctitle: result['documents']['doctitle'],
              //   docpath: global.backoffice+result['documents']['docpath'],
              //   docid: result['documents']['documentid'],
              //   extension: result['documents']['extension']
              // })
            } 
            else
            {
              let toast = this.toastCtrl.create({
                  message: 'Sorry! unable to process your request',
                  duration: 3000
                });
              toast.present();
            }
    
            this.loader.dismiss();       
    
          },(err)=> {
              //alert('failled '+err);
              let toast = this.toastCtrl.create({
                  message: err,
                  duration: 3000
                });
              toast.present();
              this.loader.dismiss();
          });
    
          //this.loader.dismiss();
          
        });
        
      }
    

  ionViewDidLoad() {
    console.log('ionViewDidLoad ExamSchedulePage');
  }

  fileOpen(filepath,extension)
  {
      var filename = filepath.substring(filepath.lastIndexOf('/') + 1, filepath.length );
      const fileTransfer: FileTransferObject = this.fileTransfer.create();
      const imageLocation = global.apiBaseUrl+'backoffice/uploads/school-'+this.schoolid+'/'+filename;

      fileTransfer.download(encodeURI(filepath), this.storageDirectory + filename).then((entry) => 
      {
        this.fileOpener.open(this.storageDirectory + filename, global.getMIMEtype(extension)).then(() => 
        console.log('File is opened'))
        .catch(e => console.log('Error openening file', e));

      }, (error) => {
        const alertFailure = this.alertCtrl.create({
          title: `Download Failed !`,
          subTitle: `${filename} failed to download.`,
          buttons: ['Ok']
        });
        alertFailure.present();
      });      
  }



}
