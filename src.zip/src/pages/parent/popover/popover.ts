import { Component } from '@angular/core';
import { ModalController, NavController, NavParams,ViewController } from 'ionic-angular';
import { LoginPage } from '../login/login';
import { PasswordPage } from '../password/password';
import { MyprofilePage } from '../myprofile/myprofile';
import { SigninPage } from '../../signin/signin';
import { AuthServiceProvider } from './../../../providers/parent/auth-service/auth-service';


@Component({
  selector: 'page-popover',
  templateUrl: 'popover.html',
})
export class PopoverPage {

  constructor
  (
    public navCtrl: NavController, 
    public navParams: NavParams,
    public viewCtrl: ViewController,
    public modalCtrl: ModalController,
    public authservice: AuthServiceProvider,    
  ) 
  {

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PopoverPage');
  }
 
  close() 
  {
    this.viewCtrl.dismiss();
  }

  profile()
  {
    this.viewCtrl.dismiss();
    let modal = this.modalCtrl.create(MyprofilePage);
    modal.present();
  }

  password()
  {
    this.viewCtrl.dismiss();
    let modal = this.modalCtrl.create(PasswordPage);
    modal.present();
  }

  logout()
  {
    this.authservice.postData({'useremail':localStorage.getItem('useremail'),'usertype':'parent'}, 'ParentDeviceTokenDestroy').then((result)=>{
        if(result['response'] == 1){
          console.log('token destroy');
        }else{
          console.log('token destroy failed');
        }
    },(err)=> {
      alert('failled '+err);
    });
    this.viewCtrl.dismiss();
    localStorage.clear();
    this.navCtrl.setRoot(SigninPage);
  }


}
