import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, ToastController } from 'ionic-angular';
import { AuthServiceProvider } from './../../../providers/parent/auth-service/auth-service';

@Component({
  selector: 'page-report-card',
  templateUrl: 'report-card.html',
})
export class ReportCardPage {
  responseData: number;
  totalMarks: number;
  obtainMarks: number;
  examname: any;
  termname: any;
  schoolname: any;
  sectionname: any;
  classname: any;
  studentname: any;

  postData1: { 'schoolid': any; 'studentid': any; 'classid': any; 'sectionid': any; 'termid': any; 'examid': any};
  reportCardInfo: any;

  loader: any; myLoadingControl: any;
  schoolid: any; studentid: any; classid: any; sectionid: any; termid: any; examid: any;

  constructor(
      public navCtrl: NavController,
      public navParams: NavParams,
      public authservice: AuthServiceProvider,
      public loadingCtrl: LoadingController,
      public toastCtrl: ToastController,
  )
  {

    this.schoolid = this.navParams.get('schoolid');
    this.studentid = this.navParams.get('studentid');
    this.classid = this.navParams.get('classid');
    this.sectionid = this.navParams.get('sectionid');
    this.termid = this.navParams.get('termid');
    this.examid = this.navParams.get('examid');
    
    this.myLoadingControl = loadingCtrl;

    this.postData1 = {'schoolid':this.schoolid,'studentid':this.studentid,'classid':this.classid,'sectionid':this.sectionid,'termid':this.termid, 'examid':this.examid}
    this.reportCard();
  }

  reportCard()
  {
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {
      this.authservice.postData(this.postData1, 'getStudentReportCard').then((result)=>{
        if(result['response'] == 1){
          this.responseData = 1;
          this.reportCardInfo = result['reportcard'];
          this.studentname = this.reportCardInfo[0].studentname;
          this.classname = this.reportCardInfo[0].classname;
          this.sectionname = this.reportCardInfo[0].sectionname;
          this.schoolname = this.reportCardInfo[0].schoolname; 
          this.examname = this.reportCardInfo[0].examname;          
          this.termname = this.reportCardInfo[0].termname;          
          // calculating sum of total obtain marks
          let totalObtainMarks = 0;
          for (var i = 0; i < this.reportCardInfo.length; i++) {
              if (this.reportCardInfo[i].obtainmark) {
                totalObtainMarks+=parseInt(this.reportCardInfo[i].obtainmark);
              }
          }
          this.obtainMarks = totalObtainMarks;
          // calculating sum of total marks
          let totalmarks = 0;
          for (var a = 0; a < this.reportCardInfo.length; a++) {
              if (this.reportCardInfo[a].totalmark) {
                totalmarks+=parseInt(this.reportCardInfo[a].totalmark);
              }
          }
          this.totalMarks = totalmarks;
          
          this.loader.dismiss();
        }else{
          this.responseData = 0;
          let toast = this.toastCtrl.create({ message: 'Sorry ! no data found.', 'cssClass':'toastText', duration: 3000 });
          toast.present();
          this.loader.dismiss();
        }
    	},(err)=> {
        let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 3000 });
        toast.present();
        this.loader.dismiss();
    	});
    });
  }

  ionViewDidLoad() 
  {
    console.log('ionViewDidLoad ReportCardPage');
  }

}
