import { DatePipe } from '@angular/common';
import { CalendarComponent } from 'ionic2-calendar/calendar';
import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, LoadingController, ToastController, AlertController } from 'ionic-angular';
import { AuthServiceProvider } from '../../../providers/auth-service/auth-service';

@Component({
  selector: 'page-p-calendar',
  templateUrl: 'p-calendar.html',
})
export class PCalendarPage {
  @ViewChild(CalendarComponent) myCalendar: CalendarComponent;
  
    eventSource: any;
    viewTitle: string;
    selectedDay: any;
    calendar: any;
    months: string[];
    loader: any;
    postData: any;
    responseData: any;
    currentDate: any;
    startTime: any;
    endTime: any;
    studentname: any;
    schoolName: any;
    isOnLoad: number;
  
    constructor(
      public navCtrl: NavController, 
      public navParams: NavParams, 
      public myLoadingControl: LoadingController, 
      public authservice: AuthServiceProvider, 
      public toastCtrl: ToastController, 
      public alertCtrl: AlertController, 
      public datepipe: DatePipe
    ) 
    {
      this.isOnLoad = 0;
      this.schoolName = this.navParams.get('schoolname');
      this.loader = myLoadingControl;
      this.postData = {schoolid: this.navParams.get('schoolid'), month: 0, year: 0};
      this.eventSource = [];
      this.responseData = [];
      this.months = ['January', 'February', 'March'];
      this.viewTitle = "Feb";
      this.selectedDay = new Date();
      this.calendar = {
        dateFormatter: {
            formatMonthViewDay: function(date:Date) {
                return date.getDate().toString();
            },
            formatMonthViewTitle: function(date:Date) {
                let monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'Octomber', 'November', 'December'];
                this.selectedDay = date;
                return monthNames[date.getMonth()] + '-' + date.getFullYear();
            },
            formatWeekViewDayHeader: function(date:Date) {
                return 'testWDH';
            },
            formatWeekViewTitle: function(date:Date) {
                return this.months[1];
            },
            formatWeekViewHourColumn: function(date:Date) {
                return 'testWH';
            },
            formatDayViewHourColumn: function(date:Date) {
                return 'testDH';
            },
            formatDayViewTitle: function(date:Date) {
                return 'testDT';
            }
        },
        mode: 'month',
        currentDate: new Date(),
        noEventsLabel: '',
        showEventDetail: false
      }
    }
  
    loadAttendance(){
      //let calDate = this.calendar.currentDate;
      //this.postData = {studentid: this.navParams.get('studentid'), month: this.selectedDay.getMonth()+1, year: this.selectedDay.getFullYear()};
      this.postData.month = this.selectedDay.getMonth()+1;
      this.postData.year = this.selectedDay.getFullYear();
      this.loader = this.myLoadingControl.create({
        content : "Please wait.."
      });
  
      this.eventSource = [];
  
      /*let toast = this.toastCtrl.create({
          message: this.calendar.currentDate.getMonth() + '',
          duration: 3000
      });
      toast.present();*/
      let colors: string[] = ['primary', 'danger'];
  
      this.loader.present().then(() => {
        this.authservice.postData(this.postData, 'calendar/get').then((result)=>{
        this.responseData = result;
        console.log(this.responseData);
        if(this.responseData['response'] == 1)
        {
              try {
                  let newDate = new Date();
                  let eventType = Math.floor(Math.random() * 2);
                  let startDay = Math.floor(Math.random() * 90) - 45;
                  let endDay = Math.floor(Math.random() * 2) + startDay;
                  for(let data of this.responseData['events'])
                  {
                      newDate = new Date(data['eventdate']);
                      //let startMinute = Math.floor(Math.random() * 24 * 60);
                      //let endMinute = Math.floor(Math.random() * 180) + startMinute;
                      let startTime = new Date(Date.UTC(newDate.getFullYear(), newDate.getMonth(), newDate.getDate()));
                      let endTime = new Date(Date.UTC(newDate.getFullYear(), newDate.getMonth(), newDate.getDate()+1));
                      this.eventSource.push({
                          title: data['eventtitle'],
                          startTime: startTime,
                          endTime: endTime,
                          allDay: true,
                          color: "colors[Math.floor(Math.random()*colors.length)]",
                          eventid: data['eventid']
                      });
                      console.log(newDate);
                      //this.calendar.loadEvents();
                  }
                  /* let toast = this.toastCtrl.create({
                      message: this.eventSource.length + '',
                      duration: 3000
                  });
                  toast.present(); */
                  //this.calendar.currentDate = newDate;
                  this.loader.dismiss();
              } catch (error) {
                  let toast = this.toastCtrl.create({
                      message: error + '',
                      duration: 3000
                  });
                  toast.present();
                  this.loader.dismiss();
              }            
              
        }else{
              this.loader.dismiss();
        }
  
          this.myCalendar.loadEvents();
          this.isOnLoad = 1;
  
        },(err)=> {
            //alert('failled '+err);
            let toast = this.toastCtrl.create({
                message: err,
                duration: 3000
              });
            toast.present();
            this.loader.dismiss();
        });
  
          
      });
    }
  
    ionViewDidLoad() {
      console.log('ionViewDidLoad AttendanceviewPage');
    }
  
    onRangeChanged(sTime, eTime){
      this.selectedDay = this.myCalendar.currentDate;
      /*let toast = this.toastCtrl.create({
          message: this.selectedDay + '',
          duration: 3000
      });
      toast.present();*/
      //this.calendar.currentDate = this.selectedDay;
  
      this.loadAttendance();
  
    }
  
    onEventSelected(event)
    {
  
    }
  
    onViewTitleChanged(title){
      this.viewTitle = title;    
  
    }
  
    onTimeSelected(event){
      
    }
  
    onCurrentDateChanged(event){
      //this.myCalendar.loadEvents();
      //this.loadAttendance();
    }
  
}
