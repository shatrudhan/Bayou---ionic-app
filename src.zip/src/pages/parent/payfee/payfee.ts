import { AuthServiceProvider } from './../../../providers/parent/auth-service/auth-service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component } from '@angular/core';
import { NavController, NavParams, ToastController, LoadingController } from 'ionic-angular';
import { StudentPage } from '../student/student';
import { FeePage } from '../fee/fee';


@Component({
  selector: 'page-payfee',
  templateUrl: 'payfee.html',
})
export class PayfeePage {

  public feeForm: FormGroup;
  enrollmentNo: any;
  myLoadingControl: any;
  loader: any;
  submitEnrollNo: any;
  studentList: any;
  
  constructor(
                public navCtrl: NavController, 
                public navParams: NavParams, 
                public formBuilder: FormBuilder, 
                public loadingCtrl: LoadingController, 
                public authService: AuthServiceProvider,
                public toastCtrl: ToastController,
              ) 
  {
    this.enrollmentNo = 0;
    this.myLoadingControl = loadingCtrl;
    this.feeForm = this.formBuilder.group({
      txtno: ['', [Validators.required]]
    });
    this.submitEnrollNo = {enrNo: '', email: localStorage.getItem('useremail')};
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PayfeePage');
  }

  doSubmit(){

    this.loader = this.myLoadingControl.create({
      content : "Please wait..."
    });

    this.loader.present().then(() => {

      this.authService.postData(this.submitEnrollNo, 'getStudentByEnrollment').then((result)=>{
        if(result['response'] == 1){
          this.studentList = result['students'];
          if(this.studentList.emailid != localStorage.getItem('useremail')){
            this.navCtrl.push(StudentPage , {studentinfo : this.studentList});
            this.loader.dismissAll();
          }else{
            this.navCtrl.push(FeePage , {schoolid: this.studentList.schoolId, studentid: this.studentList.sid, classid: this.studentList.classes, sectionid: this.studentList.section });
            this.loader.dismissAll();
          }
        }else if(result['response'] == 0){
          let toast = this.toastCtrl.create({ message: 'Invalid Enrollment number !', duration: 3000 });
          toast.present();
          this.loader.dismissAll();
        }else{
          let toast = this.toastCtrl.create({ message: 'Something went wrong ! Try again.', duration: 3000 });
          toast.present();
          this.loader.dismissAll();
        }
      },(err)=> {
        alert('failled '+err);
      });

    });

  }

  









}
