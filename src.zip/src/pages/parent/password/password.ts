import { Component } from '@angular/core';
import { NavController, NavParams, ViewController, App, LoadingController, ToastController } from 'ionic-angular';
import {Validators, FormGroup, FormBuilder } from '@angular/forms';
import { AuthServiceProvider } from './../../../providers/parent/auth-service/auth-service';
import { global } from "../../../app/global";


@Component({
  selector: 'page-password',
  templateUrl: 'password.html',
})
export class PasswordPage {

  public changePasswordForm : FormGroup;
  passForm:any; old_password:any; new_password:any; confirm_password:any; mismatchedPasswords:any;
  responseData:any;
  userData = {'oldpass':'', 'newpass':'', 'cpass':'', 'email':''};

  constructor(
               public navCtrl: NavController,
               public navParams: NavParams,
               public viewCtrl: ViewController,
               public app: App,
       			   public authservice: AuthServiceProvider,
       			   public loadingCtrl: LoadingController,
       			   public toastCtrl: ToastController,
               public formBuilder: FormBuilder,
             )
  {

    // change password form validation
    this.changePasswordForm = this.formBuilder.group({
      'old_password': ['', [Validators.required]],
      'new_password': ['', [Validators.required, Validators.minLength(6)]],
      'confirm_password': ['', Validators.required],
    }, {validator: global.matchingPasswords('new_password', 'confirm_password')});

    this.old_password = this.changePasswordForm.controls['old_password'];
    this.new_password = this.changePasswordForm.controls['new_password'];
    this.confirm_password = this.changePasswordForm.controls['confirm_password'];
    this.mismatchedPasswords = this.changePasswordForm['mismatchedPasswords'];

  }

  // CHECKING THAT NEW PASSWORD AND CONFIRM PASSWORD IS SAME OR NOT


  ionViewDidLoad()
  {
    console.log('ionViewDidLoad PasswordPage');
  }

  // modal pop-up dismiss
  dismiss() {
    this.viewCtrl.dismiss();
  }

  // update password form submission
  changePassword()
  {

     this.userData.email = localStorage.getItem('useremail');

     this.authservice.postData(this.userData, 'updatePassword').then((result)=>{
     this.responseData = result;
     if(this.responseData['response'] == 1){
       let toast = this.toastCtrl.create({ message: this.responseData['msg'], 'cssClass':'toastText', duration: 3000 });
       toast.present();
       this.dismiss();
     }else if(this.responseData['response'] == 2){
       let toast = this.toastCtrl.create({ message: this.responseData['msg'], 'cssClass':'toastText', duration: 3000 });
       toast.present();
     }else{
       let toast = this.toastCtrl.create({ message: 'Sorry ! something went wrong.', 'cssClass':'toastText', duration: 3000 });
       toast.present();
     }
     },(err)=> {
       alert('failled : '+err);
     });

  }










}
