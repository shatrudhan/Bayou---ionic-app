import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, ToastController, AlertController, ViewController } from 'ionic-angular';
import {Validators, FormGroup, FormBuilder } from '@angular/forms';
import { AuthServiceProvider } from './../../../providers/parent/auth-service/auth-service';

@Component({
  selector: 'page-queryform',
  templateUrl: 'queryform.html',
})
export class QueryformPage {

  schoolid:number; classid:number; sectionid:number; studentid:number; queryClassObj:any;
  postArray:any; getArray:any;
  addArray = {'teacher_name':'', 'query':'', 'parentemail':localStorage.getItem('useremail'), 'schoolid':'', 'classid':'', 'sectionid':'', 'studentid':''};
  bindData: any;
  public queryForm : FormGroup;
  query_description: any; teacher_name: any;

  constructor(
              public navCtrl: NavController,
              public navParams: NavParams,
              public toastCtrl: ToastController,
              public authservice: AuthServiceProvider,
              public loadingCtrl: LoadingController,
              public alertCtrl: AlertController,
              public viewCtrl: ViewController,
              public formBuilder: FormBuilder
            )
  {

    this.queryClassObj = navParams.get('queryClassObj');
    this.schoolid = navParams.get('schoolid');
    this.studentid = navParams.get('studentid');
    this.classid = navParams.get('classid');
    this.sectionid = navParams.get('sectionid');


    this.postArray = { 'classid': this.classid, 'sectionid':this.sectionid, 'schoolid': this.schoolid };
    this.authservice.postData(this.postArray, 'getTeachersByschoolClass').then((result)=>{
        this.getArray = result['teachers'];
     },(err)=> {
       alert('failled '+err);
     });

     // query form validation
     this.queryForm = this.formBuilder.group({
       query_description: [null, [Validators.required]],
       teacher_name: [null, Validators.required]
     });
     this.query_description = this.queryForm.controls['query_description'];
     this.teacher_name = this.queryForm.controls['teacher_name'];

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad QueryformPage');
  }

  dismiss() {
      this.viewCtrl.dismiss();
  }

  submitQuery()
  {
    this.addArray.schoolid = this.navParams.get('schoolid');
    this.addArray.classid = this.navParams.get('classid');
    this.addArray.sectionid = this.navParams.get('sectionid');
    this.addArray.studentid = this.navParams.get('studentid');

    this.authservice.postData(this.addArray, 'addParentQuery').then((result)=>{
        this.bindData = result;
        if(this.bindData['response'] == 1){
          //this.dismiss();
          let toast = this.toastCtrl.create({ message: this.bindData['msg'], duration: 3000 });
    			toast.present();
          this.queryClassObj.parentQueries();
          this.navCtrl.pop();
          //this.navCtrl.push(QueryPage, { 'studentid': this.navParams.get('studentid'), 'classid': this.navParams.get('classid'), 'sectionid':this.navParams.get('sectionid'), 'schoolid': this.navParams.get('schoolid') });
        }else{
          this.dismiss();
    			let toast = this.toastCtrl.create({ message: this.bindData['msg'], duration: 3000 });
    			toast.present();
          this.navCtrl.pop(this.queryClassObj);
    		}
     },(err)=> {
       alert('failled '+err);
     });
  }













}
