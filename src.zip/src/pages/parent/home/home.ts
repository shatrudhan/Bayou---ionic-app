import { Platform } from 'ionic-angular';
import { Component } from '@angular/core';
import { ViewController, PopoverController , NavController, LoadingController,NavParams, ModalController, ToastController } from 'ionic-angular';
import { SignupPage } from '../signup/signup';
import { UserPage } from '../user/user';
import { AuthServiceProvider } from './../../../providers/parent/auth-service/auth-service';
import { PopoverPage } from '../popover/popover';
import { PayfeePage } from './../payfee/payfee';
// import { LocalNotifications } from '@ionic-native/local-notifications';
import { AttendanceviewPage } from '../attendanceview/attendanceview';
import { global } from '../../../app/global';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  scheduleFee: { 'studentid': any; 'schoolid': any; };

  responseData: any;
  globalVar: any;
  loader: any;
  myLoadingControl: any;
  constructor(
              public navCtrl: NavController,
              public modalCtrl: ModalController,
              public navParams: NavParams,
              public toastCtrl: ToastController,
              public authservice: AuthServiceProvider,
              public loadingCtrl: LoadingController,
              public popoverCtrl: PopoverController,
              // public localNotifications: LocalNotifications,
              private plt: Platform,
              public viewCtrl: ViewController,
             )
  {
    //this.autoCallSchedulerService();
    this.getStudents();
    this.globalVar = global.apiBaseUrl;
    this.myLoadingControl = loadingCtrl;

    this.plt.ready().then(() => {
     /* this.localNotifications.on('click', (success,state) => {
        var ed = JSON.parse(success.data);
        if(ed.remark == 'attendance'){
          this.navCtrl.push(AttendanceviewPage , {studentname:ed.name, studentid: ed.id });
        }else if(ed.remark == 'notice'){
          //this.navCtrl.push(NoticeBoardPage , {studentname:'', schoolid: ed.schoolid });
        }else if(ed.remark == 'busattendance'){
        }else if(ed.remark == 'fee'){
        } 
      });*/
    });  

  }

  autoCallSchedulerService()
  {
    this.authservice.postData({'useremail':localStorage.getItem('useremail')}, 'getAllParentChild').then((result)=>{
      result['responseData'].forEach(loopData => {
        this.scheduleFee = {'studentid':loopData.sid, 'schoolid':loopData.schoolId};
        this.authservice.postData(this.scheduleFee, 'studentFeeByScheduler').then((res)=>{
        });
      });
    });
  }

  signup()
  {
	  this.navCtrl.push(SignupPage);
  }

  getStudents()
  {
    this.authservice.postData({'useremail':localStorage.getItem('useremail')}, 'getAllParentChild').then((result)=>{
      this.responseData = result['responseData'];
    },(err)=> {
      let toast = this.toastCtrl.create({ message: err, duration: 3000 });
      toast.present();
    });
  }

  MorePopOver(myEvent) 
  {
    let popover = this.popoverCtrl.create(PopoverPage);
    popover.present({
      ev: myEvent
    });
  }

  goToScreen(schoolid,studentid,classid,sectionid,studentname,busarea,busstop,busincharge,schoolname)
  {
    this.navCtrl.push(UserPage , {schoolid: schoolid, studentid: studentid, classid: classid, sectionid: sectionid, studentname: studentname, busarea:busarea,busstop:busstop,busincharge:busincharge,schoolname:schoolname });
  }

  addChildAndPayFee()
  {
     this.navCtrl.push(PayfeePage, {}, {animate: true, direction: 'forward'});
  }


}
