import { Component } from '@angular/core';
import { NavController, NavParams, App, LoadingController, ToastController, AlertController } from 'ionic-angular';
import { AuthServiceProvider } from './../../../providers/parent/auth-service/auth-service';
import { FormBuilder, FormGroup, Validator, Validators } from '@angular/forms';
import { global } from "../../../app/global";
import { HomePage } from '../home/home';


@Component({
  selector: 'page-email-configuration',
  templateUrl: 'email-configuration.html',
})
export class EmailConfigurationPage {
  isDisabled: boolean;

  userData1: any;
  userData2: any;
  userData3: any;
  sess_email_mobile: string;

  public emailForm : FormGroup; v_txtemail: any;
  loader: any; otherLoader: any; myLoadingControl: any;
  
  constructor(
      public navCtrl: NavController,
      public navParams: NavParams,
      public app: App,
      public authservice: AuthServiceProvider,
      public loadingCtrl: LoadingController,
      public toastCtrl: ToastController,
      public formBuilder: FormBuilder,
      public alertCtrl: AlertController,
  )
  {

    this.emailForm = this.formBuilder.group({
      txtemail: ['', [Validators.required, Validators.pattern("[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?")]]
    });
    this.v_txtemail = this.emailForm.controls['txtemail'];

    this.sess_email_mobile = localStorage.getItem('useremail');
    this.myLoadingControl = loadingCtrl;
    this.userData1 = {'txtemail':'', 'txtmobile': localStorage.getItem('useremail')};  
    this.isDisabled = false;
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad EmailConfigurationPage');
  }

  updateEmailAddress()
  {
    
        this.loader = this.myLoadingControl.create({
          content : "Please wait.."
        });

        this.loader.present().then(() => {
          this.authservice.postData(this.userData1, 'emailUpdateVarification').then((result)=>{
          
          // EMAIL ALREADY EXIST IN DATABASE THEN VERIFY FIRST PARENT PASSWORD AND AFTER THAT LOGGEDIN
          if(result['response'] == 3)
          {
            this.isDisabled = global.makeDisabled; // making disabled input fields
            
            const alert = this.alertCtrl.create({
              title: 'Confirmation !',
              enableBackdropDismiss: false,
              message: 'Do you really want to login with '+this.userData1['txtemail']+' !',
              buttons: [
                {
                  text: 'Cancel',
                  role: 'cancel',
                  handler: () => {
                    console.log('Cancel clicked');
                    this.loader.dismiss();
                    this.isDisabled = global.makeEnabled; // making disabled input fields
                  }
                },
                {
                  text: 'Ok',
                  handler: () => {

                    this.loader.dismiss();
                    let prompt = this.alertCtrl.create({
                      title: 'Please enter your password to signin.',
                      enableBackdropDismiss: false,
                      //message: "Please enter your password to signin. ",
                      inputs: [
                        {
                          name: 'existpassword',
                          placeholder: 'password',
                          type: 'password'
                        },
                      ],
                      buttons: [
                        {
                          text: 'Cancel',
                          handler: data => {
                            this.isDisabled = global.makeEnabled; // making disabled input fields
                          }
                        },
                        {
                          text: 'Signin',
                          handler: data => {
        
                            let userData2 = {'email':this.userData1['txtemail'] , 'password': data.existpassword, 'mobileno':localStorage.getItem('useremail')};
        
                            if(data.existpassword == ''){
                              let toast = this.toastCtrl.create({ message: 'Please enter password !', duration: 3000 });
                              toast.present();
                              return false;
                            }
        
                            this.otherLoader = this.myLoadingControl.create({
                              content : "Please wait.."
                            });
        
                            this.otherLoader.present().then(() => {
                              this.authservice.postData(userData2, 'ParentLoginWithEmail').then((result)=>{
                                if(result['eResponse'] == 1){
                                    localStorage.removeItem('useremail');
                                    localStorage.setItem('useremail',userData2['email']);
                                    // let toast = this.toastCtrl.create({ message: 'abc :'+localStorage.getItem('useremail'), duration: 5000 });
                                    // toast.present();
                                    this.navCtrl.push(HomePage);
                                    prompt.dismiss();
                                    this.otherLoader.dismiss();
                                }else if(result['eResponse'] == 0) {
                                    let toast = this.toastCtrl.create({ message: result['msg'], duration: 5000 });
                                    toast.present();
                                    this.otherLoader.dismiss();
                                }else{
                                    let toast = this.toastCtrl.create({ message: 'Sorry ! something went wrong.', duration: 3000 });
                                    toast.present();
                                    this.otherLoader.dismiss();
                                }
                            },(err)=> {
                                this.otherLoader.dismiss();
                            });
                            });
                              return false;
                          }
                        }
                      ]
                    });
                    prompt.present();

                  }
                }
              ]
            });
            alert.present();
          }
          // VERIFICATION TEXT MAIL SENT
          if(result['response'] == 2)
          {
          
            this.loader.dismiss();
            let prompt = this.alertCtrl.create({
              title: 'Varification Alert !.',
              enableBackdropDismiss: false,
              message: "Please enter 6 digit varification code which is sent on "+this.userData1['txtemail']+' !',
              inputs: [
                {
                  name: 'varificationcode',
                  placeholder: 'Varification Code',
                  type: 'string'
                },
              ],
              buttons: [
                {
                  text: 'Cancel',
                  handler: data => {
                    this.isDisabled = global.makeEnabled; // making disabled input fields
                  }
                },
                {
                  text: 'Varify',
                  handler: data => {

                    let userData3 = {'email':this.userData1['txtemail'] , 'varificationcode': data.varificationcode, 'mobileno':localStorage.getItem('useremail')};

                    if(data.varificationcode == ''){
                      let toast = this.toastCtrl.create({ message: 'Please enter 6 digit code !', duration: 3000 });
                      toast.present();
                      return false;
                    }

                    this.otherLoader = this.myLoadingControl.create({
                      content : "Please wait.."
                    });

                    this.otherLoader.present().then(() => {
                      this.authservice.postData(userData3, 'ParentNewEmail').then((result)=>{
                        if(result['eResponse'] == 1){
                            localStorage.removeItem('useremail');
                            localStorage.setItem('useremail',userData3['email']);
                            this.navCtrl.push(HomePage);
                            prompt.dismiss();
                            this.otherLoader.dismiss();
                        }else if(result['eResponse'] == 0) {
                            let toast = this.toastCtrl.create({ message: result['msg'], duration: 3000 });
                            toast.present();
                            this.otherLoader.dismiss();
                        }else{
                            let toast = this.toastCtrl.create({ message: 'Sorry ! something went wrong.', duration: 3000 });
                            toast.present();
                            this.otherLoader.dismiss();
                        }
                    },(err)=> {
                        this.otherLoader.dismiss();
                    });
                    });
                      return false;
                  }
                }
              ]
            });
            prompt.present();

          }
      },(err)=> {
          alert('failled '+err);
      });
    });
  }

  skip()
  {

    this.authservice.postData({'mobileno':localStorage.getItem('useremail')}, 'UpdateMobileNumberAsEmail').then((result)=>{
      if(result['response'] == 1){
        this.navCtrl.setRoot(HomePage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});   
      }
    },(err)=> {
       let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 3000 });
       toast.present();
    });

  }









}
