import { Alert } from 'ionic-angular/umd';
import { Component } from '@angular/core';
import { NavController, NavParams, App, LoadingController, ToastController } from 'ionic-angular';
import {Validators, FormGroup, FormBuilder } from '@angular/forms';
import { AuthServiceProvider } from '../../../providers/parent/auth-service/auth-service';
import { HomePage } from '../home/home';
import { SignupPage } from '../signup/signup';
import { EmailConfigurationPage } from '../email-configuration/email-configuration';
// import { Facebook, FacebookLoginResponse } from "@ionic-native/facebook";
import { global } from "../../../app/global";

//declare module '*';
//declare var RazorpayCheckout: any;

@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

  responseData: any;
  userData = {'txtemail':'', 'txtpassword':''};
  fbData = {email: '', name: '', id: '', imageurl: ''};
  emailValidation:string; passwordValidation:string; show:boolean; emailInvalid:string; passwordLength:any;
  myLoadingControl: any;loader: any;
  public loginForm : FormGroup; login_password:any; login_email:any;

  constructor(
        public navCtrl: NavController,
			  public navParams: NavParams,
			  public app: App,
			  public authservice: AuthServiceProvider,
			  public loadingCtrl: LoadingController,
			  public toastCtrl: ToastController,
        public formBuilder: FormBuilder,
        // private fb: Facebook,
			 )
  {
    
    this.myLoadingControl = loadingCtrl;
     let isUserLogin = localStorage.getItem('useremail');
     if(isUserLogin){
       this.navCtrl.setRoot(HomePage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
     }

     // login form validation
     //Validators.pattern("[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?")
     this.loginForm = this.formBuilder.group({
       login_email: ['', [Validators.required]],
       login_password: ['', [Validators.required, Validators.minLength(6)]]
     });
     this.login_email = this.loginForm.controls['login_email'];
     this.login_password = this.loginForm.controls['login_password'];


  }

  ionViewDidLoad() 
  {
    console.log('ionViewDidLoad LoginPage');
  }

  goToSignup()
  {
    this.navCtrl.push(SignupPage);
  }

  login()
  {
    this.loader = this.myLoadingControl.create({
        content : "Please wait.."
    });

    this.loader.present().then(() => {
      this.authservice.postData(this.userData, 'login').then((result)=>{
          this.responseData = result;
          if(this.responseData['response'] == 1){
            this.loader.dismiss();
            localStorage.setItem('useremail',this.userData.txtemail);

            let checkEmail = global.isValidEmail(this.userData.txtemail);
            let checkMobile = global.isValidPhone(this.userData.txtemail);
            if(checkEmail == true){
              // login with email
              this.navCtrl.setRoot(HomePage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
            }else if(checkMobile == true){
              // login with mobile number
              this.authservice.postData({'mobileno':localStorage.getItem('useremail')}, 'isEmail').then((result)=>{
                if(result['response'] == 0){
                  this.navCtrl.push(EmailConfigurationPage);
                }else if(result['response'] == 1){
                  // if login with mobile number and also available email id
                  localStorage.clear();
                  localStorage.setItem('useremail', result['sess_email']);
                  this.navCtrl.setRoot(HomePage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});               
                }
              },(err)=> {
                 let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 3000 });
                 toast.present();
              });
              
            }
          }else{
            this.loader.dismiss();
            let toast = this.toastCtrl.create({ message: this.responseData['msg'], 'cssClass':'toastText', duration: 3000 });
            toast.present();
          }
        },(err)=> {
          this.loader.dismiss();
          let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 3000 });
          toast.present();
      });
    });
  }

  /*facebookLogin(){
    this.fb.getLoginStatus().then((res: FacebookLoginResponse) => {

        if (res.status == "connected")
        {
          this.processFBLogin();
        }
        else
        {
          this.fb.login(['public_profile', 'user_friends', 'email']).then((response: FacebookLoginResponse) => {
           
            if (response.status == "connected")
            {
              this.processFBLogin();
            }

          });
        }
    });    
  }
  processFBLogin(){
    this.fb.api('me?fields=id,name,email,first_name,last_name,picture.width(720).height(720).as(picture_large)', []).then(profile => {
      this.fbData = {
        email: profile['email'], 
        name: profile['first_name'] + ' ' + profile['last_name'], 
        id: profile['id'],
        imageurl: profile['picture_large']['data']['url']
      };

      if (this.fbData.email == "")
      {
        let toast = this.toastCtrl.create({ message: "Sorry! unable to login. Please update your email id on facebook first", duration: 3000 });
        toast.present();
      }
      else
      {
        this.loader = this.myLoadingControl.create({
          content : "Please wait.."
        });
        this.loader.present().then(() => {
          this.authservice.postData(this.fbData, 'socialmedialogin').then((result)=>{
              this.responseData = result;
                
              if(this.responseData['sign_response'] == 1){
                this.loader.dismiss();
              
                localStorage.setItem('useremail',this.fbData.email);
                this.navCtrl.setRoot(HomePage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
              }else{
                this.loader.dismiss();
                let toast = this.toastCtrl.create({ message: "Sorry!unable to process request", 'cssClass':'toastText', duration: 3000 });
                toast.present();
              }
            },(err)=> {
              this.loader.dismiss();
              let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 3000 });
              toast.present();
          });
        });

      }
    },(err) => {
      this.loader.dismiss();
      let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 3000 });
      toast.present();
    });
  }*/



  
}
