import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { AuthServiceProvider } from './../../../providers/parent/auth-service/auth-service';
import { global } from "../../../app/global";


@Component({
  selector: 'page-p-curriculum',
  templateUrl: 'p-curriculum.html',
})
export class PCurriculumPage {
  items: any;
  schoolname: any;
  schoolid: any;
  studentname: any;

  constructor(
      public navCtrl: NavController,
      public navParams: NavParams,
      public authService: AuthServiceProvider,
  )
  {

    this.studentname = this.navParams.get('studentname'); 
    this.schoolid = this.navParams.get('schoolid');  
    this.schoolname = this.navParams.get('schoolname');        
    
    this.authService.postData({'schoolid':this.schoolid}, 'getSchoolCurriculum').then((result)=>{
      if(result['response'] == 1){
        this.items = result['curriculum'];
      }
    },(err)=> {
      alert('failled '+err);
    });

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PCurriculumPage');
  }





}
