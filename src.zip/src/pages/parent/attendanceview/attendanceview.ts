import { AuthServiceProvider } from './../../../providers/parent/auth-service/auth-service';
import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, LoadingController, ToastController } from 'ionic-angular';
import { CalendarComponent } from "ionic2-calendar/calendar";

@Component({
  selector: 'page-attendanceview',
  templateUrl: 'attendanceview.html',
})
export class AttendanceviewPage {
    colors: string[];
    leave: any;
    absent: any;
    present: any;

  @ViewChild(CalendarComponent) myCalendar: CalendarComponent;
  eventSource: any;
  viewTitle: string;
  selectedDay: any;
  calendar: any;
  months: string[];
  loader: any;
  postData: any;
  responseData: any;
  currentDate: any;
  startTime: any;
  endTime: any;
  studentname: any;
  

  constructor(
      public navCtrl: NavController, 
      public navParams: NavParams, 
      public myLoadingControl: LoadingController, 
      public authservice: AuthServiceProvider, 
      public toastCtrl: ToastController
    ) 
{
    this.studentname = navParams.get('studentname');
    this.loader = myLoadingControl;
    this.postData = {studentid: navParams.get('studentid'), month: 0, year: 0};
    this.eventSource = [];
    this.responseData = [];
    this.months = ['January', 'February', 'March'];
    this.viewTitle = "Feb";
    this.selectedDay = new Date();
    this.calendar = {
      dateFormatter: {
          formatMonthViewDay: function(date:Date) {
              return date.getDate().toString();
          },
          formatMonthViewTitle: function(date:Date) {
              let monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'Octomber', 'November', 'December'];
              this.selectedDay = date;
              return monthNames[date.getMonth()] + '-' + date.getFullYear();
          },
          formatWeekViewDayHeader: function(date:Date) {
              return 'testWDH';
          },
          formatWeekViewTitle: function(date:Date) {
              return this.months[1];
          },
          formatWeekViewHourColumn: function(date:Date) {
              return 'testWH';
          },
          formatDayViewHourColumn: function(date:Date) {
              return 'testDH';
          },
          formatDayViewTitle: function(date:Date) {
              return 'testDT';
          }
      },
      mode: 'month',
      currentDate: new Date(),
      noEventsLabel: '',
      showEventDetail: false
    }
}

  loadAttendance(){
      //let calDate = this.calendar.currentDate;
    this.postData = {studentid: this.navParams.get('studentid'), month: this.selectedDay.getMonth()+1, year: this.selectedDay.getFullYear()};
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.eventSource = [];
    
    this.present = '';
    this.absent = '';
    this.leave = '';    
    this.colors = [''];

    this.loader.present().then(() => {
      this.authservice.postData(this.postData, 'getStudentAttendance').then((result)=>{
  		this.responseData = result;
  		if(this.responseData['response'] == 1){
            try {
                this.present = this.responseData['attendance'][0]['present'];
                this.absent = this.responseData['attendance'][0]['absent']; 
                this.leave = this.responseData['attendance'][0]['onleave'];                                
                let newDate = new Date();
                let eventType = Math.floor(Math.random() * 2);
                let startDay = Math.floor(Math.random() * 90) - 45;
                let endDay = Math.floor(Math.random() * 2) + startDay;

                for(let data of this.responseData['attendance'])
                {
                    if(data['reason'] == ''){
                        var clr = 'success';
                    }else if(data['reason'] == 'Absent'){
                        var clr = 'danger';
                    }else if(data['reason'] != 'Absent' && data['reason'] != ''){
                        var clr = 'warning';
                    }else{
                        var clr = '#fff';
                    }
                    
                    this.colors = [clr];
                    
                    newDate = new Date(data['cdate']);
                    let startTime = new Date(Date.UTC(newDate.getFullYear(), newDate.getMonth(), newDate.getDate()));
                    let endTime = new Date(Date.UTC(newDate.getFullYear(), newDate.getMonth(), newDate.getDate()+1));
                    this.eventSource.push({
                        title: 'Present',
                        startTime: startTime,
                        endTime: endTime,
                        allDay: true,
                        color: this.colors[Math.floor(Math.random()*this.colors.length)]
                    });
                    
                    console.log(this.eventSource);
                    //this.calendar.loadEvents();
                }
                this.loader.dismiss();
            } catch (error) {
                let toast = this.toastCtrl.create({
                    message: error + '',
                    duration: 3000
                });
                toast.present();
                this.loader.dismiss();
            }            
            
  		}else{
            this.loader.dismiss();
  		}

        this.myCalendar.loadEvents();
  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismiss();
  	  });

        
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AttendanceviewPage');
  }

  onRangeChanged(sTime, eTime){
    this.selectedDay = this.myCalendar.currentDate;
    this.loadAttendance();
  }

  onEventSelected(event)
  {
  }

  onViewTitleChanged(title){
    this.viewTitle = title;    
  }

  onTimeSelected(event){
  }

  onCurrentDateChanged(event){
  }


}
