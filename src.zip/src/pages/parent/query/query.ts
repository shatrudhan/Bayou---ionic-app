import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, ToastController, AlertController, ModalController } from 'ionic-angular';
import { QueryformPage } from '../queryform/queryform';

import { AuthServiceProvider } from './../../../providers/parent/auth-service/auth-service';
// import { global } from "../../../app/global";
import { QuerydetailPage } from '../querydetail/querydetail';

//  class 1 started from here //
@Component({
  selector: 'page-query',
  templateUrl: 'query.html',
})

export class QueryPage {
  studentname: any;

schoolid:number; classid:number; sectionid:number; studentid:number;
queries:any;

  constructor(
              public navCtrl: NavController,
              public navParams: NavParams,
              public toastCtrl: ToastController,
              public authservice: AuthServiceProvider,
              public loadingCtrl: LoadingController,
              public alertCtrl: AlertController,
              public modalCtrl: ModalController
             )
  {
    this.studentname = this.navParams.get('studentname');
    this.schoolid = navParams.get('schoolid');
    this.studentid = navParams.get('studentid');
    this.classid = navParams.get('classid');
    this.sectionid = navParams.get('sectionid');

    this.parentQueries();

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad QueryPage');
  }

  // getting queries of parents
  parentQueries()
  {
    this.authservice.postData({ 'email': localStorage.getItem('useremail'), 'schoolid':this.schoolid, 'studentid':this.studentid}, 'getAllParentQueries').then((result)=>{
        this.queries = result['queries'];
     },(err)=> {
       alert('failled '+err);
     });
  }

  // on click event which is using to open a MODAL
  addQuery()
  {
    let QueryFormModal = this.modalCtrl.create(QueryformPage , { 'studentid': this.studentid, 'classid': this.classid, 'sectionid':this.sectionid, 'schoolid': this.schoolid, 'queryClassObj':this });
    QueryFormModal.present();
  }

  replyToTeacher(msgid)
  {
    this.navCtrl.push(QuerydetailPage , {messageid: msgid, 'schoolid':this.schoolid});
  }

};
