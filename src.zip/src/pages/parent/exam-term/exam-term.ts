import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, ToastController } from 'ionic-angular';
import { AuthServiceProvider } from './../../../providers/parent/auth-service/auth-service';
import { ReportCardPage } from '../report-card/report-card';


@Component({
  selector: 'page-exam-term',
  templateUrl: 'exam-term.html',
})
export class ExamTermPage {
  studentname: any;
  termExamArray: Array<{ termid: number, termname: string, exams: any, examid: number  }>;
  allExams: any;
  allExamTerms: any;

  loader: any; myLoadingControl: any;
  schoolid: any; studentid: any; classid: any; sectionid: any;

  constructor(
      public navCtrl: NavController,
      public navParams: NavParams,
      public authservice: AuthServiceProvider,
      public loadingCtrl: LoadingController,
      public toastCtrl: ToastController,
  )
  {
    this.studentname = this.navParams.get('studentname');
    this.schoolid = this.navParams.get('schoolid');
    this.studentid = this.navParams.get('studentid');
    this.classid = this.navParams.get('classid');
    this.sectionid = this.navParams.get('sectionid');
    
    this.myLoadingControl = loadingCtrl;

    this.getAllExamTermsBySchool();
    this.termExamArray = [];
    
  }

  getAllExamTermsBySchool()
  {
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {
      this.authservice.postData({'schoolid':this.schoolid}, 'getAllSchoolExamTerms').then((result)=>{
        if(result['response'] == 1){
          this.allExamTerms = result['terms'];
          this.allExams = result['exams']; 

          for(let val of result['terms'])
          {
            this.termExamArray.push({
              termid: val['tid'],
              termname: val['termname'], 
              exams: this.allExams,
              examid: 0
            });
          }
          console.log(this.termExamArray);

          this.loader.dismiss();
        }else{
          let toast = this.toastCtrl.create({ message: 'Sorry ! no data found.', 'cssClass':'toastText', duration: 3000 });
          toast.present();
          this.loader.dismiss();
        }
    	},(err)=> {
        let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 3000 });
        toast.present();
        this.loader.dismiss();
    	});
    });
  }

  goToReportCard(i)
  {
    //let toast = this.toastCtrl.create({ message: 'termid :'+this.termExamArray[i].termid+' , examid :'+this.termExamArray[i].examid, 'cssClass':'toastText', duration: 3000 });
    //toast.present();
   if(this.termExamArray[i].examid == 0){
    let toast = this.toastCtrl.create({ message: 'Select exam name first !', 'cssClass':'toastText', duration: 3000 });
    toast.present();
   }else{
    this.navCtrl.push(ReportCardPage , {schoolid: this.schoolid, studentid: this.studentid, classid: this.classid, sectionid: this.sectionid, 'termid':this.termExamArray[i].termid, 'examid':this.termExamArray[i].examid });
   }
  }

  ionViewDidLoad() 
  {
    console.log('ionViewDidLoad ExamTermPage');
  }

}
