import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { AuthServiceProvider } from './../../../providers/parent/auth-service/auth-service';
import { global } from "../../../app/global";

@Component({
  selector: 'page-p-latest-news',
  templateUrl: 'p-latest-news.html',
})
export class PLatestNewsPage {
  latestnews: any;
  schoolname: any;
  schoolid: any;
  studentname: any;

  constructor(
      public navCtrl: NavController,
      public navParams: NavParams,
      public authService: AuthServiceProvider,
  )
  {

    this.studentname = this.navParams.get('studentname'); 
    this.schoolid = this.navParams.get('schoolid');  
    this.schoolname = this.navParams.get('schoolname');        
    
    this.authService.postData({'schoolid':this.schoolid}, 'getSchoolLatestNews').then((result)=>{
      if(result['response'] == 1){
        this.latestnews = result['latestnews'];
      }
    },(err)=> {
      alert('failled '+err);
    });

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PLatestNewsPage');
  }

}
