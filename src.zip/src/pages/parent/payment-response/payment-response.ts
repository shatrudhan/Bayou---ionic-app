import { Component } from '@angular/core';
import { NavController, NavParams, ViewController, LoadingController, ToastController } from 'ionic-angular';
import { AuthServiceProvider } from './../../../providers/parent/auth-service/auth-service';
import { global } from "../../../app/global";
import { FeePage } from '../fee/fee';

@Component({
  selector: 'page-payment-response',
  templateUrl: 'payment-response.html',
})
export class PaymentResponsePage {
  schoollogopath: any;
  txdate: any;
  
  successDivShow: boolean;
  alertDivShow: boolean;
  success: boolean;
  
  address1: any; address2: any; city: any; address: any; fathername: any; mobile: any; email: any; schoolname: any; studentname: any;
  amount: any; feetitle: any; feeid: any; sectionid: any; classid: any; studentid: any; schoolid: any; transactionid: any; status: any;
  loader: any;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public authservice: AuthServiceProvider,
    public loadingCtrl: LoadingController,
    public toastCtrl: ToastController,
    public viewCtrl: ViewController,
  )
  {

    this.status  = this.navParams.get('status');
    this.transactionid  = this.navParams.get('transactionid');
    this.schoolid  = this.navParams.get('schoolid');
    this.studentid  = this.navParams.get('studentid');
    this.classid  = this.navParams.get('classid');
    this.sectionid  = this.navParams.get('sectionid');
    this.feeid  = this.navParams.get('feeid');
    this.feetitle  = this.navParams.get('feetitle');
    this.amount  = this.navParams.get('amount');
    this.email  = this.navParams.get('email');
    this.mobile  = this.navParams.get('mobile');
    this.fathername  = this.navParams.get('fathername');
    this.address  = this.navParams.get('address');
    this.address1  = this.navParams.get('address1');
    this.address2  = this.navParams.get('address2');
    this.city  = this.navParams.get('city');
    this.studentname  = this.navParams.get('studentname');
    this.schoolname  = this.navParams.get('schoolname');
    this.schoollogopath  = this.navParams.get('schoollogopath');    
    
    
    this.loader = this.loadingCtrl.create({
      spinner: `hide`,
      enableBackdropDismiss: false,
      content: `
              <div class="row">
                <div class="col-md-3">
                  <img src="assets/images/processing_payment_loader.svg" />
                </div>
                <div class="col-md-9">
                  <div class="processing_fee_content"><b>Processing Payment...</b></div> 
                </div>
              </div>`,
      //duration: 10000
    });
    this.loader.present();

    this.alertDivShow = true;
    this.successDivShow = false;
    
    setInterval(()=>{
      this.onSuccess();
    },3000);

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PaymentResponsePage');
  }

  // on success condition
  onSuccess()
  {
    this.loader.present().then(() => {

      if(this.transactionid != 'undefined' && this.transactionid != ''){
        // success
        // update student data in tblpaymentstatus
        this.authservice.postData({'txid':this.transactionid, 'amount':this.amount*100}, 'RazorResponseCapture').then((result)=>{
          if(result['response'] == 1){
            //console.log(result['capturedResponse']);
            if(result['RazorStatus'] == 'captured'){
              let Rdata = {
                            'transactionid':this.transactionid,
                            'status':'success',
                            'schoolid':this.schoolid,
                            'studentid':this.studentid,
                            'classid':this.classid,
                            'sectionid':this.sectionid,
                            'feeid':this.feeid,
                            'feetitle':this.feetitle,
                            'amount':this.amount,
                            'email':this.email,
                            'mobile':this.mobile,
                            'fathername':this.fathername,
                            'address':this.address,
                            'address1':this.address1,
                            'address2':this.address2,
                            'city':this.city,
                            'studentname':this.studentname,
                            'schoolname':this.schoolname,
                            'schoollogopath':this.schoollogopath,
                            'paymentdate':result['RazorTransDate']
                          }
              this.authservice.postData(Rdata, 'UpdateFeeByRazorPay').then((result)=>{
                  if(result['response'] == 1){
                    let toast = this.toastCtrl.create({ message: 'Payment updated successfully !' , duration: 5000 });
                    toast.present();
                  }else{
                    let toast = this.toastCtrl.create({ message: 'Failled to update student fee !' , duration: 5000 });
                    toast.present();
                  }
              },(err)=> {
                alert('failled '+err);
              }); 

              this.txdate = result['RazorTransDate'];
              this.successDivShow = true;
              this.alertDivShow = false;
              this.loader.dismiss();

            }
          }else{
            alert('response 0');
          }
        },(err)=> {
          alert('failled '+err);
        });       
      }

    });
  }

  // ok press on success page
  gotoback()
  {
    this.viewCtrl.dismiss();
  }
  



}
