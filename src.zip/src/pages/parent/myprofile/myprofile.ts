import { Component } from '@angular/core';
import { NavController, ActionSheetController, Platform, NavParams, LoadingController, ToastController, ModalController, ViewController, Loading } from 'ionic-angular';
import {Validators, FormGroup, FormBuilder } from '@angular/forms';
import { AuthServiceProvider } from './../../../providers/parent/auth-service/auth-service';
import { global } from "../../../app/global";
import { HomePage } from '../home/home';

import { File } from '@ionic-native/file';
import { Transfer, TransferObject } from '@ionic-native/transfer';
import { FilePath } from '@ionic-native/file-path';
import { Camera } from '@ionic-native/camera';
import { Crop } from '@ionic-native/crop';

/************************* CLASS 1 ************************************/

declare var cordova: any;

@Component({
  selector: 'page-myprofile',
  templateUrl: 'myprofile.html',
})
export class MyprofilePage {
  // userPhoto: any;

  ribluBaseurl: any;
  useremail:any;
  userData = {'useremail':localStorage.getItem('useremail')};
  profileInfoA: any = [];

  lastImage: string = null;
  loading: Loading;
  loader: any;
  myLoadingControl: any;
  
  constructor(
              public navCtrl: NavController,
              public navParams: NavParams,
              public authservice: AuthServiceProvider,
              public loadingCtrl: LoadingController,
              public toastCtrl: ToastController,
              public modalCtrl: ModalController,
              public viewCtrl: ViewController,  
              public formBuilder: FormBuilder,
              public camera: Camera,
              public transfer: Transfer, 
              public file: File, 
              public filePath: FilePath, 
              public actionSheetCtrl: ActionSheetController, 
              public platform: Platform,
              public cropCtrl: Crop
             )
  {
     if(!localStorage.getItem('useremail')){
       this.navCtrl.setRoot(HomePage);
     }

    this.myLoadingControl = loadingCtrl;
    this.ribluBaseurl = global.ribbluBasePath;
    this.profileInformationA();

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MyprofilePage');
  }

  // GETTING PROFILE INFORMATION
  profileInformationA()
  {
    this.loader = this.myLoadingControl.create({
        content : "Please wait.."
    });

    this.loader.present().then(() => {
      this.authservice.postData(this.userData, 'getProfileInfo').then((result)=>{
        this.profileInfoA = result['profile_info'];
        // this.userPhoto = this.profileInfoA.profilephoto.substring(this.profileInfoA.profilephoto.lastIndexOf('/') + 1, this.profileInfoA.profilephoto.length )
        // alert(this.userPhoto);
        this.loader.dismiss();
        if(result['profile_info'] == 0){
          let toast = this.toastCtrl.create({ message: 'Please update your profile !', 'cssClass':'toastText', duration: 5000 });
          toast.present();
        }
      },(err)=> {
        let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 5000 });
        toast.present();
        this.loader.dismiss();
      });
    });
  }

  // EDIT PROFILE INFORMATION
  editProfile()
  {
    let modal = this.modalCtrl.create(EditprofilePage, {'myProfilePageObj': this});
    modal.present();
  }

  /********************  PROFILE PHOTO UPLOAD STARTING HERE  ******************/

  setProfilePhoto() {
    let actionSheet = this.actionSheetCtrl.create({
      title: 'Select Profile Photo',
      buttons: [
        {
          text: 'Choose Gallery',
          handler: () => {
            this.takePicture(this.camera.PictureSourceType.PHOTOLIBRARY);
          }
        },
        {
          text: 'Use Camera',
          handler: () => {
            this.takePicture(this.camera.PictureSourceType.CAMERA);
          }
        },
        {
          text: 'Cancel',
          role: 'cancel'
        }
      ]
    });
    actionSheet.present();
  }

  public takePicture(sourceType) {
    // Create options for the Camera Dialog
    var options = {
      quality: 100,
      sourceType: sourceType,
      saveToPhotoAlbum: false,
      correctOrientation: true
    };
   
    // Get the data of an image
    this.camera.getPicture(options).then((imagePath) => {
      // Special handling for Android library
      if (this.platform.is('android') && sourceType === this.camera.PictureSourceType.PHOTOLIBRARY) {
        this.filePath.resolveNativePath(imagePath)
          .then(filePath => {

            this.cropCtrl.crop(filePath, {quality: 100}).then(newImage => {

              let correctPath = newImage.substr(0, newImage.lastIndexOf('/') + 1);
              let currentName = newImage.substring(newImage.lastIndexOf('/') + 1, newImage.lastIndexOf('?'));
              this.copyFileToLocalDir(correctPath, currentName, this.createFileName());

            });

            
          });
      } 
      else if (this.platform.is('ios') && sourceType === this.camera.PictureSourceType.PHOTOLIBRARY) {
        //this.filePath.resolveNativePath(imagePath)
          //.then(filePath => {

            this.cropCtrl.crop(imagePath, {quality: 100}).then(newImage => {

              let correctPath = newImage.substr(0, newImage.lastIndexOf('/') + 1);
              let currentName = imagePath.substring(imagePath.lastIndexOf('/') + 1, imagePath.lastIndexOf('?'));
              this.copyFileToLocalDir(correctPath, currentName, this.createFileName());
         
            });

            
          //});
      } 
      else if (this.platform.is('android') && sourceType === this.camera.PictureSourceType.CAMERA)
      {
        

        this.cropCtrl.crop(imagePath, {quality: 100}).then(newImage => {
          
          this.presentToast(newImage);
          var currentName = newImage.substr(newImage.lastIndexOf('/') + 1);
          currentName = currentName.substr(0, currentName.lastIndexOf("?"));
          var correctPath = newImage.substr(0, newImage.lastIndexOf('/') + 1);
          this.copyFileToLocalDir(correctPath, currentName, this.createFileName());

        });

      }
      else 
      {
        

        this.cropCtrl.crop(imagePath, {quality: 100}).then(newImage => {

          this.presentToast(newImage);
          var currentName = newImage.substr(newImage.lastIndexOf('/') + 1);
          var correctPath = newImage.substr(0, newImage.lastIndexOf('/') + 1);
          this.copyFileToLocalDir(correctPath, currentName, this.createFileName());

        });

      }
    }, (err) => {
      this.presentToast('Error while selecting image.');
    });
  }

  // Create a new name for the image
  public createFileName() {
  var d = new Date(),
  n = d.getTime(),
  newFileName =  n + ".jpg";
  return newFileName;
}
 
// Copy the image to a local folder
public copyFileToLocalDir(namePath, currentName, newFileName) {
  this.file.copyFile(namePath, currentName, cordova.file.dataDirectory, newFileName).then(success => {
    this.lastImage = newFileName;
    this.uploadImage();
  }, error => {
    //this.presentToast('Error while storing file.' + error);
  });
}
 
public presentToast(text) {
  let toast = this.toastCtrl.create({
    message: text,
    duration: 3000,
    position: 'bottom'
  });
  toast.present();
}
 
// Always get the accurate path to your apps folder
public pathForImage(img) {
  if (img === null) {
    return '';
  } else {
    return cordova.file.dataDirectory + img;
  }
}

public uploadImage() {
    // Destination URL
    let url = global.apiUserUrl+'profilePhotoUpload';

    // File for Upload
    var targetPath = this.pathForImage(this.lastImage);
    
    // File name only
    var filename = this.lastImage;
    
    var options = {
      fileKey: "file",
      fileName: filename,
      chunkedMode: false,
      mimeType: "multipart/form-data",
      params : {'fileName': filename, 'usermail': localStorage.getItem('useremail')}
    };
    
    const fileTransfer: TransferObject = this.transfer.create();
    
    this.loading = this.loadingCtrl.create({
      content: 'Uploading...',
    });
    this.loading.present();
    
    // Use the FileTransfer to upload the image
    fileTransfer.upload(targetPath, url, options ).then((data) => {
      this.loading.dismissAll();
      this.profileInformationA(); 
      this.presentToast('Uploaded successfully');  
    }, err => {
      this.loading.dismissAll();
      this.presentToast('Something went wrong, Try again.');
      this.profileInformationA();
    });

  }

  dismiss() 
  {
    this.viewCtrl.dismiss();
  }

/********************  PROFILE PHOTO UPLOAD ENDS HERE  ******************/









}


/************************* CLASS 2 ************************************/

@Component({
  selector: 'page-myprofile',
  template: `<ion-header>
              <ion-toolbar>
                <ion-title>
                  Update Profile
                </ion-title>
                <ion-buttons start>
                  <button ion-button (click)="modalDismiss()">
                    <span ion-text color="primary" showWhen="ios">Cancel</span>
                    <ion-icon name="md-close" showWhen="android,windows"></ion-icon>
                  </button>
                </ion-buttons>
              </ion-toolbar>
            </ion-header>

            <ion-content>

              <form [formGroup]="updateProfileForm" (ngSubmit)="updateProfileInfo()">

                  <ion-list>

            <ion-row align-items-start>
            <ion-col col-3>

            <div>
              <ion-item no-lines>
                <ion-label floating>Title</ion-label>
                <ion-select formControlName="txt_title" name="txt_title" [(ngModel)]="upPro.txt_title">
                <ion-option value="Mr." >Mr.</ion-option>
                <ion-option value="Miss">Miss</ion-option>
                <ion-option value="Mrs.">Mrs.</ion-option>
                </ion-select>
              </ion-item>
              <div *ngIf="txt_title.hasError('required') && txt_title.touched" class="val-err">
                  Title required !
              </div>
            </div>

            </ion-col>
            <ion-col col-9>

            <div>
              <ion-item no-lines>
                <ion-label floating>Name</ion-label>
                <ion-input formControlName="txt_name" type="text" name="txt_name" [(ngModel)]="upPro.txt_name"></ion-input>
              </ion-item>
              <div *ngIf="txt_name.hasError('required') && txt_name.touched" class="val-err">
                  Name required !
              </div>
              <div *ngIf="txt_name.hasError('pattern') && txt_name.touched" class="val-err">
                  Numerical value not allowed !
              </div>
            </div>

            </ion-col>
            </ion-row>

            <ion-row align-items-start>
            <ion-col>

            <div>
              <ion-item no-lines>
                <ion-label floating>Mobile No.</ion-label>
                <ion-input formControlName="txt_mobileno" type="number" name="txt_mobileno" [(ngModel)]="upPro.txt_mobileno"></ion-input>
              </ion-item>

              <div *ngIf="txt_mobileno.hasError('required') && txt_mobileno.touched" class="val-err">
                  Mobile no required !
              </div>
              <div *ngIf="txt_mobileno.hasError('pattern') && txt_mobileno.touched" class="val-err">
                  Only numbers allowed !
              </div>
              <div *ngIf="txt_mobileno.hasError('minlength') || txt_mobileno.hasError('maxlength') && txt_mobileno.touched" class="val-err">
                  Mobile number should be 10 digit !
              </div>
            </div>

            </ion-col>
            <ion-col>

            <div>
              <ion-item no-lines>
                <ion-label floating>Phone No.</ion-label>
                <ion-input formControlName="txt_phoneno" type="number" name="txt_phoneno" [(ngModel)]="upPro.txt_phoneno"></ion-input>
              </ion-item>
              <div *ngIf="txt_phoneno.hasError('required') && txt_phoneno.touched" class="val-err">
                  Phone number required !
              </div>
              <div *ngIf="txt_phoneno.hasError('pattern') && txt_phoneno.touched" class="val-err">
                  Only numbers allowed !
              </div>
            </div>

            </ion-col>
            </ion-row>

            <ion-row align-items-start>
            <ion-col>

            <div>
              <ion-item no-lines>
                <ion-label floating>Pincode</ion-label>
                <ion-input formControlName="txt_pincode" type="number" name="txt_pincode" [(ngModel)]="upPro.txt_pincode"></ion-input>
              </ion-item>
              <div *ngIf="txt_pincode.hasError('required') && txt_pincode.touched" class="val-err">
                  Pincode required !
              </div>
              <div *ngIf="txt_pincode.hasError('pattern') && txt_pincode.touched" class="val-err">
                  Only numbers allowed !
              </div>
              <div *ngIf="txt_pincode.hasError('minlength') || txt_pincode.hasError('maxlength') && txt_pincode.touched" class="val-err">
                  Pincode should be 6 digit !
              </div>
            </div>

            </ion-col>
            <ion-col>

            <div>
              <ion-item no-lines>
                <ion-label floating>City</ion-label>
                <ion-input formControlName="txt_city" type="text" name="txt_city" [(ngModel)]="upPro.txt_city"></ion-input>
              </ion-item>
              <div *ngIf="txt_city.hasError('required') && txt_city.touched" class="val-err">
                  City name required !
              </div>
              <div *ngIf="txt_city.hasError('pattern') && txt_city.touched" class="val-err">
                  Numbers not allowed !
              </div>
            </div>

            </ion-col>
            </ion-row>

            <ion-row align-items-start>
            <ion-col>

            <div>
              <ion-item no-lines>
                <ion-label floating>Address</ion-label>
                <ion-input formControlName="txt_address" type="text" name="txt_address" [(ngModel)]="upPro.txt_address"></ion-input>
              </ion-item>	
              <div *ngIf="txt_address.hasError('required') && txt_address.touched" class="val-err">
                  Address required !
              </div>  
            </div>
          
            </ion-col>
            </ion-row>

            <ion-row align-items-start>
            <ion-col>

            <div>
              <ion-item no-lines>
                <ion-label floating>State</ion-label>
                <ion-select formControlName="txt_state" name="txt_state" [(ngModel)]="upPro.txt_state">
                <ion-option *ngFor="let state of states" [value]="state.statename" >{{state.statename}}</ion-option>
                </ion-select>
              </ion-item>
              <div *ngIf="txt_state.hasError('required') && txt_state.touched" class="val-err">
                  State name required !
              </div>
            </div>

            </ion-col>
            <ion-col>

            <div>
              <ion-item no-lines>
                <ion-label floating>Country</ion-label>
                <ion-select formControlName="txt_country" name="txt_country" [(ngModel)]="upPro.txt_country">
                <ion-option *ngFor="let country of countries" [value]="country.CountryName" >{{country.CountryName}}</ion-option>
                </ion-select>
              </ion-item>
              <div *ngIf="txt_country.hasError('required') && txt_country.touched" class="val-err">
                  Country name required !
              </div>
            </div>

            </ion-col>
            </ion-row>
                    
                  </ion-list>

                  <div style="padding-left: 15px;padding-right:0px;">
                    <button ion-button block type="submit" [disabled]="updateProfileForm.invalid" >Update Profile</button>
                  </div>

                </form>

            </ion-content>
            `
})


export class EditprofilePage {
  
   useremail: any = localStorage.getItem('useremail');
   profileId: number;
   states:string; countries:string;
   userData = {'useremail':localStorage.getItem('useremail')};
   upPro = {'txt_title':'', 'txt_name':'', 'txt_phoneno':'', 'txt_mobileno':'', 'txt_address':'', 'txt_pincode':'', 'txt_city':'', 'txt_state':'', 'txt_country':'', 'email':localStorage.getItem('useremail'), 'detailId':0};
   profileInfoB: any;
   refreshMyProfile: any;
   public updateProfileForm : FormGroup;
   txt_country: any; txt_state: any; txt_address: any; txt_pincode: any; txt_city: any; txt_phoneno: any; txt_mobileno: any; txt_title: any; txt_name: any;
   loader: any;
   myLoadingControl: any;
  constructor(
              public navCtrl: NavController,
              public navParams: NavParams,
              public authservice: AuthServiceProvider,
              public loadingCtrl: LoadingController,
              public toastCtrl: ToastController,
              public modalCtrl: ModalController,
              public viewCtrl: ViewController,
              public formBuilder: FormBuilder,
              public camera: Camera,
              public transfer: Transfer, 
              public file: File, 
              public filePath: FilePath, 
              public actionSheetCtrl: ActionSheetController, 
              public platform: Platform,
             )
  {
    
    this.myLoadingControl = loadingCtrl;
    // update form validation
    this.updateProfileForm = this.formBuilder.group({
      txt_title: ['', [Validators.required]],
      txt_name: ['',[Validators.required, Validators.pattern("[a-zA-Z][a-zA-Z ]+")]],
      txt_mobileno: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern("[0-9]*")]],
      txt_phoneno: ['', [Validators.required, Validators.pattern("[0-9]*")]],
      txt_city: ['',[Validators.required, Validators.pattern("[a-zA-Z][a-zA-Z ]+")]],
      txt_pincode: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(6), Validators.pattern("[0-9]*")]],
      txt_address: ['', [Validators.required]],
      txt_state: ['', [Validators.required]],
      txt_country: ['', [Validators.required]]
    });
      this.txt_title = this.updateProfileForm.controls['txt_title'];
      this.txt_name = this.updateProfileForm.controls['txt_name'];
      this.txt_mobileno = this.updateProfileForm.controls['txt_mobileno'];
      this.txt_phoneno = this.updateProfileForm.controls['txt_phoneno'];
      this.txt_city = this.updateProfileForm.controls['txt_city'];
      this.txt_pincode = this.updateProfileForm.controls['txt_pincode'];
      this.txt_address = this.updateProfileForm.controls['txt_address'];
      this.txt_state = this.updateProfileForm.controls['txt_state'];
      this.txt_country = this.updateProfileForm.controls['txt_country'];
      
    

    this.profileId = this.navParams.get('profileId');
    this.upPro.detailId = this.navParams.get('profileId');

    this.refreshMyProfile = navParams.get('myProfilePageObj');

    this.profileInfoB = [];
    this.profileInformationB();
    this.allStates();
    this.allCountries();

  }

  modalDismiss()
  {
    this.viewCtrl.dismiss();
  }

  // GETTING ALL STATES
  allStates()
  {
    this.authservice.postData('','getAllStates').then((result)=>{
    this.states = result['allstates'];
    },(err)=> {
      alert('failled : '+err);
    });
  }

  // GETTING ALL COUNTRIES
  allCountries()
  {
    this.authservice.postData('','getAllCountries').then((result)=>{
    this.countries = result['countries'];
    },(err)=> {
      alert('failled : '+err);
    });
  }

  // GETTING PROFILE INFORMATION
  profileInformationB()
  {
    this.loader = this.myLoadingControl.create({
        content : "Please wait.."
    });

    this.loader.present().then(() => {
      this.authservice.postData(this.userData, 'getProfileInfo').then((result)=>{

          this.profileInfoB = result['profile_info'];
          
          this.upPro.txt_title = this.profileInfoB.title;       
          this.upPro.txt_name = this.profileInfoB.name;
          this.upPro.txt_mobileno = this.profileInfoB.mobileno;
          this.upPro.txt_phoneno = this.profileInfoB.phoneno;
          this.upPro.txt_address = this.profileInfoB.address;
          this.upPro.txt_pincode = this.profileInfoB.pincode;
          this.upPro.txt_city = this.profileInfoB.city;
          this.upPro.txt_state = this.profileInfoB.state;
          this.upPro.txt_country = this.profileInfoB.country;

          this.loader.dismiss();

      },(err)=> {
        let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 5000 });
        toast.present();
        this.loader.dismiss();
      });
    });
  }

  updateProfileInfo()
  {
    this.loader = this.myLoadingControl.create({
        content : "Please wait.."
    });

    this.loader.present().then(() => {
      this.authservice.postData(this.upPro, 'updateProfileInfo').then((result)=>{
        let updated = result;
        if(updated['response'] == 1){
          this.loader.dismiss();
          let toast = this.toastCtrl.create({ message: updated['msg'], 'cssClass':'toastText', duration: 5000 });
          toast.present();
          this.modalDismiss();
          this.refreshMyProfile.profileInformationA();
        }else{
          this.loader.dismiss();
          let toast = this.toastCtrl.create({ message: updated['msg'], 'cssClass':'toastText', duration: 5000 });
          toast.present();
          this.refreshMyProfile.profileInformationA();
        }
      },(err)=> {
        let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 5000 });
        toast.present();
        this.loader.dismiss();
      });
    });
  }
  





}

