import { Component } from '@angular/core';
import { AlertController, NavController, NavParams, ModalController, ViewController, LoadingController, ToastController } from 'ionic-angular';
import { InAppBrowser } from '@ionic-native/in-app-browser';
import { PaymentResponsePage } from '../payment-response/payment-response';
import { UserPage } from '../user/user';
import { AuthServiceProvider } from './../../../providers/parent/auth-service/auth-service';
import { global } from "../../../app/global";

@Component({
  selector: 'page-studentfee',
  templateUrl: 'studentfee.html',
})
export class StudentfeePage {
  isParentTrueOrFalse: boolean;
  studentschoolname: any;

  sectionid: any; classid: any; schoolid: any; studentid: any;
  userData : any;
  feeCount:number;
  totalAmount:number; school_id:number; student_id:number; class_id:number; section_id:number; emailid:any; fathername:string; address:any; city:string; state:string; pincode:number; mobile_no:number;
  childfee: any; isParent: any;
  hash_string:any; hash:any; mkey:any; txnid:any; e_feeid:number; e_studentid:number; e_schoolid:number;
  email: any;

  
  /*options : InAppBrowserOptions = {
      location : 'yes',//Or 'no'
      hidden : 'no', //Or  'yes'
      clearcache : 'yes',
      clearsessioncache : 'yes',
      zoom : 'yes',//Android only ,shows browser zoom controls
      hardwareback : 'yes',
      mediaPlaybackRequiresUserAction : 'no',
      shouldPauseOnSuspend : 'no', //Android only
      closebuttoncaption : 'Close', //iOS only
      disallowoverscroll : 'no', //iOS only
      toolbar : 'yes', //iOS only
      enableViewportScale : 'no', //iOS only
      allowInlineMediaPlayback : 'no',//iOS only
      presentationstyle : 'pagesheet',//iOS only
      fullscreen : 'yes',//Windows only
  };*/

  constructor(
              public navCtrl: NavController, 
              public navParams: NavParams, 
              public loadingCtrl: LoadingController, 
              public authService: AuthServiceProvider,
              public toastCtrl: ToastController,
              public theInAppBrowser: InAppBrowser,
              public modalCtrl: ModalController, 
              public viewCtrl: ViewController,
              public alertCtrl: AlertController,                            
             ) 
  {

    this.studentid = navParams.get('studentid');
    this.schoolid = navParams.get('schoolid');
    this.classid = navParams.get('classid');
    this.sectionid = navParams.get('sectionid');
    this.isParent = navParams.get('chkValue');
    
    this.userData = { 'studentid': this.studentid,
                      'classid': this.classid,
                      'sectionid': this.sectionid,
                      'schoolid': this.schoolid,
                      'status': 0
                    };
    this.childFeeDefault(); 

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad StudentfeePage');
  }

  childFeeDefault()
  {
      this.authService.postData(this.userData, 'childFeeInfo').then((result)=>{
      this.childfee = result['feeinfo'];
      // getting sum of amount from result
      let total = 0;
      for (var i = 0; i < this.childfee.length; i++) {
          if (this.childfee[i].amount) {
              total+=parseInt(this.childfee[i].amount);
          }
      }
      this.totalAmount = total;
      // binding some values outside the ngfor loop or result in view (html) page
      this.feeCount = this.childfee.length;
      if(this.feeCount > 0){

        this.school_id = this.childfee[0].schoolid;
        this.student_id = this.childfee[0].studentid;
        this.class_id = this.childfee[0].classid;
        this.section_id = this.childfee[0].sectionid;
        this.emailid = this.childfee[0].emailid;
        this.fathername = this.childfee[0].fathername;
        this.address = this.childfee[0].address;
        this.city = this.childfee[0].city;
        this.state = this.childfee[0].state;
        this.pincode = this.childfee[0].pincode;
        this.mobile_no = this.childfee[0].mobile_no;
      }
    },(err)=> {
      alert('failled '+err);
    });
  }

  // fee submission process (total)
  /*payAllFee()
  {
    if(this.isParent === true){
      this.email = localStorage.getItem('useremail');
    }else{
      this.email = this.emailid;
    }

    let payUmoneyAction = global.payUmoneyAction;
    this.userData = { 'totalAmount': this.totalAmount, 'studentid': this.studentid, 'schoolid': this.schoolid, 'classid': this.classid, 'sectionid': this.sectionid,   'email': this.email, 'mobile': this.mobile_no, 'fathername': this.fathername};
    this.authService.postData(this.userData, 'iPaymentTotal').then((result)=>{
      this.hash_string = result['hash_string'];
      this.hash = result['hash'];
      this.mkey = result['MERCHANT_KEY'];
      this.txnid = result['txnid'];
      this.e_feeid = result['e_feeid'];
      this.e_studentid = result['e_studentid'];
      this.e_schoolid = result['e_schoolid'];

      let target = "_blank";

      var pageContent = '<html><head></head><body><form id="ipayment" action="'+payUmoneyAction+'" method="post">' +

      '<input type="hidden" id="h_schoolid" value="'+this.schoolid+'"/>'+
      '<input type="hidden" id="h_classid" value="'+this.classid+'"/>'+
      '<input type="hidden" id="h_sectionid" value="'+this.sectionid+'"/>'+
      '<input type="hidden" id="h_studentid" value="'+this.studentid+'"/>'+

      '<input type="hidden" name="mkey" value="'+this.hash_string+'"/>'+
      '<input type="hidden" name="key" value="'+this.mkey+'"/>'+
      '<input type="hidden" name="txnid" value="'+this.txnid+'"/>'+
      '<input type="hidden" name="amount" value="'+this.totalAmount+'"/>'+
      '<input type="hidden" name="productinfo" value="total fee pay"/>'+
      '<input type="hidden" name="firstname" id="firstname" value="'+this.fathername+'"/>'+
      '<input type="hidden" name="email" value="'+this.email+'"/>'+
      '<input type="hidden" name="phone" value="'+this.mobile_no+'"/>'+
      '<input type="hidden" name="address1" value="'+this.isParent+'"/>'+
      '<input type="hidden" name="surl" value="'+global.ipaymentResponse+'ipaymentresponse?scid='+this.e_schoolid+'&stid='+this.e_studentid+'&fid='+this.e_feeid+'" size="64"/>'+
      '<input type="hidden" name="furl" value="'+global.ipaymentResponse+'ipaymentresponse?scid='+this.e_schoolid+'&stid='+this.e_studentid+'&fid='+this.e_feeid+'" size="64"/>'+
      '<input type="hidden" name="hash" value="'+this.hash+'"/>'+
      '<input type="hidden" name="service_provider" value="payu_paisa" size="64"/>'+

      '</form> <script type="text/javascript">document.getElementById("ipayment").submit();</script></body></html>';

      let pageContentUrl = 'data:text/html;base64,' + btoa(pageContent);
      let iabRef = this.theInAppBrowser.create(pageContentUrl,target,this.options);

      iabRef.show();
      iabRef.on("loadstop").subscribe(result => {
        if (result.url.match(global.ipaymentResponse+'closePaymentpage')) {
          iabRef.close();
          this.childFeeDefault();
        }
      });

    },(err)=> {
      alert('failled '+err);
    });
  }*/

  // fee submission process (individual)
  /*payFee(feeid,feetitle,amount,studentid,schoolid,classid,sectionid,email,mobile,fathername)
  {

    if(this.isParent === true){
      this.email = localStorage.getItem('useremail');
    }else{
      this.email = email;
    }

    let payUmoneyAction = global.payUmoneyAction;
    this.userData = { 'feeid': feeid, 'feetitle': feetitle, 'amount': amount, 'studentid': studentid, 'schoolid': schoolid, 'classid': classid, 'sectionid': sectionid, 'email': this.email, 'mobile': mobile, 'fathername': fathername };
    this.authService.postData(this.userData, 'iPaymentIndividual').then((result)=>{

        this.hash_string = result['hash_string'];
        this.hash = result['hash'];
        this.mkey = result['MERCHANT_KEY'];
        this.txnid = result['txnid'];
        this.e_feeid = result['e_feeid'];
        this.e_studentid = result['e_studentid'];
        this.e_schoolid = result['e_schoolid'];

        let target = "_blank";

        var pageContent = '<html><head></head><body><form id="ipayment" action="'+payUmoneyAction+'" method="post">' +

        '<input type="hidden" id="h_schoolid" value="'+schoolid+'"/>'+
        '<input type="hidden" id="h_classid" value="'+classid+'"/>'+
        '<input type="hidden" id="h_sectionid" value="'+sectionid+'"/>'+
        '<input type="hidden" id="h_studentid" value="'+studentid+'"/>'+

        '<input type="hidden" name="mkey" value="'+this.hash_string+'"/>'+
        '<input type="hidden" name="key" value="'+this.mkey+'"/>'+
        '<input type="hidden" name="txnid" value="'+this.txnid+'"/>'+
        '<input type="hidden" name="amount" value="'+amount+'"/>'+
        '<input type="hidden" name="productinfo" value="'+feetitle+'"/>'+
        '<input type="hidden" name="firstname" id="firstname" value="'+fathername+'"/>'+
        '<input type="hidden" name="email" value="'+this.email+'"/>'+
        '<input type="hidden" name="phone" value="'+mobile+'"/>'+
        '<input type="hidden" name="address1" value="'+this.isParent+'"/>'+ 
        '<input type="hidden" name="surl" value="'+global.ipaymentResponse+'ipaymentresponse?scid='+this.e_schoolid+'&stid='+this.e_studentid+'&fid='+this.e_feeid+'" size="64"/>'+
        '<input type="hidden" name="furl" value="'+global.ipaymentResponse+'ipaymentresponse?scid='+this.e_schoolid+'&stid='+this.e_studentid+'&fid='+this.e_feeid+'" size="64"/>'+
        '<input type="hidden" name="hash" value="'+this.hash+'"/>'+
        '<input type="hidden" name="service_provider" value="payu_paisa" size="64"/>'+

        '</form> <script type="text/javascript">document.getElementById("ipayment").submit();</script></body></html>';

        let pageContentUrl = 'data:text/html;base64,' + btoa(pageContent);
        let iabRef = this.theInAppBrowser.create(pageContentUrl,target,this.options);

        iabRef.show();
        iabRef.on("loadstop").subscribe(result => {
          if (result.url.match(global.ipaymentResponse+'closePaymentpage')) {
            iabRef.close();
            this.childFeeDefault();
          }
        });


    },(err)=> {
      alert('failled '+err);
    });
  }*/






  /* FEE PAYMENT BY RAZORPAY PAYMENT GATEWAY (AWESOME) */

  // CASE-1 : INDIVIDUAL
  payFee(feeid,feetitle,amount,studentid,schoolid,classid,sectionid,email,mobile,fathername)
  {
    if(this.isParent === true){
      this.email = localStorage.getItem('useremail');
    }else{
      this.email = email;
    }

    if(amount <= 2000){
      var conv = 'If you pay by Debit Card 1.25% applicable';
    }else{
      var conv = 'If you pay by Debit Card 1.5% applicable';
    }
    let alert = this.alertCtrl.create({
      title: '<div class="ccaH">Conveyance Charges Apply</div>',
      message: '<div class="ccaP"><span class="ccaAlertStar">*</span> '+conv+' </div><div class="ccaP"> <span class="ccaAlertStar">*</span> If you pay by Credit Card 1.65% applicable </div><div class="ccaP"> <span class="ccaAlertStar">*</span> If you pay by Net Banking &#8377;30.00 applicable </div><div class="ccaP"> <span class="ccaAlertStar">*</span> If you pay by Mobile wallet (MobiKwik, PayU Money, Airtel Money, PayZapp, Ola Money, FreeCharge) 2.35% applicable</div>',
      enableBackdropDismiss: false,
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
          }
        },
        {
          text: 'Proceed',
          handler: () => {

              this.authService.postData({'studentid':studentid,'schoolid':schoolid}, 'getStudentAndSchoolName').then((result)=>{
                  this.studentschoolname = result['name'];
              },(err)=> {
                // alert('failled '+err);
              });   

              var options = {
                  name: feetitle,
                  description: 'Student Fee',
                  // image: global.apiBaseUrl+'toplogo.png',
                  currency: 'INR',
                  key: 'rzp_test_aGzio06c7dTwxU',
                  amount: amount*100,
                  prefill: {
                    method: 'netbanking',
                    email: email,
                    contact: mobile,
                    name: fathername
                  },
                  theme: {
                    color: '#F37254'
                  },
                  modal: {
                    ondismiss: ()=> {
                      // alert('dismissed')
                    }
                  }
                };

                var successCallback = (payment_id)=> {
                  //alert('payment_id: ' + payment_id);
                  let modal = this.modalCtrl.create(PaymentResponsePage,
                    {
                      status:'success',
                      transactionid:payment_id,
                      schoolid:schoolid, 
                      studentid:studentid, 
                      classid:classid, 
                      sectionid:sectionid,
                      feeid:feeid, 
                      feetitle:feetitle, 
                      amount:amount, 
                      email:email, 
                      mobile:mobile, 
                      fathername:fathername,
                      address:'', 
                      address1:this.isParent,
                      address2:0,
                      city:1,
                      studentname:this.studentschoolname['studentname'],
                      schoolname:this.studentschoolname['schoolname'],
                      schoollogopath:this.studentschoolname['LogoPath'],           
                    },{'enableBackdropDismiss':false});
                    modal.onDidDismiss(() => {
                      this.childFeeDefault();
                    });
                    modal.present(); 
                };
                var cancelCallback = (error)=> {
                  //alert(error.description + ' (Error ' + error.code + ')');
                };
                RazorpayCheckout.open(options, successCallback, cancelCallback);
              }
            }
          ],
          cssClass: 'ccaAlert'
          });
          alert.present();
  }

  
  // CASE-1 : TOTAL
  payAllFee()
  {

    /*if(this.isParent === true){
      this.email = localStorage.getItem('useremail');
    }else{
      this.email = this.emailid;
    }*/

    if(this.isParent === true){
      this.email = localStorage.getItem('useremail');
      this.isParentTrueOrFalse = true;
    }else{
      this.email = this.emailid;
      this.isParentTrueOrFalse = false;
    }

    if(this.totalAmount <= 2000){
      var conv = 'If you pay by Debit Card 1.25% applicable';
    }else{
      var conv = 'If you pay by Debit Card 1.5% applicable';
    }
    let alert = this.alertCtrl.create({
      title: '<div class="ccaH">Conveyance Charges Apply</div>',
      message: '<div class="ccaP"><span class="ccaAlertStar">*</span> '+conv+' </div><div class="ccaP"> <span class="ccaAlertStar">*</span> If you pay by Credit Card 1.65% applicable </div><div class="ccaP"> <span class="ccaAlertStar">*</span> If you pay by Net Banking &#8377;30.00 applicable </div><div class="ccaP"> <span class="ccaAlertStar">*</span> If you pay by Mobile wallet (MobiKwik, PayU Money, Airtel Money, PayZapp, Ola Money, FreeCharge) 2.35% applicable</div>',
      enableBackdropDismiss: false,
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
          }
        },
        {
          text: 'Proceed',
          handler: () => {

                this.authService.postData({'studentid':this.student_id,'schoolid':this.school_id}, 'getStudentAndSchoolName').then((result)=>{
                  this.studentschoolname = result['name'];
                },(err)=> {
                  // alert('failled '+err);
                });   

                var options = {
                  name: 'Total Fee Pay',
                  description: 'Student Fee',
                  // image: 'assets/images/toplogo.png',
                  currency: 'INR',
                 
                  key: 'rzp_test_aGzio06c7dTwxU',
                  amount: this.totalAmount*100,
                  prefill: {
                    method: 'netbanking',
                    email: this.email,
                    contact: this.mobile_no,
                    name: this.fathername
                  },
                  theme: {
                    color: '#F37254'
                  },
                  modal: {
                    ondismiss: ()=> {
                      // alert('dismissed')
                    }
                  }
                };

                var successCallback = (payment_id)=> {
                  //alert('payment_id: ' + payment_id);
                  let modal = this.modalCtrl.create(PaymentResponsePage,
                    {
                      status:'success',
                      transactionid:payment_id,
                      schoolid:this.school_id, 
                      studentid:this.student_id, 
                      classid:this.class_id, 
                      sectionid:this.section_id,
                      feeid:0, 
                      feetitle:'total fee pay', 
                      amount:this.totalAmount, 
                      email:this.email, 
                      mobile:this.mobile_no, 
                      fathername:this.fathername,
                      address:this.address, 
                      address1:this.isParentTrueOrFalse,
                      address2:0,
                      city:1,
                      studentname:this.studentschoolname['studentname'],
                      schoolname:this.studentschoolname['schoolname'],
                      schoollogopath:this.studentschoolname['LogoPath'],           
                    },{'enableBackdropDismiss':false});
                    modal.onDidDismiss(() => {
                      this.childFeeDefault();
                      this.viewCtrl.dismiss();

                      // go back 2 times
                        const index = this.navCtrl.getActive().index;
                        this.navCtrl.remove(index-1);
                        this.navCtrl.remove(index-2);
                      //

                      this.navCtrl.push(UserPage, {'screen': 0}, {animate:true,animation:'transition',duration:600,direction:'forward'});
                    });
                    modal.present(); 
                };
                var cancelCallback = (error)=> {
                  //alert(error.description + ' (Error ' + error.code + ')');
                };
                RazorpayCheckout.open(options, successCallback, cancelCallback);
              }
            }
            ],
            cssClass: 'ccaAlert'
            });
            alert.present();
  }





}
