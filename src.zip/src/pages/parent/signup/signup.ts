import { Component } from '@angular/core';
import { NavController, NavParams, ToastController, LoadingController, AlertController } from 'ionic-angular';

import { AuthServiceProvider } from './../../../providers/parent/auth-service/auth-service';
import { global } from "../../../app/global";
import { HomePage } from '../home/home';
import { LoginPage } from '../login/login';
import {Validators, FormGroup, FormBuilder } from '@angular/forms';
import { Facebook, FacebookLoginResponse } from "@ionic-native/facebook";


@Component({
  selector: 'page-signup',
  templateUrl: 'signup.html',
})
export class SignupPage {

  responseData: any;
  userData = {'name':'', 'email':'', 'contact':''};
  isDisabled: any; dataa: any;
  loader: any; otherLoader: any; myLoadingControl: any;
  fbData = {email: '', name: '', id: '', imageurl: ''};
  
  public signForm : FormGroup; sign_username:any; sign_email:any; sign_contact:any;

  constructor(
              public navCtrl: NavController,
              public navParams: NavParams,
              public authservice: AuthServiceProvider,
              public loadingCtrl: LoadingController,
      			  public toastCtrl: ToastController,
              public alertCtrl: AlertController,
              public formBuilder: FormBuilder,
              public fb: Facebook,
            )
  {
    // default enabled all sign up input fields
    this.isDisabled = global.makeEnabled;

    this.myLoadingControl = loadingCtrl;

    // signup form validation
    this.signForm = this.formBuilder.group({
      sign_email: ['', [Validators.required,Validators.pattern("[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?")]],
      sign_contact: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern("[0-9]*")]],
      sign_username: ['',[Validators.required, Validators.pattern("[a-zA-Z][a-zA-Z ]+")]]
    });
    this.sign_email = this.signForm.controls['sign_email'];
    this.sign_contact = this.signForm.controls['sign_contact'];
    this.sign_username = this.signForm.controls['sign_username'];

  }

  ionViewDidLoad(){
    console.log('ionViewDidLoad SignupPage');
  }

  goToLogin(){
    this.navCtrl.push(LoginPage);
     //this.navCtrl.pop();
    //const root = this.app.getRootNav();
    //root.popToRoot();
  }

  signup()
  {
      this.loader = this.myLoadingControl.create({
        content : "Please wait.."
      });

      this.loader.present().then(() => {
	      this.authservice.postData(this.userData , 'signup').then((result)=>{
    		this.responseData = result;
        // EMAIL ALREADY EXIST IN DATABASE
        if(this.responseData['sign_response'] == 3)
        {
          let toast = this.toastCtrl.create({  message: this.responseData['msg'], duration: 3000 });
    			toast.present();
          this.loader.dismiss();
        }
        // VERIFICATION TEXT MESSAGE/MAIL SENT
        if(this.responseData['sign_response'] == 2)
        {
          this.isDisabled = global.makeDisabled; // making disabled all sign up input fields
          localStorage.setItem('useremail',this.userData.email);
          localStorage.setItem('name',this.userData.name);

          let toast = this.toastCtrl.create({   message: this.responseData['msg'], duration: 2000 });
          toast.present();
          this.loader.dismiss();

          let prompt = this.alertCtrl.create({
            title: 'Varification Code',
            enableBackdropDismiss: false,
            message: "Please enter account varification code which is sent on your given email id and contact number by Ribblu.com",
            inputs: [
              {
                name: 'varificationcode',
                placeholder: 'enter 5 digit code',
                type: 'number'
              },
            ],
            buttons: [
              {
                text: 'Cancel',
                handler: data => {
                  console.log('Cancel clicked');
                }
              },
              {
                text: 'Verify',
                handler: data => {

                  let dataa = {'email':localStorage.getItem('useremail') , 'name':localStorage.getItem('name'), 'vcode':data.varificationcode};

                  if(data.varificationcode == ''){
                    let toast = this.toastCtrl.create({ message: 'Please enter varification code !', duration: 8000 });
                    toast.present();
                    return false;
                  }

                  this.otherLoader = this.myLoadingControl.create({
                    content : "Please wait.."
                  });

                   this.otherLoader.present().then(() => {
                     this.authservice.postData(dataa, 'verifyaccount').then((result)=>{
                      this.dataa = result;
                      if(this.dataa['varify_response'] == 1){
                          let toast = this.toastCtrl.create({ message: this.dataa['msg'], duration: 8000 });
                          toast.present();
                          prompt.dismiss();
                          this.otherLoader.dismiss();
                          this.navCtrl.push(HomePage);
                      }else if(this.dataa['varify_response'] == 2) {
                          let toast = this.toastCtrl.create({ message: this.dataa['msg'], duration: 3000 });
                          toast.present();
                          this.otherLoader.dismiss();
                      }else{
                          let toast = this.toastCtrl.create({ message: 'Sorry ! something went wrong.', duration: 3000 });
                          toast.present();
                          this.otherLoader.dismiss();
                      }
                  },(err)=> {
                      alert('failled '+err);
                      this.otherLoader.dismiss();
                  });
                  });
                    return false;

                }
              }
            ]
          });
          prompt.present();
        }
	  },(err)=> {
    		alert('failled '+err);
	  });
  });
  }

  facebookLogin(){
    this.fb.getLoginStatus().then((res: FacebookLoginResponse) => {

        if (res.status == "connected")
        {
          this.processFBLogin();
        }
        else
        {
          this.fb.login(['public_profile', 'user_friends', 'email']).then((response: FacebookLoginResponse) => {
           
            if (response.status == "connected")
            {
              this.processFBLogin();
            }

          });
        }
    });    
  }
  processFBLogin(){
    this.fb.api('me?fields=id,name,email,first_name,last_name,picture.width(720).height(720).as(picture_large)', []).then(profile => {
      this.fbData = {
        email: profile['email'], 
        name: profile['first_name'] + ' ' + profile['last_name'], 
        id: profile['id'],
        imageurl: profile['picture_large']['data']['url']
      };

      if (this.fbData.email == "")
      {
        let toast = this.toastCtrl.create({ message: "Sorry! unable to login. Please update your email id on facebook first", duration: 3000 });
        toast.present();
      }
      else
      {
        this.loader = this.myLoadingControl.create({
          content : "Please wait.."
        });
        this.loader.present().then(() => {
          this.authservice.postData(this.fbData, 'socialmedialogin').then((result)=>{
              this.responseData = result;
                
              if(this.responseData['sign_response'] == 1){
                this.loader.dismiss();
              
                localStorage.setItem('useremail',this.fbData.email);
                this.navCtrl.setRoot(HomePage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
              }else{
                this.loader.dismiss();
                let toast = this.toastCtrl.create({ message: "Sorry!unable to process request", 'cssClass':'toastText', duration: 3000 });
                toast.present();
              }
            },(err)=> {
              this.loader.dismiss();
              let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 3000 });
              toast.present();
          });
        });

      }
    },(err) => {
      this.loader.dismiss();
      let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 3000 });
      toast.present();
    });
  }

}
