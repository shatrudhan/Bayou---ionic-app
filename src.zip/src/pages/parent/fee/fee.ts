import { Component } from '@angular/core';
import { AlertController, NavController, ActionSheetController, Platform, NavParams, LoadingController, ToastController, ModalController, ViewController } from 'ionic-angular';
import { AuthServiceProvider } from './../../../providers/parent/auth-service/auth-service';
import { InAppBrowser, InAppBrowserOptions } from '@ionic-native/in-app-browser';
import { global } from "../../../app/global";
import { PaymentResponsePage } from '../payment-response/payment-response';


@Component({
  selector: 'page-fee',
  templateUrl: 'fee.html',
})
export class FeePage {
  studentname: any;
  studentschoolname: any;
  edate: string;
  sdate: any;

  // declaration of variable type here.
  fee: string = "pending_fee";
  isAndroid: boolean = false;
  childfee: any; userData : any; feeCount:number;
  totalAmount:number; school_id:number; student_id:number; class_id:number; section_id:number; emailid:any; fathername:string; address:any; city:string; state:string; pincode:number; mobile_no:number;
  hash_string:any; hash:any; mkey:any; txnid:any; e_feeid:number; e_studentid:number; e_schoolid:number;

  /*options : InAppBrowserOptions = {
      location : 'yes',//Or 'no'
      hidden : 'no', //Or  'yes'
      clearcache : 'yes',
      clearsessioncache : 'yes',
      zoom : 'yes',//Android only ,shows browser zoom controls
      hardwareback : 'yes',
      mediaPlaybackRequiresUserAction : 'no',
      shouldPauseOnSuspend : 'no', //Android only
      closebuttoncaption : 'Close', //iOS only
      disallowoverscroll : 'no', //iOS only
      toolbar : 'yes', //iOS only
      enableViewportScale : 'no', //iOS only
      allowInlineMediaPlayback : 'no',//iOS only
      presentationstyle : 'pagesheet',//iOS only
      fullscreen : 'yes',//Windows only
  };*/

  constructor(
              public modalCtrl: ModalController,
              public viewCtrl: ViewController, 
              public actionSheetCtrl: ActionSheetController,
              public platform: Platform, 
              public navCtrl: NavController,
              public navParams: NavParams,
              public toastCtrl: ToastController,
              public authservice: AuthServiceProvider,
              public loadingCtrl: LoadingController,
              public theInAppBrowser: InAppBrowser,
              public alertCtrl: AlertController,              
             )
  {
    this.studentname = this.navParams.get('studentname');
    // loader starts
      let loader = this.loadingCtrl.create({ content: "Please wait...", duration: 500 });
      loader.present();

    // here ,  we are getting child pending fee status by default
      this.userData = { 'studentid': navParams.get('studentid'),
                        'classid': navParams.get('classid'),
                        'sectionid': navParams.get('sectionid'),
                        'schoolid': navParams.get('schoolid'),
                        'status': 0
                      };
      this.childFeeDefault();
  }

  ionViewDidLoad()
  {
    console.log('ionViewDidLoad FeePage');
  }

  payFeeScheduler(feeid,feetitle,amount,studentid,schoolid,classid,sectionid,email,mobile,fathername,address,city,state,pincode,paymentid,feetype,quarter)
  {
    let modal = this.modalCtrl.create(paymentWifergation, {'schoolid': schoolid, 'studentid': studentid, 'paymentid':paymentid, 'quarter':quarter, 'feetype':feetype, 'feePageObj':this});
    modal.present();
  }

  childFeeDefault()
  {
      this.authservice.postData(this.userData, 'childFeeInfo').then((result)=>{
      this.childfee = result['feeinfo'];
      result['feeinfo'].forEach(element => {
        if(element.quarter == 1){
          this.sdate = element.q1startday+'-'+element.q1startmonth;
          this.edate = element.q1endday+'-'+element.q1endmonth;
        }
        if(element.quarter == 2){
          this.sdate = element.q2startday+'-'+element.q2startmonth;
          this.edate = element.q2endday+'-'+element.q2endmonth;
        }
        if(element.quarter == 3){
          this.sdate = element.q3startday+'-'+element.q3startmonth;
          this.edate = element.q3endday+'-'+element.q3endmonth;
        }
        if(element.quarter == 4){
          this.sdate = element.q4startday+'-'+element.q4startmonth;
          this.edate = element.q4endday+'-'+element.q4endmonth;
        }
      });
      // getting sum of amount from result
      let total = 0;
      for (var i = 0; i < this.childfee.length; i++) {
          if (this.childfee[i].amount) {
              total+=parseInt(this.childfee[i].amount);
          }
      }
      this.totalAmount = total;
      // binding some values outside the ngfor loop or result in view (html) page
      this.feeCount = this.childfee.length;
      if(this.feeCount > 0){

        this.school_id = this.childfee[0].schoolid;
        this.student_id = this.childfee[0].studentid;
        this.class_id = this.childfee[0].classid;
        this.section_id = this.childfee[0].sectionid;
        this.emailid = this.childfee[0].emailid;
        this.fathername = this.childfee[0].fathername;
        this.address = this.childfee[0].address;
        this.city = this.childfee[0].city;
        this.state = this.childfee[0].state;
        this.pincode = this.childfee[0].pincode;
        this.mobile_no = this.childfee[0].mobile_no;

      }
    },(err)=> {
      alert('failled '+err);
    });
  }


  // getting child pending fee info
  pendingStatus(status)
  {
    //this.childFeeDefault();
    this.userData = { 'studentid': this.navParams.get('studentid'),
                      'classid': this.navParams.get('classid'),
                      'sectionid': this.navParams.get('sectionid'),
                      'schoolid': this.navParams.get('schoolid'),
                     'status': status
                    };
    this.authservice.postData(this.userData, 'childFeeInfo').then((result)=>{
    this.childfee = result['feeinfo'];
    },(err)=> {
      alert('failled '+err);
    });
  }

  // getting child submitted fee info
  submittedStatus(status)
  {
    this.userData = { 'studentid': this.navParams.get('studentid'),
                      'classid': this.navParams.get('classid'),
                      'sectionid': this.navParams.get('sectionid'),
                      'schoolid': this.navParams.get('schoolid'),
                     'status': status
                    };
    this.authservice.postData(this.userData, 'childFeeInfo').then((result)=>{
      this.childfee = result['feeinfo'];
    },(err)=> {
      alert('failled '+err);
    });
  }

  // ITS DONE BY THE PAYUMONEY PAYMENT GATEWAY (INDIVIDUAL)
  /*payFee(feeid,feetitle,amount,studentid,schoolid,classid,sectionid,email,mobile,fathername,address,city,state,pincode)
  {

    let payUmoneyAction = global.payUmoneyAction;
    this.userData = { 'feeid': feeid, 'feetitle': feetitle, 'amount': amount, 'studentid': studentid, 'schoolid': schoolid, 'classid': classid, 'sectionid': sectionid, 'email': email, 'mobile': mobile, 'fathername': fathername };
    this.authservice.postData(this.userData, 'iPaymentIndividual').then((result)=>{

        this.hash_string = result['hash_string'];
        this.hash = result['hash'];
        this.mkey = result['MERCHANT_KEY'];
        this.txnid = result['txnid'];
        this.e_feeid = result['e_feeid'];
        this.e_studentid = result['e_studentid'];
        this.e_schoolid = result['e_schoolid'];

        let target = "_blank";

        var pageContent = '<html><head></head><body><form id="ipayment" action="'+payUmoneyAction+'" method="post">' +

        '<input type="hidden" id="h_schoolid" value="'+schoolid+'"/>'+
        '<input type="hidden" id="h_classid" value="'+classid+'"/>'+
        '<input type="hidden" id="h_sectionid" value="'+sectionid+'"/>'+
        '<input type="hidden" id="h_studentid" value="'+studentid+'"/>'+

        '<input type="hidden" name="mkey" value="'+this.hash_string+'"/>'+
        '<input type="hidden" name="key" value="'+this.mkey+'"/>'+
        '<input type="hidden" name="txnid" value="'+this.txnid+'"/>'+
        '<input type="hidden" name="amount" value="'+amount+'"/>'+
        '<input type="hidden" name="productinfo" value="'+feetitle+'"/>'+
        '<input type="hidden" name="firstname" id="firstname" value="'+fathername+'"/>'+
        '<input type="hidden" name="email" value="'+email+'"/>'+
        '<input type="hidden" name="phone" value="'+mobile+'"/>'+
        '<input type="hidden" name="address1" value="'+false+'"/>'+ 
        '<input type="hidden" name="address2" value="0"/>'+ 
        '<input type="hidden" name="city" value="1"/>'+   
        '<input type="hidden" name="surl" value="'+global.ipaymentResponse+'ipaymentresponse?scid='+this.e_schoolid+'&stid='+this.e_studentid+'&fid='+this.e_feeid+'" size="64"/>'+
        '<input type="hidden" name="furl" value="'+global.ipaymentResponse+'ipaymentresponse?scid='+this.e_schoolid+'&stid='+this.e_studentid+'&fid='+this.e_feeid+'" size="64"/>'+
        '<input type="hidden" name="hash" value="'+this.hash+'"/>'+
        '<input type="hidden" name="service_provider" value="payu_paisa" size="64"/>'+

        '</form> <script type="text/javascript">document.getElementById("ipayment").submit();</script></body></html>';

        let pageContentUrl = 'data:text/html;base64,' + btoa(pageContent);
        let iabRef = this.theInAppBrowser.create(pageContentUrl,target,this.options);

        iabRef.show();
        iabRef.on("loadstop").subscribe(result => {
          if (result.url.match(global.ipaymentResponse+'closePaymentpage')) {
            iabRef.close();
            //this.fee = "submitted_fee";
            //this.submittedStatus(parseInt('1'));
            this.pendingStatus(parseInt('0'));
          }
        });


    },(err)=> {
      alert('failled '+err);
    });

  }*/

  // ITS DONE BY THE RAZORPAY PAYMENT GATEWAY (AWESOME) (INDIVIDUAL)
  payFee(feeid,feetitle,amount,studentid,schoolid,classid,sectionid,email,mobile,fathername,address,city,state,pincode)
  {
      if(amount <= 2000){
        var conv = 'If you pay by Debit Card 1.25% applicable';
      }else{
        var conv = 'If you pay by Debit Card 1.5% applicable';
      }
      let alert = this.alertCtrl.create({
        title: '<div class="ccaH">Conveyance Charges Apply</div>',
        message: '<div class="ccaP"><span class="ccaAlertStar">*</span> '+conv+' </div><div class="ccaP"> <span class="ccaAlertStar">*</span> If you pay by Credit Card 1.65% applicable </div><div class="ccaP"> <span class="ccaAlertStar">*</span> If you pay by Net Banking &#8377;30.00 applicable </div><div class="ccaP"> <span class="ccaAlertStar">*</span> If you pay by Mobile wallet (MobiKwik, PayU Money, Airtel Money, PayZapp, Ola Money, FreeCharge) 2.35% applicable</div>',
        enableBackdropDismiss: false,
        buttons: [
          {
            text: 'Cancel',
            role: 'cancel',
            handler: () => {
            }
          },
          {
            text: 'Proceed',
            handler: () => {
              
              this.authservice.postData({'studentid':studentid,'schoolid':schoolid}, 'getStudentAndSchoolName').then((result)=>{
                  this.studentschoolname = result['name'];
              },(err)=> {
                // alert('failled '+err);
              });   

              var options = {
                  name: feetitle,
                  description: 'Student Fee',
                  // image: global.apiBaseUrl+'toplogo.png',
                  currency: 'INR',
                 
                  key: 'rzp_test_aGzio06c7dTwxU',
                  amount: amount*100,
                  prefill: {
                    method: 'netbanking',
                    email: email,
                    contact: mobile,
                    name: fathername
                  },
                  theme: {
                    color: '#F37254'
                  },
                  modal: {
                    ondismiss: ()=> {
                      // alert('dismissed')
                    }
                  }
                };

                var successCallback = (payment_id)=> {
                  //alert('payment_id: ' + payment_id);
                  let modal = this.modalCtrl.create(PaymentResponsePage,
                    {
                      status:'success',
                      transactionid:payment_id,
                      schoolid:schoolid, 
                      studentid:studentid, 
                      classid:classid, 
                      sectionid:sectionid,
                      feeid:feeid, 
                      feetitle:feetitle, 
                      amount:amount, 
                      email:email, 
                      mobile:mobile, 
                      fathername:fathername,
                      address:address, 
                      address1:false,
                      address2:0,
                      city:1,
                      studentname:this.studentschoolname['studentname'],
                      schoolname:this.studentschoolname['schoolname'],
                      schoollogopath:this.studentschoolname['LogoPath'],           
                    },{'enableBackdropDismiss':false});
                    modal.onDidDismiss(() => {
                      this.pendingStatus(parseInt('0'));
                      this.childFeeDefault();
                    });
                    modal.present(); 
                };
                var cancelCallback = (error)=> {
                  //alert(error.description + ' (Error ' + error.code + ')');
                };
                RazorpayCheckout.open(options, successCallback, cancelCallback);

            }
          }
        ],
        cssClass: 'ccaAlert'
        });
        alert.present();
  }
  
  // ITS DONE BY THE PAYUMONEY PAYMENT GATEWAY (TOTAL)
  /*payAllFee(totalAmount,studentid,schoolid,classid,sectionid,email,mobile,fathername,address,city,state,pincode)
  {
    let payUmoneyAction = global.payUmoneyAction;
    this.userData = { 'totalAmount': totalAmount, 'studentid': studentid, 'schoolid': schoolid, 'classid': classid, 'sectionid': sectionid,   'email': email, 'mobile': mobile, 'fathername': fathername, 'isParent':false, 'fee_title':'total fee pay' };
    this.authservice.postData(this.userData, 'iPaymentTotal').then((result)=>{
      this.hash_string = result['hash_string'];
      this.hash = result['hash'];
      this.mkey = result['MERCHANT_KEY'];
      this.txnid = result['txnid'];
      this.e_feeid = result['e_feeid'];
      this.e_studentid = result['e_studentid'];
      this.e_schoolid = result['e_schoolid'];

      let target = "_blank";

      var pageContent = '<html><head></head><body><form id="ipayment" action="'+payUmoneyAction+'" method="post">' +

      '<input type="hidden" id="h_schoolid" value="'+schoolid+'"/>'+
      '<input type="hidden" id="h_classid" value="'+classid+'"/>'+
      '<input type="hidden" id="h_sectionid" value="'+sectionid+'"/>'+
      '<input type="hidden" id="h_studentid" value="'+studentid+'"/>'+

      '<input type="hidden" name="mkey" value="'+this.hash_string+'"/>'+
      '<input type="hidden" name="key" value="'+this.mkey+'"/>'+
      '<input type="hidden" name="txnid" value="'+this.txnid+'"/>'+
      '<input type="hidden" name="amount" value="'+totalAmount+'"/>'+
      '<input type="hidden" name="productinfo" value="total fee pay"/>'+
      '<input type="hidden" name="firstname" id="firstname" value="'+fathername+'"/>'+
      '<input type="hidden" name="email" value="'+email+'"/>'+
      '<input type="hidden" name="phone" value="'+mobile+'"/>'+
      '<input type="hidden" name="address1" value="'+false+'"/>'+ 
      '<input type="hidden" name="address2" value="0"/>'+ 
      '<input type="hidden" name="city" value="1"/>'+      
      '<input type="hidden" name="surl" value="'+global.ipaymentResponse+'ipaymentresponse?scid='+this.e_schoolid+'&stid='+this.e_studentid+'&fid='+this.e_feeid+'" size="64"/>'+
      '<input type="hidden" name="furl" value="'+global.ipaymentResponse+'ipaymentresponse?scid='+this.e_schoolid+'&stid='+this.e_studentid+'&fid='+this.e_feeid+'" size="64"/>'+
      '<input type="hidden" name="hash" value="'+this.hash+'"/>'+
      '<input type="hidden" name="service_provider" value="payu_paisa" size="64"/>'+

      '</form> <script type="text/javascript">document.getElementById("ipayment").submit();</script></body></html>';

      let pageContentUrl = 'data:text/html;base64,' + btoa(pageContent);
      let iabRef = this.theInAppBrowser.create(pageContentUrl,target,this.options);

      iabRef.show();
      iabRef.on("loadstop").subscribe(result => {
        if (result.url.match(global.ipaymentResponse+'closePaymentpage')) {
          iabRef.close();
          this.pendingStatus(parseInt('0'));
        }
      });
    },(err)=> {
      alert('failled '+err);
    });
  }*/

  // ITS DONE BY THE RAZORPAY PAYMENT GATEWAY (AWESOME) (TOTAL)
  payAllFee(totalAmount,studentid,schoolid,classid,sectionid,email,mobile,fathername,address,city,state,pincode)
  {
    if(totalAmount <= 2000){
      var conv = 'If you pay by Debit Card 1.25% applicable';
    }else{
      var conv = 'If you pay by Debit Card 1.5% applicable';
    }
    let alert = this.alertCtrl.create({
      title: '<div class="ccaH">Conveyance Charges Apply</div>',
      message: '<div class="ccaP"><span class="ccaAlertStar">*</span> '+conv+' </div><div class="ccaP"> <span class="ccaAlertStar">*</span> If you pay by Credit Card 1.65% applicable </div><div class="ccaP"> <span class="ccaAlertStar">*</span> If you pay by Net Banking &#8377;30.00 applicable </div><div class="ccaP"> <span class="ccaAlertStar">*</span> If you pay by Mobile wallet (MobiKwik, PayU Money, Airtel Money, PayZapp, Ola Money, FreeCharge) 2.35% applicable</div>',
      enableBackdropDismiss: false,
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
          }
        },
        {
          text: 'Proceed',
          handler: () => {
              this.authservice.postData({'studentid':studentid,'schoolid':schoolid}, 'getStudentAndSchoolName').then((result)=>{
                  this.studentschoolname = result['name'];
              },(err)=> {
                // alert('failled '+err);
              });   

              var options = {
                  name: 'Total Fee Pay',
                  description: 'Student Fee',
                  // image: global.apiBaseUrl+'toplogo.png',
                  currency: 'INR',
                  key: 'rzp_test_aGzio06c7dTwxU',
                  amount: totalAmount*100,
                  prefill: {
                    method: 'netbanking',
                    email: email,
                    contact: mobile,
                    name: fathername
                  },
                  theme: {
                    color: '#F37254'
                  },
                  modal: {
                    ondismiss: ()=> {
                      // alert('dismissed')
                    }
                  }
                };

                var successCallback = (payment_id)=> {
                  //alert('payment_id: ' + payment_id);
                  let modal = this.modalCtrl.create(PaymentResponsePage,
                    {
                      status:'success',
                      transactionid:payment_id,
                      schoolid:schoolid, 
                      studentid:studentid, 
                      classid:classid, 
                      sectionid:sectionid,
                      feeid:0, 
                      feetitle:'total fee pay', 
                      amount:totalAmount, 
                      email:email, 
                      mobile:mobile, 
                      fathername:fathername,
                      address:address, 
                      address1:false,
                      address2:0,
                      city:1,
                      studentname:this.studentschoolname['studentname'],
                      schoolname:this.studentschoolname['schoolname'],
                      schoollogopath:this.studentschoolname['LogoPath'],           
                    },{'enableBackdropDismiss':false});
                    modal.onDidDismiss(() => {
                      this.pendingStatus(parseInt('0'));
                      this.childFeeDefault();
                    });
                    modal.present(); 
                };
                var cancelCallback = (error)=> {
                  //alert(error.description + ' (Error ' + error.code + ')');
                };
                RazorpayCheckout.open(options, successCallback, cancelCallback);

              }
            }
          ],
          cssClass: 'ccaAlert'
          });
          alert.present();
  }





}


@Component({
  selector: 'page-fee',
  template: `<ion-header>
              <ion-navbar>
                <ion-title style="text-align:center !important;font-size: 14px !important;">
                   Fee Summary ( {{ qValue}} Quarter )
                </ion-title>
                <ion-buttons start>
                  <button ion-button (click)="modalDismiss()">
                    <span ion-text color="primary" showWhen="ios">Cancel</span>
                    <ion-icon name="md-close" showWhen="android,windows"></ion-icon>
                  </button>
                </ion-buttons>
              </ion-navbar>
            </ion-header>

            <ion-content style="background:#fff !important;">
              <ion-item-group>
                <ion-item *ngFor="let fd of feeWithDetail">
                  <p>{{ fd.head_name }}</p>
                  <p item-end> {{ fd.amount | currency:'INR':true:'1.2-2'}} </p>
                </ion-item>
              </ion-item-group>
              <div class="totalFeeDiv"> <strong>Grand Total &nbsp;:</strong>&nbsp;&nbsp;&nbsp; {{ totalAmount | currency:'INR':true:'1.2-2' }} </div>
                <div class="ccaDiv">
                      Conveyance Charges Apply :
                      <p *ngIf="totalAmount <= 2000"> <span style="color: #fe7878;font-size: small;">*</span> If you pay by Debit Card 1.25% applicable </p>
                      <p *ngIf="totalAmount > 2000"> <span style="color: #fe7878;font-size: small;">*</span> If you pay by Debit Card 1.5% applicable </p>
                      <p> <span style="color: #fe7878;font-size: small;">*</span> If you pay by Credit Card 1.65% applicable </p>
                      <p> <span style="color: #fe7878;font-size: small;">*</span> If you pay by Net Banking {{30 | currency:'INR':true:'1.2-2'}} applicable </p>
                      <p> <span style="color: #fe7878;font-size: small;">*</span> If you pay by Mobile wallet (MobiKwik, PayU Money, Airtel Money, PayZapp, Ola Money, FreeCharge) 2.35% applicable</p>
                </div>
              <div class="paymentBtnDiv">
                <button ion-button color="secondary" full (click)="quarterFeePay()">Pay</button>
              </div>
            </ion-content>
            `
})


export class paymentWifergation {
  studentschoolname: any;
  feePageObj: any;
  mobile_no: any;
  emailid: any;
  fathername: any;
  sectionid: any;
  classid: any;
  userData: any;
  hash_string:any; hash:any; mkey:any; txnid:any; e_feeid:number; e_studentid:number; e_schoolid:number;

  totalAmount: any;

  feeWithDetail: any;

  qValue: string;
  userDataForQuarter: { 'studentid': any; 'schoolid': any; 'paymentid': any; };

  feetype: any; quarter: any; paymentid: any; studentid: any; schoolid: any;

  options : InAppBrowserOptions = {
      location : 'yes',//Or 'no'
      hidden : 'no', //Or  'yes'
      clearcache : 'yes',
      clearsessioncache : 'yes',
      zoom : 'yes',//Android only ,shows browser zoom controls
      hardwareback : 'yes',
      mediaPlaybackRequiresUserAction : 'no',
      shouldPauseOnSuspend : 'no', //Android only
      closebuttoncaption : 'Close', //iOS only
      disallowoverscroll : 'no', //iOS only
      toolbar : 'yes', //iOS only
      enableViewportScale : 'no', //iOS only
      allowInlineMediaPlayback : 'no',//iOS only
      presentationstyle : 'pagesheet',//iOS only
      fullscreen : 'yes',//Windows only
  };

  constructor(
              public navCtrl: NavController,
              public navParams: NavParams,
              public authservice: AuthServiceProvider,
              public loadingCtrl: LoadingController,
              public toastCtrl: ToastController,
              public modalCtrl: ModalController,
              public viewCtrl: ViewController, 
              public actionSheetCtrl: ActionSheetController,
              public platform: Platform, 
              public theInAppBrowser: InAppBrowser
             )
  {

    this.schoolid = this.navParams.get('schoolid');
    this.studentid = this.navParams.get('studentid');
    this.paymentid = this.navParams.get('paymentid');   
    this.quarter = this.navParams.get('quarter');      
    this.feetype = this.navParams.get('feetype');
    this.feePageObj = this.navParams.get('feePageObj');
    
    if(this.quarter == 1){
      this.qValue = '1st';
    }else if(this.quarter == 2){
      this.qValue = '2nd';
    }else if(this.quarter == 3){
      this.qValue = '3rd';
    }else if(this.quarter == 4){
      this.qValue = '4th';
    }

    this.userDataForQuarter = {'studentid':this.studentid, 'schoolid':this.schoolid, 'paymentid':this.paymentid};

    this.quarterFeeDetail();
  }

  modalDismiss()
  {
    this.viewCtrl.dismiss();
  }

  quarterFeeDetail()
  {

    this.authservice.postData(this.userDataForQuarter, 'getAllFeeTitleForQuarterFee').then((result)=>{
          result['responseData'].forEach(element => {
              this.classid = element.classid;
              this.sectionid = element.sectionid;
              this.fathername = element.fathername;
              this.emailid = element.emailid;
              this.mobile_no = element.mobile_no;
          });
          this.feeWithDetail = result['responseData'];
          // getting sum of amount from result
          let total = 0;
          for (var i = 0; i <this.feeWithDetail.length; i++) {
              if (this.feeWithDetail[i].amount) {
                  total += parseFloat(this.feeWithDetail[i].amount);
              }
          }
          this.totalAmount = total.toFixed(2);
    });
  }

  // BY PAYUMONEY
  /*quarterFeePay()
  {
    this.modalDismiss();
    let payUmoneyAction = global.payUmoneyAction;
    this.userData = { 'totalAmount': this.totalAmount, 'studentid': this.studentid, 'schoolid': this.schoolid, 'classid': this.classid, 'sectionid': this.sectionid, 'email': this.emailid, 'mobile': this.mobile_no, 'fathername': this.fathername, 'isParent':false, 'fee_title':this.qValue+' Quarter Fee' };
    this.authservice.postData(this.userData, 'iPaymentTotal').then((result)=>{
      this.hash_string = result['hash_string'];
      this.hash = result['hash'];
      this.mkey = result['MERCHANT_KEY'];
      this.txnid = result['txnid'];
      this.e_feeid = result['e_feeid'];
      this.e_studentid = result['e_studentid'];
      this.e_schoolid = result['e_schoolid'];

      let target = "_blank";

      var pageContent = '<html><head></head><body><form id="ipayment" action="'+payUmoneyAction+'" method="post">' +

      '<input type="hidden" id="h_schoolid" value="'+this.schoolid+'"/>'+
      '<input type="hidden" id="h_classid" value="'+this.classid+'"/>'+
      '<input type="hidden" id="h_sectionid" value="'+this.sectionid+'"/>'+
      '<input type="hidden" id="h_studentid" value="'+this.studentid+'"/>'+

      '<input type="hidden" name="mkey" value="'+this.hash_string+'"/>'+
      '<input type="hidden" name="key" value="'+this.mkey+'"/>'+
      '<input type="hidden" name="txnid" value="'+this.txnid+'"/>'+
      '<input type="hidden" name="amount" value="'+this.totalAmount+'"/>'+
      '<input type="hidden" name="productinfo" value="'+this.qValue+' Quarter Fee"/>'+
      '<input type="hidden" name="firstname" id="firstname" value="'+this.fathername+'"/>'+
      '<input type="hidden" name="email" value="'+this.emailid+'"/>'+
      '<input type="hidden" name="phone" value="'+this.mobile_no+'"/>'+
      '<input type="hidden" name="address1" value="'+false+'"/>'+ 
      '<input type="hidden" name="address2" value="'+this.quarter+'"/>'+ 
      '<input type="hidden" name="city" value="0"/>'+    
      '<input type="hidden" name="surl" value="'+global.ipaymentResponse+'ipaymentresponse?scid='+this.e_schoolid+'&stid='+this.e_studentid+'&fid='+this.e_feeid+'" size="64"/>'+
      '<input type="hidden" name="furl" value="'+global.ipaymentResponse+'ipaymentresponse?scid='+this.e_schoolid+'&stid='+this.e_studentid+'&fid='+this.e_feeid+'" size="64"/>'+
      '<input type="hidden" name="hash" value="'+this.hash+'"/>'+
      '<input type="hidden" name="service_provider" value="payu_paisa" size="64"/>'+

      '</form> <script type="text/javascript">document.getElementById("ipayment").submit();</script></body></html>';

      let pageContentUrl = 'data:text/html;base64,' + btoa(pageContent);
      let iabRef = this.theInAppBrowser.create(pageContentUrl,target,this.options);

      iabRef.show();
      iabRef.on("loadstop").subscribe(result => {
        if (result.url.match(global.ipaymentResponse+'closePaymentpage')) {
          iabRef.close();
          //this.pendingStatus(parseInt('0'));
          this.feePageObj.childFeeDefault();
          let toast = this.toastCtrl.create({ message: 'refresh there page.', duration: 8000 });
          toast.present();
        }
      });

    },(err)=> {
      alert('failled '+err);
    });
  }*/


  // BY RAZORPAY 
  quarterFeePay()
  {
    this.authservice.postData({'studentid':this.studentid,'schoolid':this.schoolid}, 'getStudentAndSchoolName').then((result)=>{
        this.studentschoolname = result['name'];
    },(err)=> {
      alert('failled '+err);
    });   

    var options = {
        name: this.qValue+' Quarter Fee',
        description: 'Student Fee',
        // image: global.apiBaseUrl+'toplogo.png',
        currency: 'INR',
        key: 'rzp_test_aGzio06c7dTwxU',
        amount: this.totalAmount*100,
        prefill: {
          method: 'netbanking',
          email: this.emailid,
          contact: this.mobile_no,
          name: this.fathername
        },
        theme: {
          color: '#F37254'
        },
        modal: {
          ondismiss: ()=> {
            alert('dismissed')
          }
        }
      };

      var successCallback = (payment_id)=> {
        //alert('payment_id: ' + payment_id);
        let modal = this.modalCtrl.create(PaymentResponsePage,
          {
            status:'success',
            transactionid:payment_id,
            schoolid:this.schoolid, 
            studentid:this.studentid, 
            classid:this.classid, 
            sectionid:this.sectionid,
            feeid:0, 
            feetitle:'total fee pay', 
            amount:this.totalAmount, 
            email:this.emailid, 
            mobile:this.mobile_no, 
            fathername:this.fathername,
            address:'', 
            address1:false,
            address2:this.quarter,
            city:0,
            studentname:this.studentschoolname['studentname'],
            schoolname:this.studentschoolname['schoolname'],
            schoollogopath:this.studentschoolname['LogoPath'],           
          },{'enableBackdropDismiss':false});
          modal.onDidDismiss(() => {
            this.feePageObj.childFeeDefault();
          });
          modal.present(); 
      };
      var cancelCallback = (error)=> {
        //alert(error.description + ' (Error ' + error.code + ')');
      };
      RazorpayCheckout.open(options, successCallback, cancelCallback);
  }





}