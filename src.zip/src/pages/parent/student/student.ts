import { HomePage } from '../home/home';
import { Component } from '@angular/core';
import { AlertController,NavController, ViewController, ModalController, NavParams, ToastController, LoadingController } from 'ionic-angular';
import { InAppBrowser, InAppBrowserOptions } from '@ionic-native/in-app-browser';
import { AuthServiceProvider } from './../../../providers/parent/auth-service/auth-service';
import { global } from "../../../app/global";
import { StudentfeePage } from '../studentfee/studentfee';
import { PaymentResponsePage } from '../payment-response/payment-response';


@Component({
  selector: 'page-student',
  templateUrl: 'student.html',
})
export class StudentPage {
  studentschoolname: any;

  email: any;
  student: any;
  userData : any;
  studentList: any;
  totalAmount:number;
  childfee: any;
  sectionid: any; classid: any; studentid: any; schoolid: any; fathername: any; mobile: any;
  isParent:any;
  hash_string:any; hash:any; mkey:any; txnid:any; e_feeid:number; e_studentid:number; e_schoolid:number; emailid: any;
  isParentTrueOrFalse: boolean;
  
  options : InAppBrowserOptions = {
      location : 'yes',//Or 'no'
      hidden : 'no', //Or  'yes'
      clearcache : 'yes',
      clearsessioncache : 'yes',
      zoom : 'yes',//Android only ,shows browser zoom controls
      hardwareback : 'yes',
      mediaPlaybackRequiresUserAction : 'no',
      shouldPauseOnSuspend : 'no', //Android only
      closebuttoncaption : 'Close', //iOS only
      disallowoverscroll : 'no', //iOS only
      toolbar : 'yes', //iOS only
      enableViewportScale : 'no', //iOS only
      allowInlineMediaPlayback : 'no',//iOS only
      presentationstyle : 'pagesheet',//iOS only
      fullscreen : 'yes',//Windows only
  };

  constructor(
              public navCtrl: NavController, 
              public navParams: NavParams, 
              public loadingCtrl: LoadingController, 
              public authService: AuthServiceProvider,
              public toastCtrl: ToastController,
              public theInAppBrowser: InAppBrowser,
              public modalCtrl: ModalController,
              public viewCtrl: ViewController,  
              public alertCtrl: AlertController,              
             ) 
  {
    this.student = this.navParams.get('studentinfo');
    this.studentid = this.student.sid,
    this.classid = this.student.classes,
    this.sectionid = this.student.section,
    this.schoolid = this.student.schoolId,
    this.fathername = this.student.fathername,
    this.mobile = this.student.mobile_no,
    this.emailid = this.student.emailid,
    this.isParent = true;

    this.userData = { 'studentid': this.student.sid,
                      'classid': this.student.classes,
                      'sectionid': this.student.section,
                      'schoolid': this.student.schoolId,
                      'status': 0
                    };
    this.childFeeDefault();                
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad StudentPage');
  }

  childFeeDefault()
  {
      this.authService.postData(this.userData, 'childFeeInfo').then((result)=>{
      this.childfee = result['feeinfo'];
      // getting sum of amount from result
      let total = 0;
      for (var i = 0; i < this.childfee.length; i++) {
          if (this.childfee[i].amount) {
              total+=parseInt(this.childfee[i].amount);
          }
      }
      this.totalAmount = total;
    },(err)=> {
      alert('failled '+err);
    });
  }

  goToFeeDetails()
  {
    this.navCtrl.push(StudentfeePage , {schoolid: this.schoolid, studentid: this.studentid, classid: this.classid, sectionid: this.sectionid, chkValue:this.isParent });
  }

  // total fee pay
  /*payAllFee()
  {
    if(this.isParent === true){
      this.email = localStorage.getItem('useremail');
      this.isParentTrueOrFalse = true;
    }else{
      this.email = this.emailid;
      this.isParentTrueOrFalse = false;
    }

    let payUmoneyAction = global.payUmoneyAction;
    this.userData = { 'totalAmount': this.totalAmount, 'studentid': this.studentid, 'schoolid': this.schoolid, 'classid': this.classid, 'sectionid': this.sectionid,   'email': this.email, 'mobile': this.mobile, 'fathername': this.fathername, 'fee_title':'total fee pay'};
    this.authService.postData(this.userData, 'iPaymentTotal').then((result)=>{
      this.hash_string = result['hash_string'];
      this.hash = result['hash'];
      this.mkey = result['MERCHANT_KEY'];
      this.txnid = result['txnid'];
      this.e_feeid = result['e_feeid'];
      this.e_studentid = result['e_studentid'];
      this.e_schoolid = result['e_schoolid'];

      let target = "_blank";

      var pageContent = '<html><head></head><body><form id="ipayment" action="'+payUmoneyAction+'" method="post">' +

      '<input type="hidden" id="h_schoolid" value="'+this.schoolid+'"/>'+
      '<input type="hidden" id="h_classid" value="'+this.classid+'"/>'+
      '<input type="hidden" id="h_sectionid" value="'+this.sectionid+'"/>'+
      '<input type="hidden" id="h_studentid" value="'+this.studentid+'"/>'+

      '<input type="hidden" name="mkey" value="'+this.hash_string+'"/>'+
      '<input type="hidden" name="key" value="'+this.mkey+'"/>'+
      '<input type="hidden" name="txnid" value="'+this.txnid+'"/>'+
      '<input type="hidden" name="amount" value="'+this.totalAmount+'"/>'+
      '<input type="hidden" name="productinfo" value="total fee pay"/>'+
      '<input type="hidden" name="firstname" id="firstname" value="'+this.fathername+'"/>'+
      '<input type="hidden" name="email" value="'+this.email+'"/>'+
      '<input type="hidden" name="phone" value="'+this.mobile+'"/>'+
      '<input type="hidden" name="address1" value="'+this.isParentTrueOrFalse+'"/>'+
      '<input type="hidden" name="address2" value="0"/>'+ 
      '<input type="hidden" name="city" value="1"/>'+ 
      '<input type="hidden" name="surl" value="'+global.ipaymentResponse+'ipaymentresponse?scid='+this.e_schoolid+'&stid='+this.e_studentid+'&fid='+this.e_feeid+'" size="64"/>'+
      '<input type="hidden" name="furl" value="'+global.ipaymentResponse+'ipaymentresponse?scid='+this.e_schoolid+'&stid='+this.e_studentid+'&fid='+this.e_feeid+'" size="64"/>'+
      '<input type="hidden" name="hash" value="'+this.hash+'"/>'+
      '<input type="hidden" name="service_provider" value="payu_paisa" size="64"/>'+

      '</form> <script type="text/javascript">document.getElementById("ipayment").submit();</script></body></html>';

      let pageContentUrl = 'data:text/html;base64,' + btoa(pageContent);
      let iabRef = this.theInAppBrowser.create(pageContentUrl,target,this.options);

      iabRef.show();
      iabRef.on("loadstop").subscribe(result => {
        if (result.url.match(global.ipaymentResponse+'closePaymentpage')) {
          iabRef.close();
          this.goToFeeDetails(); // after succeessful transaction
        }
      });

    },(err)=> {
      alert('failled '+err);
    });

  }*/


  // ITS DONE BY THE RAZORPAY PAYMENT GATEWAY (AWESOME) (TOTAL)
  payAllFee()
  {
    if(this.isParent === true){
      this.email = localStorage.getItem('useremail');
      this.isParentTrueOrFalse = true;
    }else{
      this.email = this.emailid;
      this.isParentTrueOrFalse = false;
    }
    
    if(this.totalAmount <= 2000){
      var conv = 'If you pay by Debit Card 1.25% applicable';
    }else{
      var conv = 'If you pay by Debit Card 1.5% applicable';
    }
    let alert = this.alertCtrl.create({
      title: '<div class="ccaH">Conveyance Charges Apply</div>',
      message: '<div class="ccaP"><span class="ccaAlertStar">*</span> '+conv+' </div><div class="ccaP"> <span class="ccaAlertStar">*</span> If you pay by Credit Card 1.65% applicable </div><div class="ccaP"> <span class="ccaAlertStar">*</span> If you pay by Net Banking &#8377;30.00 applicable </div><div class="ccaP"> <span class="ccaAlertStar">*</span> If you pay by Mobile wallet (MobiKwik, PayU Money, Airtel Money, PayZapp, Ola Money, FreeCharge) 2.35% applicable</div>',
      enableBackdropDismiss: false,
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
          }
        },
        {
          text: 'Proceed',
          handler: () => {

              this.authService.postData({'studentid':this.studentid,'schoolid':this.schoolid}, 'getStudentAndSchoolName').then((result)=>{
                this.studentschoolname = result['name'];
              },(err)=> {
                // alert('failled '+err);
              });   

              var options = {
                  name: 'Total Fee Pay',
                  description: 'Student Fee',
                  // image: global.apiBaseUrl+'toplogo.png',
                  currency: 'INR',
                  key: 'rzp_test_aGzio06c7dTwxU',
                  amount: this.totalAmount*100,
                  prefill: {
                    method: 'netbanking',
                    email: this.email,
                    contact: this.mobile,
                    name: this.fathername
                  },
                  theme: {
                    color: '#F37254'
                  },
                  modal: {
                    ondismiss: ()=> {
                      // alert('dismissed')
                    }
                  }
                };

                var successCallback = (payment_id)=> {
                  //alert('payment_id: ' + payment_id);
                  let modal = this.modalCtrl.create(PaymentResponsePage,
                    {
                      status:'success',
                      transactionid:payment_id,
                      schoolid:this.schoolid, 
                      studentid:this.studentid, 
                      classid:this.classid, 
                      sectionid:this.sectionid,
                      feeid:0, 
                      feetitle:'total fee pay', 
                      amount:this.totalAmount, 
                      email:this.email, 
                      mobile:this.mobile, 
                      fathername:this.fathername,
                      address:'', 
                      address1:this.isParentTrueOrFalse,
                      address2:0,
                      city:1,
                      studentname:this.studentschoolname['studentname'],
                      schoolname:this.studentschoolname['schoolname'],
                      schoollogopath:this.studentschoolname['LogoPath'],           
                    },{'enableBackdropDismiss':false});
                    modal.onDidDismiss(() => {
                      this.childFeeDefault();
                      this.viewCtrl.dismiss();
                      this.navCtrl.setRoot(HomePage, {animate:true,animation:'transition',duration:600,direction:'forward'});
                    });
                    modal.present(); 
                };
                var cancelCallback = (error)=> {
                  //alert(error.description + ' (Error ' + error.code + ')');
                };
                RazorpayCheckout.open(options, successCallback, cancelCallback);
              }
            }
            ],
            cssClass: 'ccaAlert'
            });
            alert.present();
  }

  addChild()
  {
    //alert(this.mobile);
    if(this.mobile){
      this.authService.postData({'mobileno':this.mobile}, 'addChildRequest').then((result)=>{
        //this.studentschoolname = result['name'];
        if(result['response'] == 1){
          localStorage.setItem('sess_vcode', result['vcode']);
          // let toast = this.toastCtrl.create({  message: 'Varification Code sent !', duration: 3000 });
          // toast.present();

          let prompt = this.alertCtrl.create({
            title: 'Varification Code',
            enableBackdropDismiss: false,
            message: "Please enter varification code which is sent on your mobile number by Ribblu.com to add this child.",
            inputs: [
              {
                name: 'varificationcode',
                placeholder: 'enter 5 digit code',
                type: 'number'
              },
            ],
            buttons: [
              {
                text: 'Cancel',
                handler: data => {
                  localStorage.removeItem('sess_vcode');
                  console.log('Cancel clicked');
                }
              },
              {
                text: 'Verify',
                handler: data => {

                  if(data.varificationcode == ''){
                    let toast = this.toastCtrl.create({ message: 'Please enter varification code !', duration: 8000 });
                    toast.present();
                    return false;
                  }
                
                  this.authService.postData({'e_vcode':data.varificationcode,'sess_vcode':localStorage.getItem('sess_vcode'),'useremail':localStorage.getItem('useremail'),'mobile':this.mobile}, 'verifyToAddChild').then((result)=>{
                      if(result['varify_response'] == 1){
                          localStorage.removeItem('sess_vcode');
                          let toast = this.toastCtrl.create({ message: result['msg'], duration: 8000 });
                          toast.present();
                          prompt.dismiss();
                          //this.viewCtrl.dismiss();
                          // go back 2 times
                            const index = this.navCtrl.getActive().index;
                            this.navCtrl.remove(index-1);
                            this.navCtrl.remove(index-2);
                          //
                          this.navCtrl.setRoot(HomePage,{animate:true,animation:'transition',duration:600,direction:'forward'});
                      }else if(result['varify_response'] == 0) {
                          let toast = this.toastCtrl.create({ message: result['msg'], duration: 3000 });
                          toast.present();
                      }else{
                          let toast = this.toastCtrl.create({ message: 'Sorry ! something went wrong.', duration: 3000 });
                          toast.present();
                      }
                  },(err)=> {
                      alert('failled '+err);
                  });
                  return false;

                }
              }
            ]
          });
          prompt.present();

        }else{
          let toast = this.toastCtrl.create({  message: 'Sorry! something went wrong.', duration: 3000 });
          toast.present();
        }
      },(err)=> {
        alert('failled '+err);
      }); 
    }else{
      let toast = this.toastCtrl.create({  message: 'Please update your contact number first !', duration: 3000 });
      toast.present();
    }
  }










}
