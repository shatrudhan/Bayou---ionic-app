import { Component } from '@angular/core';
import { ModalController, App,PopoverController, NavController, NavParams, LoadingController, ToastController } from 'ionic-angular';

import { AuthServiceProvider } from './../../../providers/parent/auth-service/auth-service';
import { global } from "../../../app/global";
import { FeePage } from '../fee/fee';
import { QueryPage } from '../query/query';
import { AttendanceviewPage } from '../attendanceview/attendanceview';
import { ExamTermPage } from '../exam-term/exam-term';
import { NoticeBoardPage } from '../notice-board/notice-board';
import { PopoverPage } from '../popover/popover';
import { BusroutePage } from '../busroute/busroute';
import { PCurriculumPage } from '../p-curriculum/p-curriculum';
import { PLatestNewsPage } from '../p-latest-news/p-latest-news';
import { PCalendarPage } from '../p-calendar/p-calendar';
import { PFeeStructurePage } from '../p-fee-structure/p-fee-structure';
import { PExamResultPage } from '../p-exam-result/p-exam-result';
import { PExamSchedulePage } from '../p-exam-schedule/p-exam-schedule';
import { TrackingPage } from '../tracking/tracking';

import { PHandBookPage } from '../p-hand-book/p-hand-book';
import { PasswordPage } from '../password/password';
import { MyprofilePage } from '../myprofile/myprofile';
  
@Component({
  selector: 'page-user',
  templateUrl: 'user.html',
})
export class UserPage {
  schoolname: any;
  busarea: any;
  busstop: any;
  busincharge: any;
  CapitalizeName: any;
  ucName: any;
  schoolid: any;
  studentid: any;
  classid: any;
  sectionid: any;
  studentname: any;

  globalVar: any;
  userData = {'useremail':localStorage.getItem('useremail')};

  constructor(
		      public navCtrl: NavController,
          public navParams: NavParams,
          public authservice: AuthServiceProvider,
          public loadingCtrl: LoadingController,
          public toastCtrl: ToastController,
          public popoverCtrl: PopoverController, 
          public app:App,
          public modalCtrl: ModalController,          
			 )
  {
     // API domain URL as global variable
     this.globalVar = global.apiBaseUrl;

     this.schoolid = this.navParams.get('schoolid');
     this.studentid = this.navParams.get('studentid');
     this.classid = this.navParams.get('classid');
     this.sectionid = this.navParams.get('sectionid');
     this.studentname = this.navParams.get('studentname');
     this.busarea = this.navParams.get('busarea');
     this.busstop = this.navParams.get('busstop');
     this.busincharge = this.navParams.get('busincharge');
     this.schoolname = this.navParams.get('schoolname');     
     

     // only getting Catitalize name
      this.ucName = this.studentname.toLowerCase();
      this.CapitalizeName = this.ucName.substring(0,1).toUpperCase()+this.ucName.substring(1);
     //

  }

  ionViewDidLoad()
  {
    console.log('ionViewDidLoad UserPage');
  }

  MorePopOver(myEvent) 
  {
    let popover = this.popoverCtrl.create(PopoverPage);
    popover.present({
      ev: myEvent
    });
  }

  feePage()
  {
    this.navCtrl.push(FeePage , {studentname:this.CapitalizeName, schoolid: this.schoolid, studentid: this.studentid, classid: this.classid, sectionid: this.sectionid });
  }

  trackingPage()
  {
    //this.navCtrl.push(BusroutePage , {studentname:this.CapitalizeName, schoolid: this.schoolid, studentid: this.studentid, busid: this.busarea, busstop: this.busstop, busincharge: this.busincharge });
    let modal = this.modalCtrl.create(BusroutePage, {studentname:this.CapitalizeName, schoolid: this.schoolid, studentid: this.studentid, busid: this.busarea, studentBusStop: this.busstop, busInchargeName: this.busincharge });
    modal.present();
  }

  myqueriesPage()
  {
    this.navCtrl.push(QueryPage , {studentname:this.CapitalizeName,schoolid: this.schoolid, studentid: this.studentid, classid: this.classid, sectionid: this.sectionid });
  }

  attendancePage()
  {
    this.navCtrl.push(AttendanceviewPage , {studentname:this.CapitalizeName, studentid: this.studentid });
  }

  reportcardPage()
  {
    this.navCtrl.push(ExamTermPage , {studentname:this.CapitalizeName,schoolid: this.schoolid, studentid: this.studentid, classid: this.classid, sectionid: this.sectionid });
  }

  noticeboardPage()
  {
    this.navCtrl.push(NoticeBoardPage , {studentname:this.CapitalizeName,schoolid: this.schoolid, classid: this.classid, sectionid: this.sectionid });
  }

  curriculumPage()
  {
    this.navCtrl.push(PCurriculumPage , {studentname:this.CapitalizeName,schoolid: this.schoolid, schoolname:this.schoolname });
  }

  latestnewsPage()
  {
    this.navCtrl.push(PLatestNewsPage , {studentname:this.CapitalizeName,schoolid: this.schoolid, schoolname:this.schoolname });
  }

  calendarPage()
  {
    this.navCtrl.push(PCalendarPage , {studentname:this.CapitalizeName,schoolid: this.schoolid, schoolname:this.schoolname });    
  }

  feestructurePage()
  {
    this.navCtrl.push(PFeeStructurePage , {studentname:this.CapitalizeName,schoolid: this.schoolid, schoolname:this.schoolname });        
  }

  examschedulePage()
  {
    this.navCtrl.push(PExamSchedulePage , {studentname:this.CapitalizeName,schoolid: this.schoolid, schoolname:this.schoolname });            
  }

  examresultPage()
  {
    this.navCtrl.push(PExamResultPage , {studentname:this.CapitalizeName,schoolid: this.schoolid, schoolname:this.schoolname });            
  }

  handbookPage()
	{
		this.navCtrl.push(PHandBookPage , {studentname:this.CapitalizeName,schoolid: this.schoolid, classid: this.classid, sectionid: this.sectionid });
	}

	profile()
	{
    //this.viewCtrl.dismiss();
		let modal = this.modalCtrl.create(MyprofilePage);
		modal.present();
	}

	password()
	{
    //this.viewCtrl.dismiss();
		let modal = this.modalCtrl.create(PasswordPage);
		modal.present();
	}

  trackingTestPage()
  {
    this.navCtrl.push(TrackingPage , {studentname:this.CapitalizeName, schoolid: this.schoolid, studentid: this.studentid, busid: this.busarea, studentBusStop: this.busstop, busInchargeName: this.busincharge });
  }




}
