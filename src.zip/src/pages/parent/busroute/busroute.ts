import { Component, ViewChild, ElementRef } from '@angular/core';
import { NavController, ActionSheetController, Platform, NavParams, LoadingController, ToastController, ModalController, ViewController } from 'ionic-angular';
import { AuthServiceProvider } from './../../../providers/parent/auth-service/auth-service';
import { global } from "../../../app/global";

import { FirebaseProvider } from './../../../providers/parent/firebase/firebase';
import { FirebaseListObservable,AngularFireDatabase } from 'angularfire2/database';
import { Geolocation } from '@ionic-native/geolocation';

/*
import {
  GoogleMaps,
  GoogleMap,
  GoogleMapsEvent,
  GoogleMapOptions,
  CameraPosition,
  MarkerOptions,
  Marker
 } from '@ionic-native/google-maps';
 */

declare var google;

@Component({
  selector: 'page-busroute',
  templateUrl: 'busroute.html',
})

export class BusroutePage {
  noLocationToast: any;
  studentname: any;
  
  _fromlocation: any; _tolocation: any; infowindow: any; distance: any; 
  markerOption: any;

   directionsDisplay: any;
   bll: any;

   infoDis: any;

   polyLineCoordinates: any;
   busLocation: string;

   public isLoadMap: boolean;
   markerObj: any;

   startLongitude: number; startLatitude: number;
   endLatitude: number; endLongitude: number;

   getLatLong: FirebaseListObservable<any[]>;
   busStopLong: any; busStopLat: any;
   
   studentid: any; schoolid: any; busid: any;  busStop: any; busInchargeName: any;

   @ViewChild('map') mapElement: ElementRef;
   map: any;

  constructor(
              public navCtrl: NavController,
              public navParams: NavParams,
              public authservice: AuthServiceProvider,
              public loadingCtrl: LoadingController,
              public toastCtrl: ToastController,
              public modalCtrl: ModalController,
              public viewCtrl: ViewController, 
              public actionSheetCtrl: ActionSheetController,
              public platform: Platform, 
              public geolocation: Geolocation,
              public firebaseProvider: FirebaseProvider,
              public afd: AngularFireDatabase,
             )
  {
    this.schoolid = this.navParams.get('schoolid');
    this.studentid = this.navParams.get('studentid');
    this.busid = this.navParams.get('busid');   
    this.busInchargeName = this.navParams.get('busInchargeName');      
    this.busStop = this.navParams.get('studentBusStop');
    this.studentname = this.navParams.get('studentname');    

    // let toast = this.toastCtrl.create({ message: 'busid1 : '+this.busid+' , schoolid : '+this.schoolid+', bus stop 1: '+this.busStop, duration: 8000 });
    // toast.present();

    this.isLoadMap = true;
    this.markerObj = [];
    
    this.getCoordinates();
    this.StudentBusStopLocation();
  }

  mapModalDismiss()
  {
    this.viewCtrl.dismiss();
    this.noLocationToast.dismiss();
  }
  
  getCoordinates()
  {
    this.getLatLong = this.firebaseProvider.getBusRoute(this.schoolid,this.busid);
    this.getLatLong.subscribe(res=>{

      if(res.length != 0){
        this.startLatitude = res[0].lat; // start latitude
        this.startLongitude = res[0].long; // start longitude
        this.endLatitude = res[res.length-1].lat; // end latitude
        this.endLongitude = res[res.length-1].long; // end longitude
        this.busLocation = 'YES';
        this.busMap(); 
      }else{
        this.geolocation.getCurrentPosition().then((position) => {
          this.endLatitude = position.coords.latitude;
          this.endLongitude = position.coords.longitude;
          this.busLocation = 'NO';
          this.busMap();
          this.noLocationToast = this.toastCtrl.create({ message: 'Location not found ! Try again.', position: 'middle', 'cssClass':'toastText',  duration: 10000 });
          this.noLocationToast.present(); 
          setTimeout (() => {
            this.mapModalDismiss();
          }, 11000)
        });
      }

    });
  }

  busMap()
  {
    this.platform.ready()
    .then(() => {
      // MAP CREATION
      if(this.isLoadMap == true){ 
        let mapOptions = {
          zoom: 15,
          mapTypeId: google.maps.MapTypeId.ROADMAP,
        }
        this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
        this.isLoadMap = false;

        // BUS STOP MARKER
        var infowindow = new google.maps.InfoWindow({
          content: "<div class='infowindowDiv'>"+this.busStop+"</div>",
        });
        let busStopMarkerOption = new google.maps.Marker({
          map: this.map,
          animation: google.maps.Animation.DROP,
          position: {lat: this.busStopLat, lng: this.busStopLong}       
        });
        infowindow.open(this.map,busStopMarkerOption);
      }  

      this.busMarker();
      this.busPolylines();   
      //this.BusStop_Marker_RoadMap();   
    });
  }

  busMarker()
  {
    
    // GETTING MARKER IN CENTER ALWAYS
    var panPoint = new google.maps.LatLng(this.endLatitude, this.endLongitude);
    this.map.panTo(panPoint);

    if(this.busLocation == 'YES'){

      // DISTANCE B/W 2 LOCATION POINT
      this._tolocation = new google.maps.LatLng(this.busStopLat, this.busStopLong);
      this._fromlocation = new google.maps.LatLng(this.endLatitude, this.endLongitude);
      this.distance = google.maps.geometry.spherical.computeDistanceBetween(this._tolocation,this._fromlocation);
    
      if(this.distance < 1000){
        this.infoDis = parseFloat(this.distance.toFixed(0))+" Metre";      
      }else{
        this.infoDis = parseFloat((this.distance/1000).toFixed(1))+' Km';
      }

      if(this.distance < 2000){
        this.authservice.postData({'schoolid':this.schoolid,'busid':this.busid}, 'BusLocationNotificationToParent').then((result)=>{
          if(result['response'] == 1){
            console.log('notification has been sent.');
          }
        });
      }         
      // INFORMATION ON MARKER
      this.infowindow = new google.maps.InfoWindow({
        content: "<div class='infowindowDiv'>"+this.infoDis+"</div>",
      });

      this.markerObj.push(this.infowindow);
      for (let i = 0; i < this.markerObj.length; i++) {
        if(i < this.markerObj.length-1){
          this.markerObj[i].setMap(null);
        }
      }
      // BY DEFAULT OPEN MARKER INFO
      this.infowindow.open(this.map,this.markerOption);
      

      // MAKE NEW MARKER
      if(this.markerOption == null){
        this.markerOption = new google.maps.Marker({
          map: this.map,
          draggable: true,
          icon: 'assets/images/bus.png',   // https://maps.gstatic.com/mapfiles/transit/iw2/6/bus.png
          position: {lat: this.endLatitude, lng: this.endLongitude},       
        });
      }
      // BOUNCE ANIMATION REMOVE
      this.markerOption.setAnimation(null); 
      this.markerOption.setPosition(new google.maps.LatLng(this.endLatitude, this.endLongitude));
      
    }
  }

  busPolylines()
  {
    // POLYLINES
    this.getLatLong = this.firebaseProvider.getBusRoute(this.schoolid,this.busid);
    this.getLatLong.subscribe(res=>{
      this.polyLineCoordinates = [];
      for(let i = 0; i < res.length; i++) {
        this.polyLineCoordinates.push(new google.maps.LatLng(res[i].lat , res[i].long));
      }
    });
    let busPath = new google.maps.Polyline({
      path: this.polyLineCoordinates,
      geodesic: true,
      strokeColor: '#DB280C',
      strokeOpacity: 1.0,
      strokeWeight: 3
    });
    busPath.setMap(this.map);
  }

 StudentBusStopLocation()
 {
    var geocoder = new google.maps.Geocoder();
    var address = this.busStop;
    geocoder.geocode({ 'address': address }, (results, status)=> {
        if (status == google.maps.GeocoderStatus.OK) {
            this.busStopLat = results[0].geometry.location.lat();
            this.busStopLong = results[0].geometry.location.lng();
        } else {
            let toast = this.toastCtrl.create({ message: 'Update student bus stop location.', 'cssClass':'toastText', duration: 5000 });
            toast.present();
        }
    });
  }

  BusStop_Marker_RoadMap()
  {
    // ROUTE MAP FROM BUS STOP TO LAST LOCATION OF SCHOOL BUS
    /*
    if(this.directionsDisplay){
      this.directionsDisplay.setMap(null);
    }
    var directionsService = new google.maps.DirectionsService();
    this.directionsDisplay = new google.maps.DirectionsRenderer();
    
    this.directionsDisplay.setMap(this.map);

    this.directionsDisplay.setOptions({ 
      suppressMarkers: true,
      polylineOptions: {
          strokeWeight: 3,
          strokeOpacity: 1,
          strokeColor:  '#0B8905' 
      }
    });
    
    directionsService.route({
      origin: new google.maps.LatLng(this.endLatitude ,this.endLongitude),
      destination : new google.maps.LatLng(this.busStopLat , this.busStopLong),
      travelMode: 'DRIVING'
    }, (response)=> {
      this.directionsDisplay.setDirections(response);
    });
    */
  }





  
  }