import { AdmissionenquirydetailPage } from './../admissionenquirydetail/admissionenquirydetail';
import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { ToastController } from 'ionic-angular/components/toast/toast-controller';
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { LoadingController } from 'ionic-angular/components/loading/loading-controller';

/**
 * Generated class for the AdmissionenquiriesPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-admissionenquiries',
  templateUrl: 'admissionenquiries.html',
})
export class AdmissionenquiriesPage {

  schoolName: string;
  selectedItem: any;
  icons: string[];
  items: Array<{name: string,emailid: string, comment: string, reviewid: number}>;
  myLoadingControl: any;
  loader: any;
  responseData: any;
  postData: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public authservice: AuthServiceProvider, public toastCtrl: ToastController, public loadingCtrl: LoadingController) {
    this.schoolName = window.localStorage.getItem('schoolname');
    this.myLoadingControl = loadingCtrl;
    this.postData = {schoolid: window.localStorage.getItem('schoolid')};
    this.items = [];
    this.loadEnquires();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AdmissionenquiriesPage');
  }

  loadEnquires(){
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {
      this.authservice.postData(this.postData, 'admissionenquiries/get').then((result)=>{
  		this.responseData = result;
  		console.log(this.responseData);
        if(this.responseData['response'] == 1){
          this.items = this.responseData['enquiries'];
        }
        this.loader.dismissAll();
  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismissAll();
  	  });
    });
  }

  itemTapped(cmtId){
    this.navCtrl.push(AdmissionenquirydetailPage, {enquiryid: cmtId});
  }

}
