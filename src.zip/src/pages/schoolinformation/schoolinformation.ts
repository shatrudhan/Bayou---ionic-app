import { global } from './../../app/global';
import { Transfer, TransferObject } from '@ionic-native/transfer';
import { FilePath } from '@ionic-native/file-path';
import { SchooladditionalinformationPage } from './../schooladditionalinformation/schooladditionalinformation';
import { SchoolbasicinformationPage } from './../schoolbasicinformation/schoolbasicinformation';
import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, ToastController, ModalController, ActionSheetController, Platform, Loading } from 'ionic-angular';
import { Camera } from '@ionic-native/camera';
import { Crop } from '@ionic-native/crop';
import { File } from '@ionic-native/file';
/**
 * Generated class for the SchoolinformationPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

declare var cordova: any;

@Component({
  selector: 'page-schoolinformation',
  templateUrl: 'schoolinformation.html',
})
export class SchoolinformationPage {

  schoolName: string;
  address: string;
  statecity: string;
  pincode: string;
  contactno: string;
  emailid: string;
  website: string;
  schooltype: string;
  category: string;
  loader: any;
  myLoadingCtrl: any;
  responseData: any;
  postData: any;

  establishmentyear: any;
  medium: any;
  educationboard: any;
  principalname: string;
  gender: string;
  feesrange: string;

  lastImage: string = null;
  loading:  Loading;

  logo: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public loadingCtrl: LoadingController, public authservice: AuthServiceProvider, public toastCtrl: ToastController, public modalCtrl: ModalController, public camera: Camera, public cropCtrl: Crop, public actionSheetCtrl: ActionSheetController, public platform: Platform, public filePath: FilePath, public file: File, public transfer: Transfer) {
    this.schoolName = window.localStorage.getItem('schoolname');
    this.myLoadingCtrl = loadingCtrl;
    this.postData = {schoolid: window.localStorage.getItem('schoolid')};
    this.getInformation();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SchoolinformationPage');
  }

  getInformation(){

    this.loader = this.myLoadingCtrl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {
      
      this.authservice.postData(this.postData, 'getinformation').then((result)=>{
        
        this.responseData = result;
  		  console.log(this.responseData);
  		  if(this.responseData['response'] == 1){

          this.address = this.responseData['basic'][0]['address'];
          if (this.responseData['basic'][0]['localityarea'] != "")
            this.address = this.address + ', ' + this.responseData['basic'][0]['localityarea'];
          
          this.address = this.address;
          this.statecity = this.responseData['basic'][0]['city'] + ' (' + this.responseData['basic'][0]['state'] + ')-' + this.responseData['basic'][0]['pincode'];

          this.contactno = this.responseData['basic'][0]['contactno'];
          this.emailid = this.responseData['basic'][0]['emailid'];
          this.website = this.responseData['basic'][0]['websitename'];
          this.schooltype = this.responseData['basic'][0]['schooltype'];
          this.category = this.responseData['basic'][0]['category'];

          this.establishmentyear = this.responseData['additional'][0]['establishmentyear'];
          this.medium = this.responseData['additional'][0]['medium'];
          this.gender = this.responseData['additional'][0]['gender'];
          this.feesrange = this.responseData['additional'][0]['feerange'];
          this.principalname = this.responseData['additional'][0]['principlename'];
          this.educationboard = this.responseData['additional'][0]['educationboard'];

          this.logo = this.responseData['basic'][0]['logopath'];

        } 

        this.loader.dismiss();       

  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismiss();
  	  });

      //this.loader.dismiss();
      
    });
    
  }

  editInformation()
  {
    let modal = this.modalCtrl.create(SchoolbasicinformationPage, {myObj: this});
    modal.present();
  }

  editAdditionalInformation()
  {
    let modal = this.modalCtrl.create(SchooladditionalinformationPage, {myObj: this});
    modal.present();
  }



  /********************  PROFILE PHOTO UPLOAD STARTING HERE  ******************/

  setProfilePhoto() {
    let actionSheet = this.actionSheetCtrl.create({
      title: 'Select Profile Photo',
      buttons: [
        {
          text: 'Choose Gallery',
          handler: () => {
            this.takePicture(this.camera.PictureSourceType.PHOTOLIBRARY);
          }
        },
        {
          text: 'Use Camera',
          handler: () => {
            this.takePicture(this.camera.PictureSourceType.CAMERA);
          }
        },
        {
          text: 'Cancel',
          role: 'cancel'
        }
      ]
    });
    actionSheet.present();
  }

  public takePicture(sourceType) {
    // Create options for the Camera Dialog
    var options = {
      quality: 100,
      sourceType: sourceType,
      saveToPhotoAlbum: false,
      correctOrientation: true
    };
   
    // Get the data of an image
    this.camera.getPicture(options).then((imagePath) => {
      // Special handling for Android library
      if (this.platform.is('android') && sourceType === this.camera.PictureSourceType.PHOTOLIBRARY) {
        this.filePath.resolveNativePath(imagePath)
          .then(filePath => {

            this.cropCtrl.crop(filePath, {quality: 100}).then(newImage => {

              let correctPath = newImage.substr(0, newImage.lastIndexOf('/') + 1);
              let currentName = newImage.substring(newImage.lastIndexOf('/') + 1, newImage.lastIndexOf('?'));
              this.copyFileToLocalDir(correctPath, currentName, this.createFileName());

            });

            
          });
      } 
      else if (this.platform.is('ios') && sourceType === this.camera.PictureSourceType.PHOTOLIBRARY) {
        //this.filePath.resolveNativePath(imagePath)
          //.then(filePath => {

            this.cropCtrl.crop(imagePath, {quality: 100}).then(newImage => {

              let correctPath = newImage.substr(0, newImage.lastIndexOf('/') + 1);
              let currentName = imagePath.substring(imagePath.lastIndexOf('/') + 1, imagePath.lastIndexOf('?'));
              this.copyFileToLocalDir(correctPath, currentName, this.createFileName());
         
            });

            
          //});
      } 
      else if (this.platform.is('android') && sourceType === this.camera.PictureSourceType.CAMERA)
      {
        

        this.cropCtrl.crop(imagePath, {quality: 100}).then(newImage => {
          
          this.presentToast(newImage);
          var currentName = newImage.substr(newImage.lastIndexOf('/') + 1);
          currentName = currentName.substr(0, currentName.lastIndexOf("?"));
          var correctPath = newImage.substr(0, newImage.lastIndexOf('/') + 1);
          this.copyFileToLocalDir(correctPath, currentName, this.createFileName());

        });

      }
      else 
      {
        

        this.cropCtrl.crop(imagePath, {quality: 100}).then(newImage => {

          this.presentToast(newImage);
          var currentName = newImage.substr(newImage.lastIndexOf('/') + 1);
          var correctPath = newImage.substr(0, newImage.lastIndexOf('/') + 1);
          this.copyFileToLocalDir(correctPath, currentName, this.createFileName());

        });

      }
    }, (err) => {
      this.presentToast('Error while selecting image.'+err);
    });
  }

  // Create a new name for the image
  public createFileName() {
  var d = new Date(),
  n = d.getTime(),
  newFileName =  n + ".jpg";
  return newFileName;
}
 
// Copy the image to a local folder
public copyFileToLocalDir(namePath, currentName, newFileName) {
  this.file.copyFile(namePath, currentName, cordova.file.dataDirectory, newFileName).then(success => {
    this.lastImage = newFileName;
    this.uploadImage();
  }, error => {
    //this.presentToast('Error while storing file.' + error);
  });
}
 
public presentToast(text) {
  let toast = this.toastCtrl.create({
    message: text,
    duration: 3000,
    position: 'bottom'
  });
  toast.present();
}
 
// Always get the accurate path to your apps folder
public pathForImage(img) {
  if (img === null) {
    return '';
  } else {
    return cordova.file.dataDirectory + img;
  }
}

public uploadImage() {
    // Destination URL
    let url = global.apiUrl+'logoUpload';

    // File for Upload
    var targetPath = this.pathForImage(this.lastImage);
    
    // File name only
    var filename = this.lastImage;
    
    var options = {
      fileKey: "file",
      fileName: filename,
      chunkedMode: false,
      mimeType: "multipart/form-data",
      params : {'fileName': filename, 'schoolid': localStorage.getItem('schoolid')}
    };
    
    const fileTransfer: TransferObject = this.transfer.create();
    
    this.loading = this.loadingCtrl.create({
      content: 'Uploading...',
    });
    this.loading.present();
    
    // Use the FileTransfer to upload the image
    fileTransfer.upload(targetPath, url, options ).then((data) => {
      this.loading.dismissAll();
      //this.uploadLogo(); 
      let fuResponse = JSON.parse(data.response);
      if (fuResponse['response'] == 1)
      {
        this.logo = fuResponse['logopath'];
        this.presentToast('Logo uploaded successfully');  
      }
      else
        this.presentToast('Sorry! unable to process your request');
    }, err => {
      this.loading.dismissAll();
      this.presentToast('Something went wrong, Try again.');
      //this.uploadLogo();
    });

  }

/********************  PROFILE PHOTO UPLOAD ENDS HERE  ******************/

}
