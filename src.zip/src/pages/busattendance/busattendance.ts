import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, ToastController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { FirebasedbProvider } from './../../providers/firebasedb/firebasedb';


@Component({
  selector: 'page-busattendance',
  templateUrl: 'busattendance.html',
})
export class BusattendancePage {
  items: Array<{studentname: string, rollno: number, sid: number}>;
  myLoadingControl: any;
  loader: any;
  responseData: any;
  postData: any;
  studentArray: Array<{studentid: number}>;
  studentArray_ab: Array<{studentid: number}>;  
  submitPostData: any;

  constructor(public fbProvider: FirebasedbProvider,public navCtrl: NavController, public navParams: NavParams, public loadingCtrl: LoadingController, public authservice: AuthServiceProvider, public toastCtrl: ToastController) {
    this.myLoadingControl = loadingCtrl;
    this.items = [];
    this.studentArray = [];
    this.studentArray_ab = [];    
    this.postData = {teacherid: window.localStorage.getItem('teacherid'), schoolid: window.localStorage.getItem('schoolid'), busid: window.localStorage.getItem('busid')};
    this.submitPostData = {busid: window.localStorage.getItem('busid'), schoolid: window.localStorage.getItem('schoolid'), students: ''};
    this.submitPostData.students = [];
    this.getStudents();
  }

  getStudents(){
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {
      this.authservice.postData(this.postData, 'getbusstudents').then((result)=>{
  		this.responseData = result;
  		console.log(this.responseData);
  		if(this.responseData['response'] == 1){
        this.items = this.responseData['students'];
        for(let data of this.responseData['students'])
        {
            if (data['ispresent'] == "true")
              this.studentArray.push(data['sid']);
            else
              this.studentArray_ab.push(data['sid']);            
        }
        if (this.responseData['isattendance'] == 1)
        {
          let toast = this.toastCtrl.create({
    				  message: "Today's attendance has already been submitted!",
    				  duration: 3000
    				});
    			toast.present();
        }
        this.loader.dismiss();
  		}else{
        this.loader.dismiss();
  		}
  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismiss();
  	  });
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad BusattendancePage');
  }

  doAttendance()
  {
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.submitPostData.students = this.studentArray;
    this.submitPostData.students_ab = this.studentArray_ab;    

    this.loader.present().then(() => {
      this.authservice.postData(this.submitPostData, 'submitbusattendance').then((result)=>{
  		this.responseData = result;
  		console.log(this.responseData);
  		if(this.responseData['response'] == 1){
        // this.fbProvider.BusAttendancePushMessage(localStorage.getItem('schoolid'), this.submitPostData.students);        
        let toast = this.toastCtrl.create({
            message: "Attendance has been submitted successfuly!",
            duration: 3000
          });
        toast.present();
        this.loader.dismiss();
        this.navCtrl.pop(this);
  		}else{
        let toast = this.toastCtrl.create({
            message: "Sorry! unable to process your request",
            duration: 3000
          });
        toast.present();
        this.loader.dismiss();
  		}
  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismiss();
  	  });
    });
  }

  addStudent(event, studentid)
  {
    if (!event.checked)
    {
      let index = this.studentArray.indexOf(studentid);
      this.studentArray.splice(index, 1);
      this.studentArray_ab.push(studentid);        
    }
    else
    {
      let index = this.studentArray_ab.indexOf(studentid);      
      this.studentArray_ab.splice(index, 1);  
      this.studentArray.push(studentid);          
    }
  }

}
