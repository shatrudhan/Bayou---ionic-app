import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, ToastController, AlertController, ModalController, ViewController } from 'ionic-angular';

/**
 * Generated class for the FacilitiesPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-facilities',
  templateUrl: 'facilities.html',
})
export class FacilitiesPage {

  schoolName: string;
  loader: any;
  myLoadingControl: any;
  postData: any;
  responseData: any;
  items: Array<{facilityname: string, facilityid: number}>;
  submitPostData: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public loadingCtrl: LoadingController, public authservice: AuthServiceProvider, public toastCtrl: ToastController, public alertCtrl: AlertController, public modalCtrl: ModalController) {

    this.items = [];
    this.schoolName = localStorage.getItem('schoolname');
    this.myLoadingControl = loadingCtrl;
    this.postData = {schoolid: window.localStorage.getItem('schoolid')};
    this.submitPostData = {schoolid: window.localStorage.getItem('schoolid'), facilityid: 0};
    this.loadFacilities();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad FacilitiesPage');
  }

  loadFacilities(){

    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {
      
      this.authservice.postData(this.postData, 'facilities/get').then((result)=>{
        
        this.responseData = result;
  		  console.log(this.responseData);
  		  if(this.responseData['response'] == 1){
          this.items = this.responseData['facilities'];
        }

        this.loader.dismiss();

  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismiss();
  	  });
      
    });
    
  }

  deleteFacility(facility){

    let confirm = this.alertCtrl.create({
      title: 'Confirmation',
      message: 'Are you sure? you want to remove this facility',
      buttons: [
        {
          text: 'Yes',
          handler: () => {
            
            this.loader = this.myLoadingControl.create({
              content : "Please wait.."
            });

            this.loader.present().then(() => {
              
              this.submitPostData.facilityid = facility;
              this.authservice.postData(this.submitPostData, 'facilities/delete').then((result)=>{
                
                this.responseData = result;
                console.log(this.responseData);
                if(this.responseData['response'] == 1){
                  
                  this.loader.dismiss();
                  
                  let alert = this.alertCtrl.create({
                    title: 'Successful!',
                    subTitle: 'Selected facility has been removed successfully from school information.',
                    buttons: ['OK']
                  });
                  alert.present();

                  let index = 0;
                  for(let i=0;i<this.items.length;i++)
                  {
                    if (this.items[i].facilityid == facility)
                    {
                      index = i;
                      break;
                    }
                  }

                  this.items.splice(index, 1);

                }
                else
                {
                  this.loader.dismiss();
                  let toast = this.toastCtrl.create({
                      message: "Sorry! we are unable to process your request",
                      duration: 3000
                    });
                  toast.present();
                  this.loader.dismiss();
                }

                

              },(err)=> {
                  //alert('failled '+err);
                  let toast = this.toastCtrl.create({
                      message: err,
                      duration: 3000
                    });
                  toast.present();
                  this.loader.dismiss();
              });
              
            });

          }
        },
        {
          text: 'No',
          handler: () => {
            console.log('Agree clicked');
          }
        }
      ]
    });
    confirm.present();

  }

  addFacility()
  {
    let modal = this.modalCtrl.create(AddFacilities, {myObj: this});
    modal.present();
  }

}





@Component({
  selector: 'page-facilities',
  template: `<ion-header>
                <ion-navbar>
                  <ion-searchbar (input)="getItems($event)" start></ion-searchbar>
                  <ion-buttons end>
                    <button ion-button (click)="modalDismiss()">
                      <ion-icon name="close"></ion-icon>
                    </button>
                  </ion-buttons>
                </ion-navbar>                
             </ion-header>

            <ion-content>
              <ion-list>
                <ion-item *ngFor="let item of childItems">
                  <ion-label>{{item.facilityname}}</ion-label>
                  <ion-checkbox color="dark" checked="false" (ionChange)="addFacility($event, item.facilityid)"></ion-checkbox>
                </ion-item>
              </ion-list>
            </ion-content>
            <ion-footer>
              <ion-toolbar>
                <ion-buttons end>
                  <button ion-button icon-right color="royal" (click)="addToSchool()">
                    Submit
                    <ion-icon name="send"></ion-icon>
                  </button>
                </ion-buttons>
              </ion-toolbar>
            </ion-footer>
            `
})


export class AddFacilities {
  
  childLoader: any;
  myChildLoadingControl: any;
  childPostData: any;
  childResponseData: any;
  childItems: Array<{facilityname: string, facilityid: number}>;
  actualItems: Array<{facilityname: string, facilityid: number}>;
  submitFacilities: any;
  myFacilities: any;
  facilities: Array<{facilityid: number}>;

  constructor(
              public navCtrl: NavController,
              public navParams: NavParams,
              public authservice: AuthServiceProvider,
              public childLoadingCtrl: LoadingController,
              public toastCtrl: ToastController,
              public modalCtrl: ModalController,
              public viewCtrl: ViewController,
              public alertCtrl: AlertController
             )
  {
    this.myChildLoadingControl = childLoadingCtrl;
    this.childPostData = {schoolid: window.localStorage.getItem('schoolid')};
    this.submitFacilities = {schoolid: window.localStorage.getItem('schoolid'), facilities: ''};
    this.submitFacilities.facilities = [];
    this.childItems = [];
    this.actualItems = [];
    this.facilities = [];
    this.myFacilities = navParams.get('myObj');
    this.loadAllFacilities();
  }

  modalDismiss()
  {
    this.viewCtrl.dismiss();
  }

  loadAllFacilities(){

    this.childLoader = this.myChildLoadingControl.create({
      content : "Please wait.."
    });

    this.childLoader.present().then(() => {
      
      this.authservice.postData(this.childPostData, 'facilities/getall').then((result)=>{
        
        this.childPostData = result;
  		  console.log(this.childPostData);
  		  if(this.childPostData['response'] == 1){
          this.childItems = this.childPostData['facilities'];
          this.actualItems = this.childItems;
        }

        this.childLoader.dismiss();

  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.childLoader.dismiss();
  	  });
      
    });
    
  }

  getItems(ev: any) {
    // Reset items back to all of the items
    //this.initializeItems();

    // set val to the value of the searchbar
    let val = ev.target.value;

    // if the value is an empty string don't filter the items
    if (val && val.trim() != '') {
      this.childItems = this.actualItems.filter((item) => {
        return (item.facilityname.toLowerCase().indexOf(val.toLowerCase()) > -1);
      })
    }
    else
    {
      this.childItems = this.actualItems;
      return this.childItems;
    }
  }

  addToSchool()
  {
    
    this.submitFacilities.facilities = this.facilities;

    if (this.facilities.length == 0)
    {
      let toast = this.toastCtrl.create({
          message: "Please select at least one facility to proceed further",
          duration: 3000
        });
      toast.present();
    }
    else
    {
      this.childLoader = this.myChildLoadingControl.create({
        content : "Please wait.."
      });

      

      this.childLoader.present().then(() => {
        
        this.authservice.postData(this.submitFacilities, 'facilities/add').then((result)=>{
          
          this.childResponseData = result;
          console.log(this.childResponseData);
          if(this.childResponseData['response'] == 1){
            
            this.childLoader.dismiss();
            
            let alert = this.alertCtrl.create({
              title: 'Successful!',
              subTitle: 'Selected facility has been added successfully to school information.',
              buttons: [
                {
                  text: 'Ok',
                  handler: () => {
                    this.myFacilities.loadFacilities();
                    this.modalDismiss();
                  }
                }
              ]
            });
            alert.present();
            //this.modalDismiss();
          }
          else
          {
            this.childLoader.dismiss();
            let toast = this.toastCtrl.create({
                message: "Sorry! we are unable to process your request",
                duration: 3000
              });
            toast.present();
            this.childLoader.dismiss();
          }          

        },(err)=> {
            //alert('failled '+err);
            let toast = this.toastCtrl.create({
                message: err,
                duration: 3000
            });
            toast.present();
            this.childLoader.dismiss();
        });
        
      });
    }
  }

  addFacility(event, facility)
  {
    if (event.checked)
    {
      this.facilities.push({
        facilityid: facility
      });
    }
    else
    {
      let index = 0;
      for(let i=0;i<this.facilities.length;i++)
      {
        if (this.facilities[i] == facility)
        {
          index = i;
          break;
        }
      }
      this.facilities.splice(index, 1);
    }
    
  }

}
