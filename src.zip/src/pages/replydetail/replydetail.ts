import { Component,ViewChild } from '@angular/core';
import { NavController, NavParams,ModalController,LoadingController,ToastController,Content,ViewController,AlertController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';

/**
 * Generated class for the ReplydetailPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-replydetail',
  templateUrl: 'replydetail.html',
})
export class ReplydetailPage {

  @ViewChild(Content) content: Content;

  schoolName: string;
  logEmailid: string;
  selectedItem: any;
  icons: string[];
  items: Array<{replycomment: string,rname:string,byemail:string,repid: number}>;
  myLoadingControl: any;
  loader: any;
  responseData: any;
  postData: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public modalCtrl: ModalController, public loadingCtrl: LoadingController,public alertCtrl:AlertController, public authservice: AuthServiceProvider, public toastCtrl: ToastController) {
    this.loader
    this.myLoadingControl = loadingCtrl;
    this.schoolName = localStorage.getItem('schoolname');
    this.logEmailid = localStorage.getItem('useremail');
    this.items = [];
    this.postData = { schoolid: window.localStorage.getItem('schoolid'), reviewid: navParams.get('reviewid')};
    this.loadMessages();
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad ReplydetailPage');
  }

  addCurriculum()
  {
    let modal = this.modalCtrl.create(Addreviewreply, {cuid: this.postData.reviewid,myObj: this});
    modal.present();
  }

  loadMessages(){
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.loader.onDidDismiss(() => {
      //setTimeout(()=>{this.content.scrollToBottom();},100);
      this.content.scrollToBottom();
    })

    this.loader.present().then(() => {
      this.authservice.postData(this.postData, 'reviews/allcommentreply').then((result)=>{
  		this.responseData = result;
  		console.log(this.responseData);
  		if(this.responseData['response'] == 1){
        this.items = this.responseData['reply'];
        this.loader.dismiss();
      }else{
        this.loader.dismiss();
  		}
  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismiss();
  	  });
    });

   
  }

  deleteMyreply(rid){
    
        let confirm = this.alertCtrl.create({
          title: 'Confirmation',
          message: 'Are you sure? you want to remove this reply',
          buttons: [
            {
              text: 'Yes',
              handler: () => {
                
                this.loader = this.myLoadingControl.create({
                  content : "Please wait.."
                });
    
                this.loader.present().then(() => {
                  
                  this.postData.repid = rid;
                  this.authservice.postData(this.postData, 'reviews/delete').then((result)=>{
                    
                  this.responseData = result;
                  console.log(this.responseData);
                  if(this.responseData['response'] == 1){
                      
                  this.loader.dismiss();
                      
                    let alert = this.alertCtrl.create({
                        title: 'Successful!',
                        subTitle: 'Selected reply has been removed successfully.',
                        buttons: ['OK']
                      });
                      alert.present();

    
                      let index = 0;
                      for(let i=0;i<this.items[0]['allreply'].length;i++)
                      {
                        if (this.items[0]['allreply'][i].repid == rid)
                        {
                          index = i;
                          break;
                        }
                      }
                      
                     this.items[0]['allreply'].splice(index, 1);
    
                    }
                    else
                    {
                      this.loader.dismiss();
                      let toast = this.toastCtrl.create({
                          message: "Sorry! we are unable to process your request",
                          duration: 3000
                        });
                      toast.present();
                      this.loader.dismiss();
                    }
    
                  },(err)=> {
                      //alert('failled '+err);
                      let toast = this.toastCtrl.create({
                          message: err,
                          duration: 3000
                        });
                      toast.present();
                      this.loader.dismiss();
                  });
                  
                });
    
              }
            },
            {
              text: 'No',
              handler: () => {
                console.log('Agree clicked');
              }
            }
          ]
        });
        confirm.present();
    
      }


}



@Component({
  selector: 'page-replydetail',
  template: `<ion-header>
                <ion-navbar>
                <ion-title>Reply on Review</ion-title>
                <ion-buttons end>
                    <button ion-button (click)="modalDismiss()">
                      <ion-icon name="close"></ion-icon>
                    </button>
                  </ion-buttons>
                </ion-navbar>                
             </ion-header>
            
            <ion-content>
              <ion-list>
                <ion-item>
                <ion-label floating>Enter your reply</ion-label>
                <ion-textarea name="txtdescription" [(ngModel)]="replyPostData.txtdescription"></ion-textarea>
                </ion-item>
              </ion-list>
            </ion-content>
            <ion-footer>
              <ion-toolbar>
                <ion-buttons end>
                  <button ion-button icon-right color="royal" (click)="addToReviewreply()">
                    Submit
                    <ion-icon name="send"></ion-icon>
                  </button>
                </ion-buttons>
              </ion-toolbar>
            </ion-footer>`
})


export class Addreviewreply {
  
  childLoader: any;
  myChildLoadingControl: any;
  replyPostData: any;
  childResponseData: any;
  submitcurriculum: any;
  myReplys: any;
  myCurrid: any;
  
  constructor(
              public navCtrl: NavController,
              public navParams: NavParams,
              public authservice: AuthServiceProvider,
              // public childLoadingCtrl: LoadingController,
              public toastCtrl: ToastController,
              public modalCtrl: ModalController,
              public viewCtrl: ViewController,
              public alertCtrl: AlertController
             )
  {
    this.replyPostData = {reviewid: 0 ,schoolid: window.localStorage.getItem('schoolid'),userid:window.localStorage.getItem('useremail'), txtdescription: ''};
    this.replyPostData.txtdescription = "";
    this.myReplys = navParams.get('myObj');
    this.myCurrid = navParams.get('cuid');
    this.replyPostData.reviewid = navParams.get('cuid');
    
  }
  modalDismiss()
  {
    this.viewCtrl.dismiss();
  }

  addToReviewreply()
  {
   
    if (this.replyPostData.txtdescription == '')
      {
          let toast = this.toastCtrl.create({
              message: "Please enter review reply",
              duration: 3000
            });
          toast.present();
          return false;
      }


     this.authservice.postData(this.replyPostData, 'reviews/reply').then((result)=>{
          
          this.childResponseData = result;
          console.log(this.childResponseData);
          if(this.childResponseData['response'] == 1){
  
            let alert = this.alertCtrl.create({
              title: 'Successful!',
              subTitle: 'Reply has been added successfully.',
              buttons: [
                {
                  text: 'Ok',
                  handler: () => {
                    this.myReplys.loadMessages();
                    this.modalDismiss();
                  }
                }
              ]
            });
            alert.present();
     
          }
          else
          {
            let toast = this.toastCtrl.create({
                message: "Sorry! we are unable to process your request",
                duration: 3000
              });
            toast.present();
          }          

        },(err)=> {
        
          let toast = this.toastCtrl.create({
                message: err,
                duration: 3000
            });
            toast.present();
         });
        
      }

    
   }

