import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { LoadingController } from 'ionic-angular/components/loading/loading-controller';
import { Component } from '@angular/core';
import { NavController, NavParams, ViewController, ToastController } from 'ionic-angular';
import { SchoolRegistrationPage } from '../school-registration/school-registration';

/**
 * Generated class for the SchoolslistPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-schoolslist',
  templateUrl: 'schoolslist.html',
})
export class SchoolslistPage {

  items: Array<{schoolname: string, schoolid: number, logopath: string}>;
  actualItems: Array<{schoolname: string, schoolid: number, logopath: string}>;
  childLoader: any;
  childPostData: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public myChildLoadingControl: LoadingController, public viewCtrl: ViewController, public authservice: AuthServiceProvider, public toastCtrl: ToastController) {
    this.items = [];
    this.childPostData = {state: navParams.get('state'), city: navParams.get('city')};
    this.loadAllSchools();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SchoolslistPage');
  }

  modalDismiss()
  {
    this.viewCtrl.dismiss();
  }

  loadAllSchools(){
    
    this.childLoader = this.myChildLoadingControl.create({
      content : "Loading schools.."
    });

    this.childLoader.present().then(() => {
      
      this.authservice.postData(this.childPostData, 'getAllSchools').then((result)=>{
        
        if(result['response'] == 1){
          this.items = result['schools'];
          this.actualItems = this.items;
        }

        this.childLoader.dismiss();

      },(err)=> {
          //alert('failled '+err);
          let toast = this.toastCtrl.create({
              message: err,
              duration: 3000
            });
          toast.present();
          this.childLoader.dismiss();
      });
      
    });
    
  }

  getItems(ev: any) {
    // Reset items back to all of the items
    //this.initializeItems();

    // set val to the value of the searchbar
    let val = ev.target.value;

    // if the value is an empty string don't filter the items
    if (val && val.trim() != '') {
      this.items = this.actualItems.filter((item) => {
        return (item.schoolname.toLowerCase().indexOf(val.toLowerCase()) > -1);
      })
    }
    else
    {
      this.items = this.actualItems;
      return this.items;
    }
  }

  itemSelected(schoolid, schoolname)
  {
    this.viewCtrl.dismiss({schoolid: schoolid, schoolname: schoolname});
  }
  
  gotoTempReg()
  {
    this.navCtrl.push(SchoolRegistrationPage, {}, {animate:true,animation:'transition',duration:300,direction:'forward'});
  }

}
