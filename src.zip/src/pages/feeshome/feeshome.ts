import { Component } from '@angular/core';
import { NavController, NavParams, ModalController } from 'ionic-angular';

import { GeneralizefeesPage } from "../generalizefees/generalizefees";
import { ClassfeesPage } from "../classfees/classfees";
/**
 * Generated class for the FeeshomePage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-feeshome',
  templateUrl: 'feeshome.html',
})
export class FeeshomePage {

  constructor(public navCtrl: NavController, public navParams: NavParams, public modalCtrl: ModalController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad FeeshomePage');
  }

  itemTapped(option) {
    if (option == 1)
    {
      let modal = this.modalCtrl.create(GeneralizefeesPage);
      modal.present();
    }
    else{
      let modal = this.modalCtrl.create(ClassfeesPage);
      modal.present();
    }
  }

}
