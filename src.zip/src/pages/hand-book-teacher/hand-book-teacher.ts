import { Component } from '@angular/core';
import { ModalController, NavController, NavParams, LoadingController, ToastController, Platform, AlertController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { File } from '@ionic-native/file';
import { Transfer, TransferObject } from '@ionic-native/transfer';
import { FilePath } from '@ionic-native/file-path';
import { global } from '../../app/global';
import { FileOpener } from '@ionic-native/file-opener';
import { HandBookFormPage } from './../hand-book-form/hand-book-form';

declare var cordova: any;

@Component({
  selector: 'page-hand-book-teacher',
  templateUrl: 'hand-book-teacher.html',
})
export class HandBookTeacherPage {
  
    noticeArray: Array<{ nid:any, HandBook: any, NoticeDate: any, docpath: any, filename: any }>;
    
      storageDirectory: string = '';
    
      notice: any;
      userData1: { 'schoolid': any; 'teacherid': any};
    
      loader: any;
      myLoadingControl: any;
      schoolid: any;
      teacherid: any;
    
      constructor(
          public navCtrl: NavController,
          public navParams: NavParams,
          public authservice: AuthServiceProvider,
          public loadingCtrl: LoadingController,
          public toastCtrl: ToastController,
          public transfer: Transfer, 
          public file: File, 
          public filePath: FilePath, 
          public platform: Platform,  
          public alertCtrl: AlertController,  
          public fileOpener: FileOpener,
          public modalCtrl: ModalController,
      )

      {    
        this.myLoadingControl = loadingCtrl;
        this.schoolid = localStorage.getItem('schoolid');
        this.teacherid = localStorage.getItem('teacherid');
      
        this.noticeArray = [];
        this.getAllSchoolhandbook();
        //let toast = this.toastCtrl.create({ message: this.navParams.get('schoolid'), duration: 3000 });
        //toast.present();
    
        this.platform.ready().then(() => {
          if(!this.platform.is('cordova')) {
            return false;
          }
          if (this.platform.is('ios')) {
            this.storageDirectory = cordova.file.documentsDirectory;
          }
          else if(this.platform.is('android')) {
            this.storageDirectory = cordova.file.externalDataDirectory ;
          }
          else {
            // exit otherwise, but we could add further types here e.g. Windows
            return false;
          }
        });
    
      }
  ionViewDidLoad() {
    console.log('ionViewDidLoad HandBookTeacherPage');
  }

  getAllSchoolhandbook()
  {
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.userData1 = {'schoolid': this.schoolid, 'teacherid': this.teacherid}
    this.loader.present().then(() => {
      this.authservice.postData(this.userData1, 'getAllHandBookByTeacher').then((result)=>{
    		if(result['response'] == 1){
          this.notice = result['allnotice'];
          for(let val of result['allnotice'])
          {
            this.noticeArray.push({
              nid: val['teacherid']+'-'+val['orderid'],
              HandBook: val['description'],
              NoticeDate: val['hbookdate'], 
              docpath: val['hdocpath'],           
              filename: val['hdocpath'].substring(val['hdocpath'].lastIndexOf('/') + 1, val['hdocpath'].length )
            });            
          }
          
          this.loader.dismiss();
        }else{
          let toast = this.toastCtrl.create({ message: 'Sorry ! record not found !', duration: 3000 });
          toast.present();
          this.loader.dismiss();
        }
    	},(err)=> {
        let toast = this.toastCtrl.create({ message: err, duration: 3000 });
        toast.present();
        this.loader.dismiss();
    	});
    });
  }

  /*getMimeType(uri) 
  {
    this.file.resolveLocalFileSystemURI(uri, (fileEntry) => {
      fileEntry.file((filee) => {
          alert(filee.type);
      }, (err) => {
          alert('error :'+ err);
      });
    });
  }*/

  downloadNoticeDoc(doc) 
  {
      this.platform.ready().then(() => {
        var filename = doc.substring(doc.lastIndexOf('/') + 1, doc.length );
        var fileExtension = doc.substring(doc.lastIndexOf('.') + 1, doc.length );     
        const mime = global.getMIMEtype(fileExtension);
        
        const fileTransfer: TransferObject = this.transfer.create();
        const imageLocation = global.apiBackoffice+'/uploads/school-'+this.schoolid+'/handbook_board_doc/'+doc;
        
        fileTransfer.download(encodeURI(imageLocation), this.storageDirectory + filename).then((entry) => 
        {
          /*const alertSuccess = this.alertCtrl.create({
            title: `Download Succeessful!`,
            subTitle: `${filename} was successfully downloaded.`,
            buttons: ['Ok']
          });
          alertSuccess.present();*/

          //this.getMimeType(this.storageDirectory + filename);

          this.fileOpener.open(this.storageDirectory + filename, mime).then(() => 
          console.log('File is opened'))
          .catch(e => console.log('Error openening file', e));

        }, (error) => {
          const alertFailure = this.alertCtrl.create({
            title: `Download Failed !`,
            subTitle: `${filename} failed to download.`,
            buttons: ['Ok']
          });
          alertFailure.present();
        });
        
      });
  
    }
  
    noticeForm()
    {
      this.noticeArray = [];
      let modal = this.modalCtrl.create(HandBookFormPage, {'HandBookObj':this});
      modal.present();
    }
    
    
    deleteHandbook(nid)
    {
      let alert = this.alertCtrl.create({
        title: 'Confirm delete',
        message: 'Are you sure want to delete this ?',
        buttons: [
          {
            text: 'Cancel',
            role: 'cancel',
            handler: () => {
              console.log('Cancel clicked');
            }
          },
          {
            text: 'Delete',
            handler: () => {
              this.authservice.postData({'hbid':nid,'schoolid':this.schoolid}, 'deleteHandbookBySchool').then((result)=>{
                if(result['response'] == 1){
                  this.noticeArray = [];
                  this.getAllSchoolhandbook();
                }else{
                  let toast = this.toastCtrl.create({ message: 'Sorry! unable to process your request.', duration: 3000 });
                  toast.present();
                }
              },(err)=> {
                let toast = this.toastCtrl.create({ message: err, duration: 3000 });
                toast.present();
              }); 
            }
          }
        ]
      });
      alert.present();
    }


}
