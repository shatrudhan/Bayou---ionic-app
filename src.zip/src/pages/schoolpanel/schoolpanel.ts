import { PopoverController } from 'ionic-angular/components/popover/popover-controller';
import { PopoverPage } from './../popover/popover';
import { GalleryPage } from './../gallery/gallery';
import { SchoolcontactsPage } from './../schoolcontacts/schoolcontacts';
import { AdmissionenquiriesPage } from './../admissionenquiries/admissionenquiries';
import { AdmissionalertsPage } from './../admissionalerts/admissionalerts';
import { SchoolcalendarPage } from './../schoolcalendar/schoolcalendar';
import { SkooldeskbookingPage } from './../skooldeskbooking/skooldeskbooking';
import { HomePage } from './../home/home';
import { SocialSharing } from '@ionic-native/social-sharing';
import { ExamSchedulePage } from './../exam-schedule/exam-schedule';
import { ExamresultPage } from './../exam-results/exam-results';
import { FeestructurePage } from './../feestructure/feestructure';
import { ReviewsPage } from './../reviews/reviews';
import { LatestNewsPage } from './../latest-news/latest-news';
import { CurriculumPage } from './../curriculum/curriculum';
import { SchoolinformationPage } from './../schoolinformation/schoolinformation';
import { PhotogalleryPage } from './../photogallery/photogallery';
import { InfrastructurePage } from './../infrastructure/infrastructure';
import { FacilitiesPage } from './../facilities/facilities';
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
//import { global } from '@angular/core/src/util';
import { ToastController } from 'ionic-angular/components/toast/toast-controller';
import { NoticeBoardPage } from '../notice-board/notice-board';

/**
 * Generated class for the SchoolpanelPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-schoolpanel',
  templateUrl: 'schoolpanel.html',
})
export class SchoolpanelPage {

  schoolName: any;
  socialSharing: any;
  schoolAdmin: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public socialShare: SocialSharing, public toastCtrl: ToastController, public popoverCtrl: PopoverController) {
    this.schoolName = localStorage.getItem('schoolname');
    this.socialSharing = socialShare;
    this.schoolAdmin = window.localStorage.getItem('isadmin');

    /* let toast = this.toastCtrl.create({
      message: this.schoolAdmin+'',
      duration: 3000
    });
    toast.present(); */

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SchoolpanelPage');
  }

  openPage(option)
  {
    if (option == 1)
      this.navCtrl.push(FacilitiesPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (option == 2)
      this.navCtrl.push(InfrastructurePage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (option == 3)
      this.navCtrl.push(GalleryPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (option == 4)
      this.navCtrl.push(SchoolinformationPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (option == 5)
      this.navCtrl.push(CurriculumPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (option == 6)
      this.navCtrl.push(LatestNewsPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (option == 7)
      this.navCtrl.push(ReviewsPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (option == 8)
      this.navCtrl.push(FeestructurePage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (option == 9)      
	    this.navCtrl.push(ExamSchedulePage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});    
	  else if (option == 10)  
	    this.navCtrl.push(ExamresultPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (option == 16)
      this.navCtrl.push(HomePage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (option == 17)
      this.navCtrl.push(SkooldeskbookingPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (option == 11)
      this.navCtrl.push(NoticeBoardPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (option == 12)
      this.navCtrl.push(SchoolcalendarPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (option == 13)
      this.navCtrl.push(AdmissionalertsPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (option == 14)
      this.navCtrl.push(AdmissionenquiriesPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (option == 15)
      this.navCtrl.push(SchoolcontactsPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
  }

  shareSchool()
  {
    let message = "Please visit our school profile link " + window.localStorage.getItem('schoolurl') + " and give your valuable review to help parents to know about the school.\r\n\r\n" + window.localStorage.getItem('schoolname');
    this.socialSharing.share(message);
  }

  MorePopOver(myEvent) 
  {
    let popover = this.popoverCtrl.create(PopoverPage);
    popover.present({
      ev: myEvent
    });
  }

}
