import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, ToastController, AlertController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { FirebasedbProvider } from './../../providers/firebasedb/firebasedb';

@Component({
  selector: 'page-attendance',
  templateUrl: 'attendance.html',
})
export class AttendancePage {
  items: Array<{studentname: string, rollno: number, sid: number, reason: string}>;
  myLoadingControl: any;
  loader: any;
  responseData: any;
  postData: any;
  studentArray: Array<{studentid: number, abReason: string}>;
  submitPostData: any;
  reason: any;
  abc: boolean;
  today: any;
  maxtoday;
  postDt: any;

  constructor(public fbProvider: FirebasedbProvider, public navCtrl: NavController, public navParams: NavParams, public loadingCtrl: LoadingController, public authservice: AuthServiceProvider, public toastCtrl: ToastController, public alertCtrl: AlertController) {
    this.myLoadingControl = loadingCtrl;
    this.items = [];
    this.studentArray = [];
    this.today = new Date().toJSON().split('T')[0];
    this.postData = {classid: navParams.get('classid'), schoolid: window.localStorage.getItem('schoolid'), sectionid: navParams.get('sectionid')};
    this.submitPostData = {classid: navParams.get('classid'), schoolid: window.localStorage.getItem('schoolid'), sectionid: navParams.get('sectionid'), students: '', attdate: this.today, teacheremailid: window.localStorage.getItem('useremail')};
    this.submitPostData.students = [];
    this.getStudents();
    this.reason = '';
    console.log('ionViewDidLoad AttendancePage');
    this.maxtoday = new Date().toJSON().split('T')[0];
    this.abc=false;
    this.postDt ={adate:"",atype:""};
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AttendancePage');
  }

  getStudents(){

    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    
    this.loader.present().then(() => {
      this.authservice.postData(this.postData, 'getstudents').then((result)=>{
  		this.responseData = result;
  		console.log(this.responseData);
  		if(this.responseData['response'] == 1){
        this.items = this.responseData['studentinfo'];
        for(let data of this.responseData['studentinfo'])
        {
            //if (data['ispresent'] == "true")
              this.studentArray.push({
                studentid: data['sid'],
                abReason: data['reason']
              });
        }
        if (this.responseData['isattendance'] == 1)
        {  
          this.abc = true;    
          let toast = this.toastCtrl.create({
    				  message: "Attendance has already been submitted for selected date.",
    				  duration: 3000
    				});
    			toast.present();
        }else{
          this.abc = false;
        }
        this.loader.dismiss();
  		}else{
        this.loader.dismiss();
  		}
  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismiss();
  	  });
    });
  }

  getNextPrvAttendance(){
    
        this.loader = this.myLoadingControl.create({
          content : "Please wait.."
        });

        this.studentArray = [];

        this.postData.adate= this.today;
        this.loader.present().then(() => {
          this.authservice.postData(this.postData, 'getstudents').then((result)=>{
          this.responseData = result;
          console.log(this.responseData);
          if(this.responseData['response'] == 1){
            this.studentArray=[];
            this.items = this.responseData['studentinfo'];
            for(let data of this.responseData['studentinfo'])
            {
                //if (data['ispresent'] == "true")
                  this.studentArray.push({
                    studentid: data['sid'],
                    abReason: data['reason']
                  });
            }
            this.today =this.responseData['chgdate'];
            if (this.responseData['isattendance'] == 1)
            {      
              this.abc=true;     
              let toast = this.toastCtrl.create({
                  message: "Attendance has already been submitted for selected date.",
                  duration: 3000
                });
              toast.present();
            }
            else
              this.abc=false;

            this.loader.dismiss();
          }else{
            this.loader.dismiss();
          }
          },(err)=> {
              //alert('failled '+err);
              let toast = this.toastCtrl.create({
                  message: err,
                  duration: 3000
                });
              toast.present();
              this.loader.dismiss();
          });
        });
      }

      getNewdate(tp)
      {
        this.postDt.atype= tp;
        this.postDt.adate= this.today;
       // this.loader.present().then(() => {
          this.authservice.postData(this.postDt, 'getnextdate').then((result)=>{
          this.responseData = result;
          console.log(this.responseData);
          if(this.responseData['response'] == 1){
           
            this.today =this.responseData['changedate'];
            }
          },(err)=> {
              //alert('failled '+err);
              let toast = this.toastCtrl.create({
                  message: err,
                  duration: 3000
                });
              toast.present();
              this.loader.dismiss();
          });
       // });
      } 

  doAttendance()
  {
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.submitPostData.students = this.studentArray;
    this.submitPostData.attdate = this.today;

    this.loader.present().then(() => {
      this.authservice.postData(this.submitPostData, 'submitattendence').then((result)=>{
  		this.responseData = result;
  		console.log(this.responseData);
  		if(this.responseData['response'] == 1){
        let toast = this.toastCtrl.create({
            message: "Attendance has been submitted successfuly!",
            duration: 3000
          });
        toast.present();
        //console.log(this.submitPostData.students);
        // this.fbProvider.AttendancePushMessage(window.localStorage.getItem('schoolid'),this.submitPostData.students);
        
        this.loader.dismiss();
        this.navCtrl.pop(this);
  		}else{
        let toast = this.toastCtrl.create({
            message: "Sorry! unable to process your request",
            duration: 3000
          });
        toast.present();
        this.loader.dismiss();
  		}
  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismiss();
  	  });
    });
  }

  editconfirm()
  {
    let alert = this.alertCtrl.create({
      title: 'Confirm',
      message: 'Do you want to edit this attendance !',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Ok',
          handler: data => {
            //console.log('Saved clicked');
           
            this.loader = this.myLoadingControl.create({
              content : "Please wait.."
            });
        
            this.postData.adate= this.today;
            this.loader.present().then(() => {
              this.authservice.postData(this.postData, 'getstudents').then((result)=>{
              this.responseData = result;
              console.log(this.responseData);
              if(this.responseData['response'] == 1){
                this.studentArray=[];
                this.items = this.responseData['studentinfo'];
                for(let data of this.responseData['studentinfo'])
                {
                    //if (data['ispresent'] == "true")
                      this.studentArray.push({
                        studentid: data['sid'],
                        abReason: data['reason']
                      });
                }
                this.today =this.responseData['chgdate'];
                if (this.responseData['isattendance'] == 1)
                {      
                  this.abc=false;     
                 
                }
                else
                  this.abc=true;
    
                this.loader.dismiss();
              }else{
                this.loader.dismiss();
              }
              },(err)=> {
                  //alert('failled '+err);
                  let toast = this.toastCtrl.create({
                      message: err,
                      duration: 3000
                    });
                  toast.present();
                  this.loader.dismiss();
              });
            });

          }
        }
      ]
    });
    alert.present();

  }

  addStudent(event, studentid)
  {
    if (!event.checked)
    {
      let prompt = this.alertCtrl.create({
        title: 'Reason',
        enableBackdropDismiss: false,
        inputs: [
          {
            label: 'Absent',
            value: 'Absent',
            type: 'radio',
            checked: true
          },
          {
            label: 'Medical Leave',
            value: 'Medical Leave',
            type: 'radio'
          },
          {
            label: 'Other Leave',
            value: 'Other Leave',
            type: 'radio'
          }
        ],
        buttons: [
          {
            text: 'Cancel',
            handler: data => {
              //console.log('Cancel clicked');
              event.checked = true;
            }
          },
          {
            text: 'Save',
            handler: data => {
              //console.log('Saved clicked');
              let itemIndex = 0;
              for(let i=0;i<this.items.length;i++)
              {
                if (this.items[i].sid == studentid)
                {
                  itemIndex = i;
                  break;
                }
              }
              this.items[itemIndex]['reason'] = data;
              let index = 0;
              for(let i=0;i<this.studentArray.length;i++)
              {
                if (this.studentArray[i].studentid == studentid)
                {
                  index = i;
                  break;
                }
              }
              /*let toast = this.toastCtrl.create({
                  message: index+'',
                  duration: 3000
                });
              toast.present();*/
              //this.studentArray.splice(index, 1);
              this.studentArray[index].abReason = data;
            }
          }
        ]
      });
      prompt.present();
    }
    else
    {
      let itemIndex = 0;
      for(let i=0;i<this.items.length;i++)
      {
        if (this.items[i].sid == studentid)
        {
          itemIndex = i;
          break;
        }
      }
      this.items[itemIndex]['reason'] = '';
      let index = 0;
      for(let i=0;i<this.studentArray.length;i++)
      {
        if (this.studentArray[i].studentid == studentid)
        {
          index = i;
          break;
        }
      }
      this.studentArray[index].abReason = '';
    }
  }

}
