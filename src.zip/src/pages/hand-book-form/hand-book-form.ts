import { Component } from '@angular/core';
import { ViewController, NavController, NavParams, LoadingController, ToastController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { FileChooser } from '@ionic-native/file-chooser';
import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer';
import { global } from '../../app/global';
import { FilePath } from '@ionic-native/file-path';
import { File } from '@ionic-native/file';
import { NoticeBoardPage } from '../notice-board/notice-board'
// import { FirebasedbProvider } from './../../providers/firebasedb/firebasedb';

@Component({
  selector: 'page-hand-book-form',
  templateUrl: 'hand-book-form.html',
})
export class HandBookFormPage {
  HandBookObj: any;
  wordLimit: any;
  NoticeSubmitBtn: boolean;
  UploadedFileName: string;
  
  responseData: any;
  userData1: any;
  nativepath: any;

  schoolid: string;
  loading: any;
  loader: any;
  myLoadingControl: any;

  teacherid : any;
  allclass : any;
  attachStatus1: string;
  attachStatus2: string;
  attachStatus3: string;
  attachStatus4: string;
  attachStatus5: string;

  UploadedFileName1: string;
  UploadedFileName2: string;
  UploadedFileName3: string;
  UploadedFileName4: string;
  UploadedFileName5: string;

  classArray: Array<{ tid:any, secid:any, classname: any, sectionname: any }>;
  

  constructor(
              public navCtrl: NavController, 
              public navParams: NavParams, 
              public authservice: AuthServiceProvider, 
              public loadingCtrl: LoadingController, 
              public toastCtrl: ToastController,
              public fileChooser: FileChooser,
              public fileTransfer: FileTransfer,
              public filePath: FilePath,   
              public file: File,
              public viewCtrl: ViewController, 
              // public fbProvider: FirebasedbProvider,              
  )
  {
    //let toast = this.toastCtrl.create({ message: localStorage.getItem('schoolid'), 'cssClass':'toastText', duration: 3000 });
    //toast.present();
    this.HandBookObj = navParams.get('HandBookObj'); 
    
    this.myLoadingControl = loadingCtrl;
    this.schoolid = localStorage.getItem('schoolid');
    this.teacherid = localStorage.getItem('teacherid');

    this.userData1 = {schoolid: this.schoolid, handbookText: '', document: '', classids: '' , teacherid: this.teacherid};

    // Attach status
    this.attachStatus1 = 'N';
    this.attachStatus2 = 'N';
    this.attachStatus3 = 'N';
    this.attachStatus4 = 'N';
    this.attachStatus5 = 'N';

    this.NoticeSubmitBtn = global.makeDisabled;

    this.wordLimit = 300;

    this.classArray=[];
    this.getteacherclass();


    this.UploadedFileName1="";
    this.UploadedFileName2="";
    this.UploadedFileName3="";
    this.UploadedFileName4="";
    this.UploadedFileName5="";
   
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad HandBookFormPage');
  }

  ModalDismiss()
  {
    this.HandBookObj.getAllSchoolhandbook();
    this.viewCtrl.dismiss();
  }

  public presentToast(text) {
    let toast = this.toastCtrl.create({
      message: text,
      duration: 3000,
      position: 'bottom'
    });
    toast.present();
  }
  
  public isTrimed(v) 
  {
    return v.replace(/^\s+|\s+$/gm,'');
  }

  public textAreaEmpty()
  {
      var nt = this.isTrimed(this.userData1['handbookText']);
      
      //let toast = this.toastCtrl.create({ message: 'lenght :'+nt.length, 'cssClass':'toastText', duration: 3000 });
      //toast.present();
      this.wordLimit = 300 - nt.length;

      if(nt.length == 0){
        this.NoticeSubmitBtn = global.makeDisabled; 
      }else{
        this.NoticeSubmitBtn = global.makeEnabled;        
      }
  }

  public createFileName(filename,fextension) 
  {
    var d = new Date(),
    n = d.getTime(),
    newFileName =  n + "."+fextension;
    return newFileName;
  }

  uploadHandBookDoc(dno)
  {
    this.fileChooser.open().then(uri =>{
      this.filePath.resolveNativePath(uri).then(path => {
      
        // Destination URL
        let url = global.apiUrl+'HandbookDocUpload';

        // File name only
        var filename = path.substring(path.lastIndexOf('/') + 1, path.length );

        // file extension
        var fileExtension = path.substring(path.lastIndexOf('.') + 1, path.length );

        var newFileName = this.createFileName(filename,fileExtension);

        // File for Upload path
        var targetPath = path;      
        
        if(newFileName != ''){
          if(dno == 1)
          this.attachStatus1 = 'Y';
          else if(dno == 2)
          this.attachStatus2 = 'Y';
          else if(dno == 3)
          this.attachStatus3 = 'Y';
          else if(dno == 4)
          this.attachStatus4 = 'Y';
          else if(dno == 5)
          this.attachStatus5 = 'Y';
        }else{
          if(dno == 1)
          this.attachStatus1 = 'N';
          else if(dno == 2)
          this.attachStatus2 = 'N';
          else if(dno == 3)
          this.attachStatus3 = 'N';
          else if(dno == 4)
          this.attachStatus4 = 'N';
          else if(dno == 5)
          this.attachStatus5 = 'N';
        }
        //let toast = this.toastCtrl.create({ message: 'file ex : '+fileExtension+' , file name : '+newFileName, 'cssClass':'toastText', duration: 30000 });
        //toast.present();

        var options: FileUploadOptions  = {
          fileKey: "file",
          fileName: newFileName,
          chunkedMode: false,
          mimeType: "multipart/form-data",
          params : {'fileName': newFileName, 'schoolid': this.schoolid}
        };
        
        const fileTransfer: FileTransferObject = this.fileTransfer.create();
        
        this.loading = this.loadingCtrl.create({content: 'Uploading...',});
        this.loading.present();
        
        // Use the FileTransfer to upload the image
        fileTransfer.upload(targetPath, url, options ).then((data) => {
          if(dno == 1)
          this.UploadedFileName1 = newFileName+',';
          else if(dno == 2)
          this.UploadedFileName2 = newFileName+',';
          else if(dno == 3)
          this.UploadedFileName3 = newFileName+',';
          else if(dno == 4)
          this.UploadedFileName4 = newFileName+',';
          else if(dno== 5)
          this.UploadedFileName5 = newFileName;
          
          this.loading.dismissAll();
        }, err => {
          this.loading.dismissAll();
          this.presentToast('File uploading failled !');
        });
      });
    });
  }

  HandbookFormSubmit()
  {

    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {
      
      //if(this.UploadedFileName){
       // this.userData1['document'] = this.UploadedFileName;
      //}else{
        //this.userData1['document'] = '';
      //}
      this.UploadedFileName = this.UploadedFileName1+this.UploadedFileName2+this.UploadedFileName3+this.UploadedFileName4+this.UploadedFileName5;

      // if(this.UploadedFileName1 !='' || this.UploadedFileName2 !='' && this.UploadedFileName3 !='' && this.UploadedFileName4 !='' && this.UploadedFileName5 !=''){
        this.userData1['document'] = this.UploadedFileName;
      // }else{
        // this.userData1['document'] = '';
      // }
      
    if(this.teacherid != 0)
      { 
       // alert('enter');
      if(this.userData1.classids == ''){
        let toast = this.toastCtrl.create({
          message: 'Please select atleast one class.',
          duration: 3000
        }); 
        this.loader.dismiss();
        toast.present();
        return false;
      }
    } 
          
      this.authservice.postData(this.userData1, 'addhandbook').then((result)=>{
          if(result['response'] == 1){
            // this.fbProvider.NoticePushMessage(this.schoolid,global.wordLimiter(this.userData1['handbookText'],70),result['studentArray']);            
            this.userData1['handbookText'] = '';
            this.userData1['classids'] = '';
            this.userData1['document'] = ''; 
            this.UploadedFileName = '';
            this.attachStatus1 = 'N';
            this.attachStatus2 = 'N';  
            this.attachStatus3 = 'N';
            this.attachStatus4 = 'N';
            this.attachStatus5 = 'N';
            this.NoticeSubmitBtn = global.makeDisabled;
            this.loader.dismiss();
            let toast = this.toastCtrl.create({ message: result['msg'], 'cssClass':'toastText', duration: 3000 });
            toast.present();
            this.viewCtrl.dismiss();
            this.HandBookObj.getAllSchoolhandbook(); 
          }else{
            this.loader.dismiss();
            let toast = this.toastCtrl.create({ message: result['msg'], 'cssClass':'toastText', duration: 3000 });
            toast.present();
          }
        },(err)=> {
          this.loader.dismiss();
          let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 3000 });
          toast.present();
      });
    });

  }


  getteacherclass()
  {
    this.authservice.postData({'teacherid':this.teacherid,'schoolid':this.schoolid}, 'allottedclasses').then((result)=>{
     if(result['response'] == 1){
        this.allclass = result['classinfo'];
        for(let val of result['classinfo'])
        {
          this.classArray.push({
            tid: val['classid'],
            secid: val['sectionid'],
            classname: val['classname'],
            sectionname: val['sectionname'],
           });
           console.log(this.classArray);
        }
        //this.loader.dismiss();
      }else{
        let toast = this.toastCtrl.create({ message: 'Sorry ! no class found.', duration: 3000 });
        toast.present();
       // this.loader.dismiss();
      }
    },(err)=> {
      let toast = this.toastCtrl.create({ message: err, duration: 3000 });
      toast.present();
      //this.loader.dismiss();
    });



  }



}
