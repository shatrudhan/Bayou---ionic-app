import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { Component } from '@angular/core';
import { NavController, NavParams, ModalController, ViewController, LoadingController, ToastController, AlertController } from 'ionic-angular';

/**
 * Generated class for the SchoolbasicinformationPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-schoolbasicinformation',
  templateUrl: 'schoolbasicinformation.html',
})
export class SchoolbasicinformationPage {

  schoolName: string;
  submitPostData:any;
  loader: any;
  myLoadingCtrl: any;
  postData: any;
  responseData: any;
  states: Array<{statename: string, stateid: number}>;
  cities: Array<{cityname: string, cityid: number}>;
  areas: Array<{areaname: string, areaid: number}>;
  basicInfo: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public viewCtrl: ViewController, public modalCtrl: ModalController, public loadingCtrl: LoadingController, public authservice: AuthServiceProvider, public toastCtrl: ToastController, public alertCtrl: AlertController) {
    this.basicInfo = navParams.get('myObj');
    this.schoolName = window.localStorage.getItem('schoolname');
    this.myLoadingCtrl = loadingCtrl;
    this.postData = {schoolid: window.localStorage.getItem('schoolid')};
    this.submitPostData = {schoolid: window.localStorage.getItem('schoolid'), schoolname: window.localStorage.getItem('schoolname'), website: '', schooltype: '', address: '', localityarea: '', city: '', state: '', pincode: '', contactno: '', emailid: '', category: ''};
    this.getInformation();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SchoolbasicinformationPage');
  }

  getInformation(){

    this.loader = this.myLoadingCtrl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {
      
      this.authservice.postData(this.postData, 'basicinformation/getforedit').then((result)=>{
        
        this.responseData = result;
  		  console.log(this.responseData);
  		  if(this.responseData['response'] == 1){          

          this.states = this.responseData['states'];
          //this.cities = this.responseData['cities'];
          //this.areas = this.responseData['areas'];

          this.submitPostData.address = this.responseData['information'][0]['address'];
          this.submitPostData.state = this.responseData['information'][0]['state'];
          this.submitPostData.city = this.responseData['information'][0]['city'];
          this.submitPostData.localityarea = this.responseData['information'][0]['LocalityArea'];
          this.submitPostData.pincode = this.responseData['information'][0]['pincode'];
          this.submitPostData.contactno = this.responseData['information'][0]['contactno'];
          this.submitPostData.emailid = this.responseData['information'][0]['emailid'];
          this.submitPostData.website = this.responseData['information'][0]['websitename'];
          this.submitPostData.schooltype = this.responseData['information'][0]['schooltype'];
          this.submitPostData.category = this.responseData['information'][0]['category'];
          this.submitPostData.localityarea = this.responseData['information'][0]['localityarea'];
        }

        this.loader.dismiss();

  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismiss();
  	  });
      
    });
    
  }

  modalDismiss()
  {
    this.viewCtrl.dismiss();
  }

  getCities()
  {
    this.loader = this.myLoadingCtrl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {

      let statedata = {state: this.submitPostData.state};
      
      this.authservice.postData(statedata, 'basicinformation/getcities').then((result)=>{
        
        //this.responseData = result;
  		  //console.log(this.responseData);
  		  if(result['response'] == 1){
          this.cities = result['cities'];
        }

        this.loader.dismiss();

  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismiss();
  	  });
      
    });
  }

  getAreas()
  {
    let areaLoader = this.myLoadingCtrl.create({
      content : "Please wait.."
    });

    areaLoader.present().then(() => {

      let citydata = {city: this.submitPostData.city};
      
      this.authservice.postData(citydata, 'basicinformation/getareas').then((resulta)=>{
        
        //this.responseData = result;
  		  //console.log(this.responseData);
  		  if(resulta['response'] == 1){
          this.areas = resulta['areas'];
        }

        areaLoader.dismiss();

  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          areaLoader.dismiss();
  	  });
      
    });
  }

  updateInformation()
  {
    if (this.submitPostData.schoolname == "" || this.submitPostData.contactno == "" || this.submitPostData.address == "" || this.submitPostData.pincode == "" || this.submitPostData.state == "" || this.submitPostData.city == "" || this.submitPostData.area == "" || this.submitPostData.schooltype == "" || this.submitPostData.category == "")
    {
      let toast = this.toastCtrl.create({
          message: "Please enter the required fields to proceed",
          duration: 3000
      });
      toast.present();
    }
    else
    {
      let areaLoader = this.myLoadingCtrl.create({
        content : "Please wait.."
      });

      areaLoader.present().then(() => {

        //let citydata = {city: this.submitPostData.city};
        
        this.authservice.postData(this.submitPostData, 'basicinformation/update').then((resulta)=>{
          
          //this.responseData = result;
          //console.log(this.responseData);
          if(resulta['response'] == 1){
            areaLoader.dismiss();
            let alert = this.alertCtrl.create({
              title: 'Successful!',
              subTitle: 'Information has been updated successfully!',
              buttons: [
                {
                  text: 'Ok',
                  handler: () => {                    
                    this.basicInfo.getInformation();
                    this.modalDismiss();
                  }
                }
              ]
            });
            alert.present();
          }
          else
          {
            areaLoader.dismiss();
          }          

        },(err)=> {
            //alert('failled '+err);
            let toast = this.toastCtrl.create({
                message: err,
                duration: 3000
              });
            toast.present();
            areaLoader.dismiss();
        });
        
      });
    }
  }

}
