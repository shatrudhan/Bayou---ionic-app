import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, ToastController, ModalController, AlertController, ViewController } from 'ionic-angular';

/**
 * Generated class for the AdmissionalertsPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-admissionalerts',
  templateUrl: 'admissionalerts.html',
})
export class AdmissionalertsPage {

  schoolName: string;
  loader: any;
  myLoadingControl: any;
  postData: any;
  responseData: any;
  items: Array<{newstopic: string, nid: number, ndate: any}>;
  submitPostData: any;
  isItemExist: boolean;

  constructor(public navCtrl: NavController, public navParams: NavParams, public loadingCtrl: LoadingController, public authservice: AuthServiceProvider,public toastCtrl: ToastController , public alertCtrl: AlertController, public modalCtrl: ModalController) {
    this.items = [];
    this.isItemExist = false;
    this.schoolName = localStorage.getItem('schoolname');
    this.myLoadingControl = loadingCtrl;
    this.postData = {schoolid: window.localStorage.getItem('schoolid'), newstype: 'A'};
    this.submitPostData = {schoolid: window.localStorage.getItem('schoolid'), nid: 0, newstype: 'A'};
    this.loadlatestnews();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LatestNewsPage');
  }

  loadlatestnews(){
    
        this.loader = this.myLoadingControl.create({
          content : "Please wait.."
        });
    
        this.loader.present().then(() => {
          
          this.authservice.postData(this.postData, 'admissionalerts/get').then((result)=>{
            
            this.responseData = result;
            console.log(this.responseData);
            if(this.responseData['response'] == 1){
              this.items = this.responseData['news'];
              this.isItemExist = true;
            }
    
            this.loader.dismiss();
    
          },(err)=> {
              //alert('failled '+err);
              let toast = this.toastCtrl.create({
                  message: err,
                  duration: 3000
                });
              toast.present();
              this.loader.dismiss();
          });
          
        });
        
  }

  addLatestnews(lid)
  {
    let modal = this.modalCtrl.create(Addadmissionalert, {nid: lid,myObj: this});
    modal.present();
  }

  deleteLatestnews(lid){
    
    let confirm = this.alertCtrl.create({
      title: 'Confirmation',
      message: 'Are you sure? you want to remove this admission alert',
      buttons: [
        {
          text: 'Yes',
          handler: () => {
            
            this.loader = this.myLoadingControl.create({
              content : "Please wait.."
            });

            this.loader.present().then(() => {
              
              this.submitPostData.nid = lid;
              this.authservice.postData(this.submitPostData, 'admissionalerts/delete').then((result)=>{
                
              this.responseData = result;
              console.log(this.responseData);
              if(this.responseData['response'] == 1){
                  
              this.loader.dismiss();
                  
                let alert = this.alertCtrl.create({
                    title: 'Successful!',
                    subTitle: 'Selected admission alert has been removed successfully',
                    buttons: ['OK']
                  });
                  alert.present();

                  let index = 0;
                  for(let i=0;i<this.items.length;i++)
                  {
                    if (this.items[i].nid == lid)
                    {
                      index = i;
                      break;
                    }
                
  
                  }
                  
                  this.items.splice(index, 1);

                }
                else
                {
                  this.loader.dismiss();
                  let toast = this.toastCtrl.create({
                      message: "Sorry! we are unable to process your request",
                      duration: 3000
                    });
                  toast.present();
                  this.loader.dismiss();
                }

              },(err)=> {
                  //alert('failled '+err);
                  let toast = this.toastCtrl.create({
                      message: err,
                      duration: 3000
                    });
                  toast.present();
                  this.loader.dismiss();
              });
              
            });

          }
        },
        {
          text: 'No',
          handler: () => {
            console.log('Agree clicked');
          }
        }
      ]
    });
    confirm.present();

  }

}



@Component({
  selector: 'page-facilities',
  template: `<ion-header>
                <ion-navbar>
                <ion-title>Admission alert</ion-title>
                <ion-buttons end>
                    <button ion-button (click)="modalDismiss()">
                      <ion-icon name="close"></ion-icon>
                    </button>
                  </ion-buttons>
                </ion-navbar>                
             </ion-header>
            
            <ion-content>
              <ion-list>
                <ion-item>
                <ion-label floating>Enter latest admission news detail</ion-label>
                <ion-textarea name="txtlatestnews" [(ngModel)]="latestnewsPostData.txtlatestnews"></ion-textarea>
                </ion-item>
              </ion-list>
            </ion-content>
            <ion-footer>
              <ion-toolbar>
                <ion-buttons end>
                  <button ion-button icon-right color="royal" (click)="addTolatestnews()">
                    Submit
                    <ion-icon name="send"></ion-icon>
                  </button>
                </ion-buttons>
              </ion-toolbar>
            </ion-footer>`
})

export class Addadmissionalert {
  
  childLoader: any;
  myChildLoadingControl: any;
  latestnewsPostData: any;
  childResponseData: any;
  submitcurriculum: any;
  mylatnews: any;
  mylnews: any;
  //facilities: Array<{facilityid: number}>;

  constructor(
              public navCtrl: NavController,
              public navParams: NavParams,
              public authservice: AuthServiceProvider,
              public childLoadingCtrl: LoadingController,
              public toastCtrl: ToastController,
              public modalCtrl: ModalController,
              public viewCtrl: ViewController,
              public alertCtrl: AlertController
             )
  {
    //this.childPostData = {schoolid: window.localStorage.getItem('schoolid')};
    //this.submitcurriculum = {schoolid: window.localStorage.getItem('schoolid'),txtheading:'', txtdescription: ''};
    this.latestnewsPostData = {newsid: 0 ,schoolid: window.localStorage.getItem('schoolid'), txtlatestnews: ''};
    this.latestnewsPostData.txtlatestnews = "";
    this.mylatnews = navParams.get('myObj');
    this.mylnews = navParams.get('nid');
    this.latestnewsPostData.newsid = navParams.get('nid');
    //studentObject = $scope.student;
    //return studentObject.firstName;
      if(this.mylnews != 0)
        {
          this.childLoader = this.childLoadingCtrl.create({
            content : "Please wait.."
          });

          this.childLoader.present().then(() => {
            
            this.latestnewsPostData.lid = this.mylnews;
            this.authservice.postData(this.latestnewsPostData, 'admissionalerts/getedit').then((result)=>{
              
            this.childResponseData = result;
            console.log(this.childResponseData);
            if(this.childResponseData['response'] == 1){
   
            this.childLoader.dismiss();
            this.latestnewsPostData.txtlatestnews=this.childResponseData['latestnews'][0].newstopic;
          

              }
             
            },(err)=> {
                //alert('failled '+err);
                let toast = this.toastCtrl.create({
                    message: err,
                    duration: 3000
                  });
                toast.present();
                this.childLoader.dismiss();
            });
            
          }); 
        }
    
  }
  modalDismiss()
  {
    this.viewCtrl.dismiss();
  }

  addTolatestnews()
  {
   
    if (this.latestnewsPostData.txtlatetsnews == '')
      {
          let toast = this.toastCtrl.create({
              message: "Please enter admission alert detail",
              duration: 3000
            });
          toast.present();
          return false;
      }


     this.authservice.postData(this.latestnewsPostData, 'admissionalerts/add').then((result)=>{
          
          this.childResponseData = result;
          console.log(this.childResponseData);
         
          if(this.childResponseData['response'] == 1){
  
            let alert = this.alertCtrl.create({
              title: 'Successful!',
              subTitle: 'Admission alert has been added successfully.',
              buttons: [
                {
                  text: 'Ok',
                  handler: () => {
                    this.mylatnews.loadlatestnews();
                    this.modalDismiss();
                  }
                }
              ]
            });
            alert.present();
     
          }
          else
          {
            let toast = this.toastCtrl.create({
                message: "Sorry! we are unable to process your request",
                duration: 3000
              });
            toast.present();
          }          

        },(err)=> {
        
          let toast = this.toastCtrl.create({
                message: err,
                duration: 3000
            });
            toast.present();
         });
        
      }

    
   }
