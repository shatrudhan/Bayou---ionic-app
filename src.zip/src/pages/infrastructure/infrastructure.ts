import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, ToastController, AlertController, ModalController, ViewController } from 'ionic-angular';

/**
 * Generated class for the InfrastructurePage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-infrastructure',
  templateUrl: 'infrastructure.html',
})
export class InfrastructurePage {

  schoolName: string;
  loader: any;
  myLoadingControl: any;
  postData: any;
  responseData: any;
  items: Array<{infrastructurename: string, infrastructureid: number}>;
  submitPostData: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public authservice: AuthServiceProvider, public loadingCtrl: LoadingController, public toastCtrl: ToastController, public alertCtrl: AlertController, public modalCtrl: ModalController) {
    this.items = [];
    this.schoolName = localStorage.getItem('schoolname');
    this.myLoadingControl = loadingCtrl;
    this.postData = {schoolid: window.localStorage.getItem('schoolid')};
    this.submitPostData = {schoolid: window.localStorage.getItem('schoolid'), infraid: 0};
    this.loadInfrastructure();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad InfrastructurePage');
  }

  loadInfrastructure(){

    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {
      
      this.authservice.postData(this.postData, 'infrastructure/get').then((result)=>{
        
        this.responseData = result;
  		  console.log(this.responseData);
  		  if(this.responseData['response'] == 1){
          this.items = this.responseData['infrastructures'];
        }

        this.loader.dismiss();

  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismiss();
  	  });
      
    });
    
  }


  deleteInfrastructure(infraid){

    let confirm = this.alertCtrl.create({
      title: 'Confirmation',
      message: 'Are you sure? you want to remove this infrastructure',
      buttons: [
        {
          text: 'Yes',
          handler: () => {
            
            this.loader = this.myLoadingControl.create({
              content : "Please wait.."
            });

            this.loader.present().then(() => {
              
              this.submitPostData.infraid = infraid;
              this.authservice.postData(this.submitPostData, 'infrastructure/delete').then((result)=>{
                
                this.responseData = result;
                console.log(this.responseData);
                if(this.responseData['response'] == 1){
                  
                  this.loader.dismiss();
                  
                  let alert = this.alertCtrl.create({
                    title: 'Successful!',
                    subTitle: 'Selected infrastructure has been removed successfully from school information.',
                    buttons: ['OK']
                  });
                  alert.present();

                  let index = 0;
                  for(let i=0;i<this.items.length;i++)
                  {
                    if (this.items[i].infrastructureid == infraid)
                    {
                      index = i;
                      break;
                    }
                  }

                  this.items.splice(index, 1);

                }
                else
                {
                  this.loader.dismiss();
                  let toast = this.toastCtrl.create({
                      message: "Sorry! we are unable to process your request",
                      duration: 3000
                    });
                  toast.present();
                  this.loader.dismiss();
                }

                

              },(err)=> {
                  //alert('failled '+err);
                  let toast = this.toastCtrl.create({
                      message: err,
                      duration: 3000
                    });
                  toast.present();
                  this.loader.dismiss();
              });
              
            });

          }
        },
        {
          text: 'No',
          handler: () => {
            console.log('Agree clicked');
          }
        }
      ]
    });
    confirm.present();

  }

  addInfrastructure()
  {
    let modal = this.modalCtrl.create(AddMoreInfrastructure, {myObj: this});
    modal.present();
  }


}




@Component({
  selector: 'page-facilities',
  template: `<ion-header>
                <ion-navbar>
                  <ion-searchbar (input)="getItems($event)" start></ion-searchbar>
                  <ion-buttons end>
                    <button ion-button (click)="modalDismiss()">
                      <ion-icon name="close"></ion-icon>
                    </button>
                  </ion-buttons>
                </ion-navbar>                
             </ion-header>

            <ion-content>
              <ion-list>
                <button ion-item *ngFor="let item of childItems" (click)="itemSelected(item)">
                  {{ item.infrastructurename }}
                </button>
              </ion-list>
            </ion-content>
            `
})


export class AddMoreInfrastructure {
  
  childLoader: any;
  myChildLoadingControl: any;
  childPostData: any;
  childResponseData: any;
  childItems: Array<{infrastructurename: string, infrastructureid: number}>;
  actualItems: Array<{infrastructurename: string, infrastructureid: number}>;
  submitFacilities: any;
  myFacilities: any;
  facilities: Array<{facilityid: number}>;

  constructor(
              public navCtrl: NavController,
              public navParams: NavParams,
              public authservice: AuthServiceProvider,
              public childLoadingCtrl: LoadingController,
              public toastCtrl: ToastController,
              public modalCtrl: ModalController,
              public viewCtrl: ViewController,
              public alertCtrl: AlertController
             )
  {
    this.myChildLoadingControl = childLoadingCtrl;
    this.childPostData = {schoolid: window.localStorage.getItem('schoolid')};
    this.submitFacilities = {schoolid: window.localStorage.getItem('schoolid'), facilities: ''};
    this.submitFacilities.facilities = [];
    this.childItems = [];
    this.actualItems = [];
    this.facilities = [];
    this.childResponseData = [];
    this.myFacilities = navParams.get('myObj');
    this.loadAllInfrastructures();
  }

  modalDismiss()
  {
    this.viewCtrl.dismiss();
  }

  loadAllInfrastructures(){

    this.childLoader = this.myChildLoadingControl.create({
      content : "Please wait.."
    });

    this.childLoader.present().then(() => {
      
      this.authservice.postData(this.childPostData, 'infrastructure/getall').then((result)=>{
        
        this.childResponseData = result;
  		  console.log(this.childResponseData);
  		  if(this.childResponseData['response'] == 1){
          this.childItems = this.childResponseData['infrastructures'];
          this.actualItems = this.childItems;
        }

        this.childLoader.dismiss();

  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.childLoader.dismiss();
  	  });
      
    });
    
  }

  getItems(ev: any) {
    // Reset items back to all of the items
    //this.initializeItems();

    // set val to the value of the searchbar
    let val = ev.target.value;

    // if the value is an empty string don't filter the items
    if (val && val.trim() != '') {
      this.childItems = this.actualItems.filter((item) => {
        return (item.infrastructurename.toLowerCase().indexOf(val.toLowerCase()) > -1);
      })
    }
    else
    {
      this.childItems = this.actualItems;
      return this.childItems;
    }
  }

  itemSelected(myItem)
  {
    let modal = this.modalCtrl.create(InfrastructureInformation, {myObj: this, infraid: myItem.infrastructureid, infraname: myItem.infrastructurename});
    modal.present();
  }

}






// infrastructure detail screen
@Component({
  selector: 'page-facilities',
  template: `<ion-header>
                <ion-navbar>
                  <ion-title>
                    Infrastructure Information
                  </ion-title>
                  <ion-buttons end>
                    <button ion-button (click)="modalDismiss()">
                      <ion-icon name="close"></ion-icon>
                    </button>
                  </ion-buttons>
                </ion-navbar>                
             </ion-header>

            <ion-content>
              <ion-list>
                <ion-item>
                  <ion-label floating>Infrastructure title</ion-label>
                  <ion-input type="text" name="txttitle" [(ngModel)]="submitPostData.title" disabled></ion-input>
                </ion-item>
                <ion-item>
                  <ion-label floating>Infrastructure information</ion-label>
                  <ion-textarea [(ngModel)]="submitPostData.description" style="height:100% !important;"></ion-textarea>
                </ion-item>
              </ion-list>
            </ion-content>
            <ion-footer>
              <ion-toolbar>
                <ion-buttons end>
                  <button ion-button icon-right color="royal" (click)="addInfraToSchool()">
                    Submit
                    <ion-icon name="send"></ion-icon>
                  </button>
                </ion-buttons>
              </ion-toolbar>
            </ion-footer>
            `
})


export class InfrastructureInformation {
  
  childLoader: any;
  myChildLoadingControl: any;
  myInfrastructures: any;
  facilities: Array<{facilityid: number}>;
  submitPostData: any;
  childResponseData: any;

  constructor(
              public navCtrl: NavController,
              public navParams: NavParams,
              public authservice: AuthServiceProvider,
              public childLoadingCtrl: LoadingController,
              public toastCtrl: ToastController,
              public modalCtrl: ModalController,
              public viewCtrl: ViewController,
              public alertCtrl: AlertController
             )
  {
    this.myChildLoadingControl = childLoadingCtrl;
    this.submitPostData = {schoolid: window.localStorage.getItem('schoolid'), infraid: navParams.get('infraid'), title: navParams.get('infraname'), description: ''};
    this.myInfrastructures = navParams.get('myObj');
  }

  modalDismiss()
  {
    this.viewCtrl.dismiss();
  }

  addInfraToSchool()
  {
    this.childLoader = this.myChildLoadingControl.create({
      content : "Please wait.."
    });

    

    this.childLoader.present().then(() => {
      
      this.authservice.postData(this.submitPostData, 'infrastructure/add').then((result)=>{
        
        this.childResponseData = result;
        console.log(this.childResponseData);
        if(this.childResponseData['response'] == 1){
          
          this.childLoader.dismiss();
          
          let alert = this.alertCtrl.create({
            title: 'Successful!',
            subTitle: 'Selected infrastructure has been added successfully to school information.',
            buttons: [
              {
                text: 'Ok',
                handler: () => {
                  let index = 0;
                  for(let i=0;i<this.myInfrastructures.childItems.length;i++)
                  {
                    if (this.myInfrastructures.childItems[i].infrastructureid == this.submitPostData.infraid)
                    {
                      index = i;
                      break;
                    }
                  }
                  let toast = this.toastCtrl.create({
                    message: index + '',
                    duration: 3000
                  });
                  toast.present();
                  this.myInfrastructures.childItems.splice(index, 1);
                  //this.myInfrastructures.loadAllInfrastructures();
                  this.myInfrastructures.myFacilities.loadInfrastructure();
                  this.modalDismiss();
                }
              }
            ]
          });
          alert.present();
          //this.modalDismiss();
        }
        else
        {
          this.childLoader.dismiss();
          let toast = this.toastCtrl.create({
              message: "Sorry! we are unable to process your request",
              duration: 3000
            });
          toast.present();
          this.childLoader.dismiss();
        }          

      },(err)=> {
          //alert('failled '+err);
          let toast = this.toastCtrl.create({
              message: err,
              duration: 3000
          });
          toast.present();
          this.childLoader.dismiss();
      });
      
    });
  }

}
