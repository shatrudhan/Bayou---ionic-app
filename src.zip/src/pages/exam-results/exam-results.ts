import { global } from './../../app/global';
import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer';
import { FileChooser } from '@ionic-native/file-chooser';
import { FilePath } from '@ionic-native/file-path';
import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, ToastController, ActionSheetController, AlertController, Platform } from 'ionic-angular';
import { File } from '@ionic-native/file';
import { FileOpener } from '@ionic-native/file-opener';

/**
 * Generated class for the ExamResultsPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
declare var cordova:any;

@Component({
  selector: 'page-exam-results',
  templateUrl: 'exam-results.html',
})
export class ExamresultPage {

  schoolName: any;
  loader: any;
  myLoadingCtrl: any;
  postData: any;
  items: Array<{doctitle: string, docpath: string, documentid: number, extension: string}>;
  schoolid: any;
  storageDirectory: string = '';

  constructor(public navCtrl: NavController, public navParams: NavParams, public loadingCtrl: LoadingController, public authservice: AuthServiceProvider, public toastCtrl: ToastController, public fileTransfer: FileTransfer, public filePath: FilePath, public myFile: File, public actionSheetCtrl: ActionSheetController, public fileChooser: FileChooser, public alertCtrl: AlertController, public fileOpener:FileOpener, public platform:Platform) {
    this.schoolName = window.localStorage.getItem('schoolname');
    this.schoolid = window.localStorage.getItem('schoolid');
    this.myLoadingCtrl = loadingCtrl;
    this.postData = {schoolid: window.localStorage.getItem('schoolid'), doctype: 'R', documentid: 0};
    this.items = [];
    this.platform.ready().then(() => {
      if(!this.platform.is('cordova')) {
        return false;
      }
      if (this.platform.is('ios')) {
        this.storageDirectory = cordova.file.documentsDirectory;
      }
      else if(this.platform.is('android')) {
        this.storageDirectory = cordova.file.externalDataDirectory ;
      }
      else {
        // exit otherwise, but we could add further types here e.g. Windows
        return false;
      }
    });
    this.getInformation();
  }
  
  getInformation(){
    
        this.loader = this.myLoadingCtrl.create({
          content : "Please wait.."
        });
    
        this.loader.present().then(() => {
          
          this.authservice.postData(this.postData, 'documents/get').then((result)=>{
            
            if(result['response'] == 1){
              this.items = result['documents'];
            } 
            else
            {
              let toast = this.toastCtrl.create({
                  message: 'Sorry! unable to process your request',
                  duration: 3000
                });
              toast.present();
            }
    
            this.loader.dismiss();       
    
          },(err)=> {
              //alert('failled '+err);
              let toast = this.toastCtrl.create({
                  message: err,
                  duration: 3000
                });
              toast.present();
              this.loader.dismiss();
          });
    
          //this.loader.dismiss();
          
        });
        
      }
    

  ionViewDidLoad() {
    console.log('ionViewDidLoad ExamresultPage');
  }

  /********************  EXAM RESULT UPLOAD STARTING HERE  ******************/

  public createFileName(filename,fextension) 
  {
    var d = new Date(),
    n = d.getTime(),
    newFileName = "result"+ n + "."+fextension;
    return newFileName;
  }

  uploadDocument()
  {
    this.fileChooser.open().then(uri =>{
      this.filePath.resolveNativePath(uri).then(path => {

        var fileExtension = path.substring(path.lastIndexOf('.') + 1, path.length );
      if(fileExtension == "pdf")
         {

        let prompt = this.alertCtrl.create({
          title: 'Exam Result',
          message: "Please enter the result description",
          inputs: [
            {
              name: 'title',
              placeholder: 'Exam result description...'
            },
          ],
          buttons: [
            {
              text: 'Cancel',
              handler: data => {
                return;
              }
            },
            {
              text: 'Save',
              handler: adata => {    
                
                if (adata.title == "")
                {
                  let toast = this.toastCtrl.create({
                    message: "Please enter the result description",
                    duration: 3000
                  });
                  toast.present();
                  return false;
                }

                let myLoader = this.myLoadingCtrl.create({
                  content : "Please wait.."
                });
                
                myLoader.present().then(() => {

                    // Destination URL
                    let url = global.apiUrl+'documents/upload';
                    // File name only
                    var filename = path.substring(path.lastIndexOf('/') + 1, path.length );
                    // file extension
                    var fileExtension = path.substring(path.lastIndexOf('.') + 1, path.length );
                    var newFileName = this.createFileName(filename,fileExtension);
                    // File for Upload path
                    var targetPath = path;
                    //let toast = this.toastCtrl.create({ message: 'file ex : '+fileExtension+' , file name : '+newFileName, 'cssClass':'toastText', duration: 30000 });
                    //toast.present();

                    var options: FileUploadOptions  = {
                      fileKey: "file",
                      fileName: newFileName,
                      chunkedMode: false,
                      mimeType: "multipart/form-data",
                      params : {'filename': newFileName, 'schoolid': this.schoolid, 'doctype': 'R', 'title': adata.title}
                    };
                    
                    const fileTransfer: FileTransferObject = this.fileTransfer.create();                    
                                  
                    // Use the FileTransfer to upload the image
                    fileTransfer.upload(targetPath, url, options ).then((data) => {
                      myLoader.dismissAll();
                      let retData = JSON.parse(data.response);
                    
                      if (retData['response'] == 1)          
                      {
                        let toast = this.toastCtrl.create({
                          message: "Exam result has been uploaded successfully!",
                          duration: 3000
                        });
                        toast.present();

                          this.items.push({
                            doctitle: retData['doctitle'],
                            docpath: global.apiBackoffice + retData['docpath'],
                            documentid: retData['docid'],
                            extension: fileExtension
                          });
                          
                      }
                    }, err => {
                      myLoader.dismissAll();
                      let toast = this.toastCtrl.create({
                        message: "Sorry! unable to process your request:",
                        duration: 3000
                      });
                      toast.present();
                    });


                }, errL => {
                  myLoader.dismissAll();
                  let toast = this.toastCtrl.create({
                    message: "Error:"+errL,
                    duration: 3000
                  });
                  toast.present();
                });                


              }
            }
          ]
        });
        prompt.present();
      }
      else
        {
          let toast = this.toastCtrl.create({
            message: "Please select pdf file only..!",
            duration: 3000
          });
          toast.present();
        }
        
      });
    });
  }

 
  fileOpen(filepath,extension)
  {
      /* let toast = this.toastCtrl.create({
        message: 'Open'+filepath,
        duration: 3000
      });
      toast.present(); */

      /* this.fileOpener.open(filepath, "application/*")
      .then(() => console.log("File is opened"))
      .catch(e => console.log('Error')); */

      var filename = filepath.substring(filepath.lastIndexOf('/') + 1, filepath.length );
      
      //this.platform.ready().then(() => {

        const fileTransfer: FileTransferObject = this.fileTransfer.create();
        const imageLocation = global.apiBaseUrl+'backoffice/uploads/school-'+this.schoolid+'/'+filename;

        fileTransfer.download(encodeURI(filepath), this.storageDirectory + filename).then((entry) => 
        {
          /*const alertSuccess = this.alertCtrl.create({
            title: `Download Succeessful!`,
            subTitle: `${filename} was successfully downloaded.`,
            buttons: ['Ok']
          });
          alertSuccess.present();*/

          //this.getMimeType(this.storageDirectory + filename);

          this.fileOpener.open(this.storageDirectory + filename, global.getMIMEtype(extension)).then(() => 
          console.log('File is opened'))
          .catch(e => console.log('Error openening file', e));

        }, (error) => {
          const alertFailure = this.alertCtrl.create({
            title: `Download Failed !`,
            subTitle: `${filename} failed to download.`,
            buttons: ['Ok']
          });
          alertFailure.present();
        });
       
      //});
      
  }


  deleteDocument(docId)
  {
    let confirm = this.alertCtrl.create({
      title: 'Confirmation',
      message: 'Are you sure? you want to remove this exam result',
      buttons: [
        {
          text: 'Yes',
          handler: () => {
            
            this.loader = this.myLoadingCtrl.create({
              content : "Please wait.."
            });

            // let toast = this.toastCtrl.create({
            //   message: docId+'',
            //   duration: 3000
            // });
            // toast.present();

            this.loader.present().then(() => {
              
              //let docPostData = {docid: docId, schoolid: this.schoolid};
              this.postData.docid = docId;
              this.authservice.postData(this.postData, 'documents/delete').then((result)=>{
                
                if(result['response'] == 1){
                  
                  this.loader.dismissAll();
                  
                  let alert = this.alertCtrl.create({
                    title: 'Successful!',
                    subTitle: 'Selected exam result has been removed successfully.',
                    buttons: ['OK']
                  });
                  alert.present();

                  let index = 0;
                  for(let i=0;i<this.items.length;i++)
                  {
                    if (this.items[i].documentid == docId)
                    {
                      index = i;
                      break;
                    }
                  }

                  this.items.splice(index, 1);

                }
                else
                {
                  this.loader.dismissAll();
                  let toast = this.toastCtrl.create({
                      message: "Sorry! we are unable to process your request",
                      duration: 3000
                    });
                  toast.present();
                  //this.loader.dismiss();
                }

                

              },(err)=> {
                  //alert('failled '+err);
                  let toast = this.toastCtrl.create({
                      message: err,
                      duration: 3000
                    });
                  toast.present();
                  this.loader.dismiss();
              });
              
            });

          }
        },
        {
          text: 'No',
          handler: () => {
            console.log('Agree clicked');
          }
        }
      ]
    });
    confirm.present();
  }

  /********************  EXAM RESULT UPLOAD ENDS HERE  ******************/


}
