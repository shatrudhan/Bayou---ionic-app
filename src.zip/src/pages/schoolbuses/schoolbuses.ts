import { BusattendancePage } from './../busattendance/busattendance';
import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController } from 'ionic-angular';
import { ToastController } from 'ionic-angular/components/toast/toast-controller';

/**
 * Generated class for the SchoolbusesPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-schoolbuses',
  templateUrl: 'schoolbuses.html',
})
export class SchoolbusesPage {

  loader: any;
  schoolName: string;
  postData: any;
  items: Array<{routeno: any, busno: any, drivername: string, routeid: number}>;

  constructor(public navCtrl: NavController, public navParams: NavParams, public myLoadingControl: LoadingController, public authservice: AuthServiceProvider, public toastCtrl: ToastController) {
    this.schoolName = window.localStorage.getItem('schoolname');
    this.postData = {schoolid: window.localStorage.getItem('schoolid')};
    this.items = [];
    this.loadBuses();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SchoolbusesPage');
  }

  loadBuses(){
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {

      let url = "";

      this.authservice.postData(this.postData, "bus/getall").then((result)=>{
  		//this.responseData = result;
  		//console.log(this.responseData);
  		if(result['response'] == 1){
        this.items = result['buses'];
        this.loader.dismiss();
  		}else{
        this.loader.dismiss();
  		}
  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismiss();
  	  });
    });
  }

  itemTapped(routeid) {
    // That's right, we're pushing to ourselves!
    this.navCtrl.push(BusattendancePage, {routeid: routeid}, {animate:true,animation:'transition',duration:600,direction:'forward'});
  }

}
