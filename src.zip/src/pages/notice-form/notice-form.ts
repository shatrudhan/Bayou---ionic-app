import { Component } from '@angular/core';
import { ViewController, NavController, NavParams, LoadingController, ToastController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { FileChooser } from '@ionic-native/file-chooser';
import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer';
import { global } from '../../app/global';
import { FilePath } from '@ionic-native/file-path';
import { File } from '@ionic-native/file';
import { NoticeBoardPage } from '../notice-board/notice-board'
import { FirebasedbProvider } from './../../providers/firebasedb/firebasedb';


@Component({
  selector: 'page-notice-form',
  templateUrl: 'notice-form.html',
})
export class NoticeFormPage {
  NoticePageObj: any;
  wordLimit: any;
  NoticeSubmitBtn: boolean;
  UploadedFileName: string;
  attachStatus: string;
  responseData: any;
  userData1: any;
  nativepath: any;

  schoolid: string;
  loading: any;
  loader: any;
  myLoadingControl: any;

  teacherid : any;
  allclass : any;

  classArray: Array<{ tid:any, secid:any, classname: any, sectionname: any }>;
  

  constructor(
              public navCtrl: NavController, 
              public navParams: NavParams, 
              public authservice: AuthServiceProvider, 
              public loadingCtrl: LoadingController, 
              public toastCtrl: ToastController,
              public fileChooser: FileChooser,
              public fileTransfer: FileTransfer,
              public filePath: FilePath,   
              public file: File,
              public viewCtrl: ViewController, 
              public fbProvider: FirebasedbProvider,              
  )
  {
    //let toast = this.toastCtrl.create({ message: localStorage.getItem('schoolid'), 'cssClass':'toastText', duration: 3000 });
    //toast.present();
    this.NoticePageObj = navParams.get('NoticePageObj'); 
    
    this.myLoadingControl = loadingCtrl;
    this.schoolid = localStorage.getItem('schoolid');
    this.teacherid = localStorage.getItem('teacherid');

    this.userData1 = {schoolid: this.schoolid, noticeText: '', document: '', classids: '' , teacherid: this.teacherid};

    // Attach status
    this.attachStatus = 'N';
    this.NoticeSubmitBtn = global.makeDisabled;

    this.wordLimit = 300;

    this.classArray=[];
    this.getteacherclass();

   
  }

  ionViewDidLoad(){ console.log('ionViewDidLoad NoticeFormPage'); }

  ModalDismiss()
  {
    this.NoticePageObj.getAllSchoolNotice();
    this.viewCtrl.dismiss();
  }

  public presentToast(text) {
    let toast = this.toastCtrl.create({
      message: text,
      duration: 3000,
      position: 'bottom'
    });
    toast.present();
  }
  
  public isTrimed(v) 
  {
    return v.replace(/^\s+|\s+$/gm,'');
  }

  public textAreaEmpty()
  {
      var nt = this.isTrimed(this.userData1['noticeText']);
      
      //let toast = this.toastCtrl.create({ message: 'lenght :'+nt.length, 'cssClass':'toastText', duration: 3000 });
      //toast.present();
      this.wordLimit = 300 - nt.length;

      if(nt.length == 0){
        this.NoticeSubmitBtn = global.makeDisabled; 
      }else{
        this.NoticeSubmitBtn = global.makeEnabled;        
      }
  }

  public createFileName(filename,fextension) 
  {
    var d = new Date(),
    n = d.getTime(),
    newFileName =  n + "."+fextension;
    return newFileName;
  }

  uploadNoticeDoc()
  {
    this.fileChooser.open().then(uri =>{
      this.filePath.resolveNativePath(uri).then(path => {
      
        // Destination URL
        let url = global.apiUrl+'NoticeDocUpload';

        // File name only
        var filename = path.substring(path.lastIndexOf('/') + 1, path.length );

        // file extension
        var fileExtension = path.substring(path.lastIndexOf('.') + 1, path.length );

        var newFileName = this.createFileName(filename,fileExtension);

        // File for Upload path
        var targetPath = path;      
        
        if(newFileName != ''){
          this.attachStatus = 'Y';
        }else{
          this.attachStatus = 'N';
        }
        //let toast = this.toastCtrl.create({ message: 'file ex : '+fileExtension+' , file name : '+newFileName, 'cssClass':'toastText', duration: 30000 });
        //toast.present();

        var options: FileUploadOptions  = {
          fileKey: "file",
          fileName: newFileName,
          chunkedMode: false,
          mimeType: "multipart/form-data",
          params : {'fileName': newFileName, 'schoolid': this.schoolid}
        };
        
        const fileTransfer: FileTransferObject = this.fileTransfer.create();
        
        this.loading = this.loadingCtrl.create({content: 'Uploading...',});
        this.loading.present();
        
        // Use the FileTransfer to upload the image
        fileTransfer.upload(targetPath, url, options ).then((data) => {
          this.UploadedFileName = newFileName;
          this.loading.dismissAll();
        }, err => {
          this.loading.dismissAll();
          this.presentToast('File uploading failled !');
        });
      });
    });
  }

  NoticeFormSubmit()
  {

    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {
      if(this.UploadedFileName){
        this.userData1['document'] = this.UploadedFileName;
      }else{
        this.userData1['document'] = '';
      } 
    if(this.teacherid != 0)
      { 
       // alert('enter');
      if(this.userData1.classids == ''){
        let toast = this.toastCtrl.create({
          message: 'Please select atleast one class.',
          duration: 3000
        }); 
        this.loader.dismiss();
        toast.present();
        return false;
      }
    } 
   // else
     // {
      //  alert('else');
      //  return false;
     // }                
      this.authservice.postData(this.userData1, 'addNotice').then((result)=>{
          if(result['response'] == 1){
            this.fbProvider.NoticePushMessage(this.schoolid,global.wordLimiter(this.userData1['noticeText'],70),result['studentArray']);            
            this.userData1['noticeText'] = '';
            this.userData1['classids'] = '';
            this.userData1['document'] = ''; 
            this.UploadedFileName = '';
            this.attachStatus = 'N';  
            this.NoticeSubmitBtn = global.makeDisabled;
            this.loader.dismiss();
            let toast = this.toastCtrl.create({ message: result['msg'], 'cssClass':'toastText', duration: 3000 });
            toast.present();
            this.viewCtrl.dismiss();
            this.NoticePageObj.getAllSchoolNotice(); 
          }else{
            this.loader.dismiss();
            let toast = this.toastCtrl.create({ message: result['msg'], 'cssClass':'toastText', duration: 3000 });
            toast.present();
          }
        },(err)=> {
          this.loader.dismiss();
          let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 3000 });
          toast.present();
      });
    });

  }


  getteacherclass()
  {
    this.authservice.postData({'teacherid':this.teacherid,'schoolid':this.schoolid}, 'allottedclasses').then((result)=>{
     if(result['response'] == 1){
        this.allclass = result['classinfo'];
        console.log( result['classinfo']);
        for(let val of result['classinfo'])
        {
          this.classArray.push({
            tid: val['classid'],
            secid: val['sectionid'],
            classname: val['classname'],
            sectionname: val['sectionname'], 
           });
        }
        //this.loader.dismiss();
      }else{
        let toast = this.toastCtrl.create({ message: 'Sorry ! no class found.', duration: 3000 });
        toast.present();
       // this.loader.dismiss();
      }
    },(err)=> {
      let toast = this.toastCtrl.create({ message: err, duration: 3000 });
      toast.present();
      //this.loader.dismiss();
    });



  }




}
