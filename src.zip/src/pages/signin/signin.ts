import { SchoolpanelPage } from './../schoolpanel/schoolpanel';
import { global } from './../../app/global';
import { TrackingPage } from './../tracking/tracking';
import { Component } from '@angular/core';
import {  NavController, Platform, NavParams, LoadingController, ToastController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';

import { HomePage } from '../home/home';
import { HomePage as p_HomePage } from '../parent/home/home';
import { EmailConfigurationPage } from '../parent/email-configuration/email-configuration';
import { AuthServiceProvider as p_AuthServiceProvider } from '../../providers/parent/auth-service/auth-service';
import { SpaccountverificationPage } from '../spaccountverification/spaccountverification';
import { ForgotpasswordPage } from '../forgotpassword/forgotpassword';
import { ClaimschoolPage } from '../claimschool/claimschool';
import { SignupPage } from '../parent/signup/signup';
import { FCM } from '@ionic-native/fcm';


@Component({
  selector: 'page-signin',
  templateUrl: 'signin.html',
})
export class SigninPage {
  responseData: any;
  userData: any;
  loader: any;
  myLoadingControl: any;

  constructor(
              public platform: Platform,     
              public navCtrl: NavController, 
              public navParams: NavParams, 
              public authservice: AuthServiceProvider, 
              public loadingCtrl: LoadingController, 
              public toastCtrl: ToastController,
              public p_authservice : p_AuthServiceProvider,
              public fcm: FCM,                
            )
  {
    this.userData = {txtteacheremailid: '', txtteacherpass: '', userType: '', FcmDeviceToken:''};
    this.userData.txtteacheremailid = "";
    this.userData.txtteacherpass = "";
    this.userData.userType = "",
    this.userData.FcmDeviceToken = "",    
    //this.userData.txtemail = "";
    //this.userData.txtpassword = "";
    this.myLoadingControl = loadingCtrl;
    this.platform.ready().then(() => {
      this.fcm.getToken().then((token:string)=>{
        localStorage.setItem('FcmDeviceToken', token);
      });
    });
  }

  ionViewDidLoad() 
  {
    if (localStorage.getItem('useremail') != "")
    {
      if(localStorage.getItem('isParent') == 'parent')
      {
        this.p_authservice.postData({'email':window.localStorage.getItem('useremail'),'token':localStorage.getItem('FcmDeviceToken'),'usertype':'parent'}, "UserDeviceTokenRegistration").then((result)=>{
          if(result['response'] == 1){
            console.log('device token registered successfully.');
          }
        });        
        if(global.isValidPhone(window.localStorage.getItem('useremail')) == true ){
          this.navCtrl.setRoot(EmailConfigurationPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});        
        }else{
          this.navCtrl.setRoot(p_HomePage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
        }
      }
      else
      {
        if (parseInt(localStorage.getItem('teacherid')) != 0)
        {
          if (parseInt(localStorage.getItem('isdriver')) == 0)
          {
            global.busId = parseInt(window.localStorage.getItem('busid'));
            if (parseInt(window.localStorage.getItem('isadmin')) == 0){
              this.p_authservice.postData({'email':window.localStorage.getItem('useremail'),'token':localStorage.getItem('FcmDeviceToken'),'usertype':'teacher'}, "UserDeviceTokenRegistration").then((result)=>{
                if(result['response'] == 1){
                  console.log('device token registered successfully.');
                }
              }); 
              this.navCtrl.setRoot(HomePage, {}, {animate:true,animation:'transition',duration:300,direction:'forward'});
            }else{
              this.navCtrl.setRoot(SchoolpanelPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
            }
          }
          else
          {
            global.busId = parseInt(window.localStorage.getItem('mybusid'));
            //this.navCtrl.setRoot(TrackingPage, {}, {animate: true, direction: 'forward'});
          }
        }
        else
        {
          this.loader = this.myLoadingControl.create({
            content : "Please wait.."
          });
      
          this.loader.present().then(() => {
      
            let aPostData = {schoolid: window.localStorage.getItem('schoolid'), loginid: window.localStorage.getItem('useremail')};
            this.authservice.postData(aPostData, "isaccountverified").then((result)=>{
              //this.responseData = result;
              //console.log(this.responseData);
              window.localStorage.setItem('isactive', result['response']);
              this.loader.dismiss();

              if (result['response'] == 0)
                this.navCtrl.setRoot(SpaccountverificationPage, {}, {animate:true,animation:'transition',duration:300,direction:'forward'});
              else
                this.navCtrl.setRoot(SchoolpanelPage, {}, {animate:true,animation:'transition',duration:300,direction:'forward'});

            },(err)=> {
                //alert('failled '+err);
                let toast = this.toastCtrl.create({
                    message: err,
                    duration: 3000
                  });
                toast.present();
                this.loader.dismiss();
            });
          });
        }
     }
    }
  }

  login()
  {

    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });
    if(this.userData.userType == ''){
      let toast = this.toastCtrl.create({
        message: 'Please select user type.',
        duration: 3000
      }); 
      toast.present();
      return false;
    }else if(this.userData.userType == 'p'){

      localStorage.setItem('isParent', 'parent');
      var ue = this.userData.txtteacheremailid; // txtemail
      var up = this.userData.txtteacherpass; // txtpassword 
      this.userData.txtemail = ue;
      this.userData.txtpassword = up;
      this.userData.FcmDeviceToken = localStorage.getItem('FcmDeviceToken');
      
      this.loader = this.myLoadingControl.create({
          content : "Please wait.."
      });

      this.loader.present().then(() => {
        this.p_authservice.postData(this.userData, 'login').then((result)=>{
            this.responseData = result;
            if(this.responseData['response'] == 1){
              this.loader.dismiss();
              localStorage.setItem('useremail',ue);

              let checkEmail = global.isValidEmail(ue);
              let checkMobile = global.isValidPhone(ue);
              if(checkEmail == true){
                // login with email
                this.navCtrl.setRoot(p_HomePage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
              }else if(checkMobile == true){
                // login with mobile number
                this.p_authservice.postData({'mobileno':localStorage.getItem('useremail')}, 'isEmail').then((result)=>{
                  if(result['response'] == 0){
                    this.navCtrl.push(EmailConfigurationPage);
                  }else if(result['response'] == 1){
                    // if login with mobile number and also available email id
                    localStorage.clear();
                    localStorage.setItem('useremail', result['sess_email']);
                    this.navCtrl.setRoot(p_HomePage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});               
                  }
                },(err)=> {
                  let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 3000 });
                  toast.present();
                });
                
              }
            }else{
              this.loader.dismiss();
              let toast = this.toastCtrl.create({ message: this.responseData['msg'], 'cssClass':'toastText', duration: 3000 });
              toast.present();
            }
          },(err)=> {
            this.loader.dismiss();
            let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 3000 });
            toast.present();
        });
      });

    }else{
      this.loader.present().then(() => {
        this.authservice.postData(this.userData, 'teacherlogin').then((result)=>{
        this.responseData = result;
        console.log(this.responseData);
        if(this.responseData['result'] == 1){
          window.localStorage.setItem('useremail',this.userData.txtteacheremailid);
          window.localStorage.setItem('teacherid', this.responseData['teacherid']);
          window.localStorage.setItem('schoolid', this.responseData['schoolid']);
          window.localStorage.setItem('teachername', this.responseData['teachername']);
          window.localStorage.setItem('busincharge', this.responseData['busincharge']);
          window.localStorage.setItem('busid', this.responseData['busid']);
          window.localStorage.setItem('schoolname', this.responseData['schoolname']);
          window.localStorage.setItem('isdriver', this.responseData['isdriver']);
          window.localStorage.setItem('mybusid', this.responseData['mybusid']);
          window.localStorage.setItem('schoolurl', this.responseData['profileurl']);
          window.localStorage.setItem('isadmin', this.responseData['isadmin']);
          window.localStorage.setItem('isactive', this.responseData['isactive']);
          this.loader.dismiss();
          
          if (this.responseData['teacherid'] != 0)
          {
            if (this.responseData['isdriver'] == '0')
            {
              this.p_authservice.postData({'email':window.localStorage.getItem('useremail'),'token':localStorage.getItem('FcmDeviceToken'),'usertype':'teacher'}, "UserDeviceTokenRegistration").then((result)=>{
                if(result['response'] == 1){
                  console.log('device token registered successfully.');
                }
              });
              global.busId = parseInt(window.localStorage.getItem('busid'));
              this.navCtrl.setRoot(HomePage, {}, {animate:true,animation:'transition',duration:300,direction:'forward'});
            }
            else
            {
              /*let toast = this.toastCtrl.create({
                message: this.responseData['isdriver'],
                duration: 3000
              });
              toast.present();*/
              global.busId = parseInt(window.localStorage.getItem('mybusid'));
              this.navCtrl.setRoot(TrackingPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
            }
          }
          else
          {
            if (this.responseData['isactive'] == 0)
            this.navCtrl.setRoot(SpaccountverificationPage, {}, {animate:true,animation:'transition',duration:300,direction:'forward'});
          else
            this.navCtrl.setRoot(SchoolpanelPage, {}, {animate:true,animation:'transition',duration:300,direction:'forward'});
          }
            
          //this.navCtrl.push(HomePage);
          //this.nav.push(HomePage) ;
        }else{
          let toast = this.toastCtrl.create({
              message: this.responseData['msg'],
              duration: 3000
            });
          toast.present();
          this.loader.dismiss();
        }
        },(err)=> {
            //alert('failled '+err);
            let toast = this.toastCtrl.create({
                message: err,
                duration: 3000
              });
            toast.present();
            this.loader.dismiss();
        });
      });
    }
  }

  gotoForgotPassword()
  {
    this.navCtrl.push(ForgotpasswordPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
  }

  signUp(val)
  {
      if (val == 1)
        this.navCtrl.push(ClaimschoolPage, {}, {animate:true,animation:'transition',duration:300,direction:'forward'});
      if(val == 2)
        this.navCtrl.push(SignupPage, {}, {animate:true,animation:'transition',duration:300,direction:'forward'});
  }

}
