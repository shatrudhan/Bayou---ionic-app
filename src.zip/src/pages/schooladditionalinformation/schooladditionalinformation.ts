import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { Component } from '@angular/core';
import { NavController, NavParams, ViewController, LoadingController, ToastController, ActionSheetController, AlertController } from 'ionic-angular';

/**
 * Generated class for the SchooladditionalinformationPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-schooladditionalinformation',
  templateUrl: 'schooladditionalinformation.html',
})
export class SchooladditionalinformationPage {

  submitPostData: any;
  years: Array<{year: string}>;
  myLoadingCtrl: any;
  loader: any;
  boards: Array<{}>;
  schoolName: string;
  basicInfo: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public viewCtrl: ViewController, public loadingCtrl: LoadingController, public authservice: AuthServiceProvider, public toastCtrl: ToastController, public alertCtrl: AlertController) {
    this.schoolName = window.localStorage.getItem('schoolname');
    this.basicInfo = navParams.get('myObj');
    this.years = [];
    this.boards = [];
    this.myLoadingCtrl = loadingCtrl;
    this.submitPostData = {schoolid: window.localStorage.getItem('schoolid'), establishmentyear: '', principalname: '', educationboard: '', gender: '', feerange: '', category: '', medium: ''}
    this.years.push({year: 'NA'});
    for(let i=2017;i>=1850;i--)
    {
      this.years.push({
        year: i.toString()
      })
    }
    this.getInformation();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SchooladditionalinformationPage');
  }

  getInformation(){

    this.loader = this.myLoadingCtrl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {
      
      this.authservice.postData(this.submitPostData, 'additionalinformation/getforedit').then((result)=>{
        
        //this.responseData = result;
  		  //console.log(this.responseData);
  		  if(result['response'] == 1){          

          //this.states = result['states'];
          //this.cities = this.responseData['cities'];
          //this.areas = this.responseData['areas'];
          this.boards = result['boards'];
          this.submitPostData.establishmentyear = result['information'][0]['establishmentyear'];
          this.submitPostData.principalname = result['information'][0]['principlename'];
          this.submitPostData.medium = result['information'][0]['medium'];
          this.submitPostData.educationboard = result['information'][0]['educationboard'].split(',');
          this.submitPostData.gender = result['information'][0]['gender'];
          this.submitPostData.category = result['information'][0]['schoolcategory'].split(",");
          this.submitPostData.feerange = result['information'][0]['feerange'];
        }

        this.loader.dismiss();

  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismiss();
  	  });
      
    }, (error) => {
      this.loader.dismiss();
    });
    
  }

  modalDismiss()
  {
    this.viewCtrl.dismiss();
  }

  updateInformation()
  {
    if (this.submitPostData.establishmentyear == "" || this.submitPostData.principalname == "" || this.submitPostData.educationboard == "" || this.submitPostData.gender == "" || this.submitPostData.feerange == "" || this.submitPostData.category == "" || this.submitPostData.medium == "")
    {
      let toast = this.toastCtrl.create({
          message: "Please enter the required fields to proceed",
          duration: 3000
      });
      toast.present();
    }
    else
    {
      let areaLoader = this.myLoadingCtrl.create({
        content : "Please wait.."
      });

      areaLoader.present().then(() => {

        this.authservice.postData(this.submitPostData, 'additionalinformation/update').then((resulta)=>{
          
          if(resulta['response'] == 1){
            areaLoader.dismiss();
            let alert = this.alertCtrl.create({
              title: 'Successful!',
              subTitle: 'Information has been updated successfully!',
              buttons: [
                {
                  text: 'Ok',
                  handler: () => {                    
                    this.basicInfo.getInformation();
                    this.modalDismiss();
                  }
                }
              ]
            });
            alert.present();
          }
          else
          {
            areaLoader.dismiss();
          }          

        },(err)=> {
            let toast = this.toastCtrl.create({
                message: err,
                duration: 3000
              });
            toast.present();
            areaLoader.dismiss();
        });
        
      });
    }
  }

}
