import { ListPage } from './../list/list';
import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { Component } from '@angular/core';
import { NavController, NavParams, ToastController } from 'ionic-angular';
import { LoadingController } from 'ionic-angular/components/loading/loading-controller';

/**
 * Generated class for the SchoolteachersPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-schoolteachers',
  templateUrl: 'schoolteachers.html',
})
export class SchoolteachersPage {

  loader: any;
  postData: any;
  items: Array<{teachername: string, teacherid: number, designation: string}>;
  schoolName: string;

  constructor(public navCtrl: NavController, public navParams: NavParams, public mLoadingCtrl: LoadingController, public authservice: AuthServiceProvider, public toastCtrl: ToastController) {
    this.postData = {schoolid: window.localStorage.getItem('schoolid')};
    this.schoolName = window.localStorage.getItem('schoolname');
    this.items = [];
    this.getTeachers();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SchoolteachersPage');
  }

  getTeachers(){
    this.loader = this.mLoadingCtrl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {
      this.authservice.postData(this.postData, 'teachers/get').then((result)=>{
  		//this.responseData = result;
  		//console.log(this.responseData);
        if(result['response'] == 1){
          this.items = result['teachers'];
        }
        this.loader.dismissAll();
  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismissAll();
  	  });
    });
  }

  itemTapped(teacherId, teacherName){
    this.navCtrl.push(ListPage, {teacherid: teacherId, teachername: teacherName.toLocaleUpperCase()});
  }

}
