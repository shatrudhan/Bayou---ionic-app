import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { InAppBrowser, InAppBrowserOptions } from '@ionic-native/in-app-browser';
//import {} from '@ionic-native/fc'

/**
 * Generated class for the MydiaryPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-mydiary',
  templateUrl: 'mydiary.html',
})
export class MydiaryPage {

  options : InAppBrowserOptions = {
      location : 'yes',//Or 'no'
      hidden : 'no', //Or  'yes'
      clearcache : 'yes',
      clearsessioncache : 'yes',
      zoom : 'yes',//Android only ,shows browser zoom controls
      hardwareback : 'yes',
      mediaPlaybackRequiresUserAction : 'no',
      shouldPauseOnSuspend : 'no', //Android only
      closebuttoncaption : 'Close', //iOS only
      disallowoverscroll : 'no', //iOS only
      toolbar : 'yes', //iOS only
      enableViewportScale : 'no', //iOS only
      allowInlineMediaPlayback : 'no',//iOS only
      presentationstyle : 'pagesheet',//iOS only
      fullscreen : 'yes',//Windows only
  };

  constructor(public navCtrl: NavController, public navParams: NavParams, public theInAppBrowser: InAppBrowser) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MydiaryPage');
  }

  openPaymentGateway()
  {
    var pageContent = '<html><head></head><body><form id="loginForm" action="https://test.payu.in/_payment" method="post">' +
    '<input name="mkey" value="rjQUPktU|c4a8307ed06be40a3a71|250|SPORTS FEE|Ranjit singh|xyz@gmail.com|||||||||||e5iIg1jwi8" type="hidden">'+
    '<input name="email" value="xyz@gmail.com" type="hidden">'+
  '  <input name="phone" value="9630012020" type="hidden">'+
    '<input name="key" value="rjQUPktU" type="hidden">'+
    '<input name="hash" value="9a30a2949eca702345123bb6220579c7ef5a73090f89b80e5f845e1b2b5515c2e0f26d8728bcba72525900ba68ae472b058185fa868fe9174bd1da98dbb1d5dd" type="hidden">'+
    '<input name="txnid" value="c4a8307ed06be40a3a71" type="hidden">'+
    '<input name="amount" value="250" type="hidden">'+
    '<input id="firstname" name="firstname" value="Ranjit singh" type="hidden">'+
    '<input name="address1" value="Vijay Nagar" type="hidden">'+
    '<input name="city" value="Indore" type="hidden">'+
    '<input name="state" value="Madhya Pradesh" type="hidden">'+
    '<input name="country" value="India" type="hidden">'+
    '<input name="zipcode" value="452001" type="hidden">'+
    '<input name="productinfo" value="SPORTS FEE" type="hidden">'+
    '<input name="surl" value="http://localhost/ribblu-final/index.php/users/dashboard/paymentresponse?scid=NjQ5&stid=Mg==&fid=MjE=" size="64" type="hidden">'+
    '<input name="furl" value="http://localhost/ribblu-final/index.php/users/dashboard/paymentresponse?scid=NjQ5&stid=Mg==&fid=MjE=" size="64" type="hidden">'+
    '<input name="service_provider" value="payu_paisa" size="64" type="hidden">'+

    '</form> <script type="text/javascript">document.getElementById("loginForm").submit();</script></body></html>';
    var pageContentUrl = 'data:text/html;base64,' + btoa(pageContent);
    //alert(pageContentUrl);

    let iabRef = this.theInAppBrowser.create('http://192.168.43.91/app.ribblu.com/payment.php',"_self",this.options);
    //let iabRef = this.theInAppBrowser.create(pageContentUrl,"_self",this.options);
    iabRef.show();
    iabRef.on("loadstop").subscribe(result => {
      //console.debug(e, event);
      //result.returnValue
      if (result.url.match("http://www.ribblu.com")) {
        iabRef.close();
      }
      //$rootScope.$broadcast('$ionicParentView.enter');
    });
  }

}
