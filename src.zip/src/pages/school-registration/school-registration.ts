import { SchoolsignupPage } from '../schoolsignup/schoolsignup';
import { AreaListPage } from '../area-list/area-list';
import { SchoolslistPage } from './../schoolslist/schoolslist';
import { SigninPage } from './../signin/signin';
import { ToastController } from 'ionic-angular/components/toast/toast-controller';
import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { AuthServiceProvider as authParentProvider } from './../../providers/parent/auth-service/auth-service';
import { LoadingController, ModalController } from 'ionic-angular';
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Pipe } from '@angular/core';
import { DatePipe } from '@angular/common';
import {Validators, FormGroup, FormBuilder } from '@angular/forms';


@Pipe({
  name: 'dateFormatPipe',
})

@Component({
  selector: 'page-school-registration',
  templateUrl: 'school-registration.html',
})
export class SchoolRegistrationPage {
  statecityarea: any;
  cityArea: any;

  SchoolTempReg: { 'schoolname': string; 'schoolemail':string; 'schoolwebsite': string; 'schooltype1': string; 'estyear': string; 'principlename': string; 'schoolboard': string; 'schooltype2': string; 'schoolcategory': string; 'schoolmedium': string; 'schoolgender': string; 'contactno': string; 'address': string; 'countryname': string; 'statename': string; 'cityname': string; 'areaname': string; 'pincode': string; };

  actualItem: any;
  items: any;
  city: any;
  areas: any;
  allCountries: any;
  maxYear: any;
  myLoadingControl: any;loader: any;
  states: Array<{statename: string}>;
  cities: Array<{cityname: string}>;
  public SchoolRegistrationForm : FormGroup;
  schoolemail: any; pincode: any; areas1: any; cities1: any; states1: any; countries: any; schooladdess: any; schoolcontact: any; schoolgender: any; schoolmedium: any; schoolcategory: any; schooltype2: any; schoolboard: any; principlename: any; estyear: any; schooltype1: any; schoolwebsite: any; schoolname: any;

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams, 
    public loadingCtrl: LoadingController, 
    public authservice: AuthServiceProvider, 
    public toastCtrl: ToastController, 
    public modalCtrl: ModalController,
    public authPservice: authParentProvider,
    public formBuilder: FormBuilder,    
  ) 
  {
    this.myLoadingControl = loadingCtrl;
    var datePipe = new DatePipe("en-US");
    var currentDate = datePipe.transform(Date.now(), 'yyyy');
    this.maxYear = currentDate;

    this.getCountries();
    this.getStates();

    // school registration form validation
    this.SchoolRegistrationForm = this.formBuilder.group({
      schoolname: ['', [Validators.required]],
      schoolemail:['', [Validators.required]],
      schoolwebsite: [''],      
      schooltype1: ['', [Validators.required]], 
      estyear: ['', [Validators.required]], 
      principlename: ['', [Validators.required]],
      schoolboard: ['', [Validators.required]], 
      schooltype2: ['', [Validators.required]],
      schoolcategory: ['', [Validators.required]],
      schoolmedium: ['', [Validators.required]], 
      schoolgender: ['', [Validators.required]], 
      schoolcontact: ['', [Validators.required, Validators.pattern("[0-9]*")]], 
      schooladdess: ['', [Validators.required]], 
      countries: ['', [Validators.required]], 
      states: ['', [Validators.required]],  
      cities: ['', [Validators.required]],
      areas: ['', [Validators.required]],
      pincode: ['', [Validators.required,Validators.minLength(6),Validators.maxLength(6),Validators.pattern("[0-9]*")]],                        
      // login_password: ['', [Validators.required, Validators.minLength(6)]]
    });
    this.schoolname = this.SchoolRegistrationForm.controls['schoolname'];
    this.schoolemail = this.SchoolRegistrationForm.controls['schoolemail'];    
    this.schoolwebsite = this.SchoolRegistrationForm.controls['schoolwebsite'];
    this.schooltype1 = this.SchoolRegistrationForm.controls['schooltype1'];
    this.estyear = this.SchoolRegistrationForm.controls['estyear'];
    this.principlename = this.SchoolRegistrationForm.controls['principlename'];
    this.schoolboard = this.SchoolRegistrationForm.controls['schoolboard'];
    this.schooltype2 = this.SchoolRegistrationForm.controls['schooltype2'];
    this.schoolcategory = this.SchoolRegistrationForm.controls['schoolcategory'];
    this.schoolmedium = this.SchoolRegistrationForm.controls['schoolmedium'];
    this.schoolgender = this.SchoolRegistrationForm.controls['schoolgender'];
    this.schoolcontact = this.SchoolRegistrationForm.controls['schoolcontact'];
    this.schooladdess = this.SchoolRegistrationForm.controls['schooladdess'];
    this.countries = this.SchoolRegistrationForm.controls['countries'];
    this.states1 = this.SchoolRegistrationForm.controls['states'];
    this.cities1 = this.SchoolRegistrationForm.controls['cities'];
    this.areas1 = this.SchoolRegistrationForm.controls['areas'];
    this.pincode = this.SchoolRegistrationForm.controls['pincode'];
  
    this.SchoolTempReg = { 'schoolname':'', 'schoolemail':'', 'schoolwebsite':'', 'schooltype1':'', 'estyear':'', 'principlename':'', 'schoolboard':'', 'schooltype2':'', 'schoolcategory':'', 'schoolmedium':'', 'schoolgender':'', 'contactno':'', 'address':'', 'countryname':'', 'statename':'', 'cityname':'', 'areaname':'', 'pincode':''}
  }

  // all counry
  getCountries()
  {
    this.authPservice.postData({}, 'getAllCountries').then((result)=>{
      this.allCountries = result['countries'];
    },(err)=> {
        let toast = this.toastCtrl.create({
            message: err,
            duration: 3000
          });
        toast.present();
    });
  }

  // all states
  getStates()
  {
      this.loader = this.myLoadingControl.create({
        content : "Please wait.."
      });
      this.loader.present().then(() => {
        let submitData = {schoolid: 0};
        this.authservice.postData(submitData, 'basicinformation/getstates').then((result)=>{
          if(result['response'] == 1){          
              this.states = result['states'];
          }
          this.loader.dismiss();
        },(err)=> {
            let toast = this.toastCtrl.create({
                message: err,
                duration: 3000
              });
            toast.present();
            this.loader.dismiss();
        });
      });
  }

  // get cities by state
  getCities(statename)
  {
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });
    this.SchoolTempReg.areaname = '';    
    this.loader.present().then(() => {
      this.authservice.postData({'state':statename}, 'basicinformation/getcities').then((result)=>{
        if(result['response'] == 1){
          this.cities = result['cities'];
          this.items = '';
          this.actualItem = '';
          this.statecityarea = statename;
        }else{
          this.cities = null;
          this.items = '';
          this.actualItem = '';
        }
        this.loader.dismiss();
      },(err)=> {
          let toast = this.toastCtrl.create({
              message: err,
              duration: 3000
            });
          toast.present();
          this.loader.dismiss();
      });
    });
  }

  // get area by city
  getAreas(city)
  {
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });
    this.SchoolTempReg.areaname = '';              
    this.loader.present().then(() => {
      this.authPservice.postData({'cityname':city}, 'getLocalityAreas').then((result)=>{
        if(result['response'] == 1){
          this.items = result['areas'];
          this.actualItem = this.items;
          this.cityArea = city;
        }else{
          this.items = '';
          this.actualItem = '';
        }
        this.loader.dismiss();
      },(err)=> {
          let toast = this.toastCtrl.create({
              message: err,
              duration: 3000
            });
          toast.present();
          this.loader.dismiss();
      });
    });
  }

  getFilterArea(ev: any) 
  {
    let modal = this.modalCtrl.create(AreaListPage, {cityname:this.cityArea,statename:this.statecityarea,AreaItemsObj: this.items,AreaActualItemsObj: this.actualItem});
    modal.present();
    modal.onDidDismiss((result) => {
      this.SchoolTempReg.areaname = result.areaname;
      // this.schoolinfo.areaid = result.areaid;
    });
  }
  
  gotoAcountInformation()
  {
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {
      // this.schoolinfo['schoolboard'].toString();
      // console.log(this.SchoolTempReg);
      this.loader.dismiss();
      this.navCtrl.push(SchoolsignupPage, {schoolTempRegJson: this.SchoolTempReg, isclaim:0}, {animate:true,animation:'transition',duration:300,direction:'forward'});
    });
    
  }


  ionViewDidLoad() {
    console.log('ionViewDidLoad SchoolRegistrationPage');
  }


}
