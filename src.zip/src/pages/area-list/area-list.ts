import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { Component } from '@angular/core';
import { NavController, NavParams, ViewController, ToastController, AlertController } from 'ionic-angular';
import { LoadingController, ModalController } from 'ionic-angular';
import { setTimeout } from 'timers';


@Component({
  selector: 'page-area-list',
  templateUrl: 'area-list.html',
})
export class AreaListPage {
  statename: any;
  NewAreaBtnItem: boolean;
  inputDiv: boolean;
  cityname: any;
  actualItem: any;
  items: any;
  myLoadingControl: any;loader: any;
  EnableOrDisable: boolean;
  
  constructor(
              public navCtrl: NavController, 
              public navParams: NavParams, 
              public myChildLoadingControl: LoadingController, 
              public viewCtrl: ViewController, 
              public authservice: AuthServiceProvider, 
              public toastCtrl: ToastController,
              public modalCtrl: ModalController,
              public loadingCtrl: LoadingController,
              public alertCtrl: AlertController,
              )
  {
    this.myLoadingControl = loadingCtrl;    
    this.items = this.navParams.get('AreaItemsObj');
    this.actualItem = this.navParams.get('AreaActualItemsObj');
    this.cityname = this.navParams.get('cityname');
    this.statename = this.navParams.get('statename');
    
    
    if(this.items){
      this.EnableOrDisable = false;      
    }else{
      this.EnableOrDisable = true;
      let toast = this.toastCtrl.create({
        message: 'Sorry! no data found.',
        duration: 3000
      });
    toast.present();
      setTimeout(()=>{
        this.viewCtrl.dismiss();    
      },2000);     
    }   
  }

  modalDismiss()
  {
    this.viewCtrl.dismiss();
  }

  getItems(ev: any) 
  {
    let val = ev.target.value;
    if (val && val.trim() != ''){
      this.items = this.actualItem.filter((item) => {
        return (item.areaname.toLowerCase().indexOf(val.toLowerCase()) > -1);
      })
    }else{
      this.items = this.actualItem
      return this.items;
    }
  }

  ionViewDidLoad() 
  {
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });
    this.loader.present().then(() => {
      this.loader.dismiss();      
    });
  }

  itemSelected(areaid, areaname)
  {
    this.viewCtrl.dismiss({areaid: areaid, areaname: areaname});
  }

  AddFabBtn()
  {
    let prompt = this.alertCtrl.create({
      title: 'Add New Area',
      enableBackdropDismiss: false,
      inputs: [
        {
          name: 'areaname',
          placeholder: 'Enter area name...'
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Save',
          handler: data => {
            if(data.areaname == '' || data.areaname == null){
              let toast = this.toastCtrl.create({ message: 'Please enter area name first!', duration: 3000 });
              toast.present();
              return false;
            }else{
              this.loader = this.myLoadingControl.create({
                content : "Please wait.."
              });

              this.loader.present().then(() => {
                this.authservice.postData({areaname:data.areaname,cityname:this.cityname,statename:this.statename }, 'addNewLocalArea').then((result)=>{
                  if(result['response'] == 2){
                    this.loader.dismiss(); 
                    let toast = this.toastCtrl.create({ message: 'Sorry! area name already exist.', duration: 3000 });
                    toast.present();
                    return false;
                  }
                  if(result['response'] == 1){
                    this.items.push({areaid: result['areaid'], areaname: result['areaname']});
                    this.viewCtrl.dismiss({areaid: result['areaid'], areaname: result['areaname']});
                    this.loader.dismiss();
                    prompt.dismiss();
                  }else{
                    let toast = this.toastCtrl.create({ message: 'Sorry! something went wrong.', duration: 3000 });
                    toast.present();
                    return false;
                  }
                },(err)=> {
                    this.loader.dismiss(); 
                    let toast = this.toastCtrl.create({ message: err, duration: 3000 });
                    toast.present();
                    return false;
                });
              });
            }
            return false;
          }
        }
      ]
    });
    prompt.present();
  }



}
