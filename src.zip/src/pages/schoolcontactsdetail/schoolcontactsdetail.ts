import { ToastController } from 'ionic-angular/components/toast/toast-controller';
import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, Content, LoadingController, AlertController, ModalController, ViewController } from 'ionic-angular';

/**
 * Generated class for the SchoolcontactsdetailPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-schoolcontactsdetail',
  templateUrl: 'schoolcontactsdetail.html',
})
export class SchoolcontactsdetailPage {

  @ViewChild(Content) content: Content;
  
    schoolName: string;
    logEmailid: string;
    selectedItem: any;
    icons: string[];
    items: Array<{replycomment: string,rname:string,byemail:string,repid: number, datetime: any, rdate: any, allreply: any}>;
    myLoadingControl: any;
    loader: any;
    responseData: any;
    postData: any;
    replys: Array<{replycomment: string,rname:string,byemail:string,replyid: number, datetime: any, rdate: any, schoollogo: any}>;  
    username: string;
    useremailid: string;
    subject: string;

    

  constructor(public navCtrl: NavController, public navParams: NavParams, public loadingCtrl: LoadingController, public authservice: AuthServiceProvider, public toastCtrl: ToastController, public alertCtrl: AlertController, public modalCtrl: ModalController) {
    this.loader
    this.myLoadingControl = loadingCtrl;
    this.schoolName = localStorage.getItem('schoolname');
    this.logEmailid = localStorage.getItem('useremail');
    this.items = [];
    this.replys = [];
    this.postData = { schoolid: window.localStorage.getItem('schoolid'), enquiryid: navParams.get('enquiryid')};
    this.loadMessages();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SchoolcontactsdetailPage');
  }

  addCurriculum()
  {
    let modal = this.modalCtrl.create(Addcontactquiryreply, {cuid: this.postData.enquiryid, myObj: this, uemailid: this.useremailid, uname: this.username, subject: this.subject});
    modal.present();
  }

  loadMessages(){
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.replys = [];

    this.loader.onDidDismiss(() => {
      //setTimeout(()=>{this.content.scrollToBottom();},100);
      this.content.scrollToBottom();
    })

    this.loader.present().then(() => {
      this.authservice.postData(this.postData, 'contactqueries/getdetail').then((result)=>{
  		this.responseData = result;
  		console.log(this.responseData);
  		if(this.responseData['response'] == 1){
        this.items = this.responseData['information'];
        this.replys.push({
          replycomment : this.responseData['replymessage'],
          rdate: this.responseData['replydate'],
          replyid: this.responseData['replyid'],
          rname: 'School admin',
          byemail: '',
          datetime: '',
          schoollogo: this.responseData['schoollogo']
        });  
        this.username = this.items[0]['name'];
        this.useremailid = this.items[0]['emailid'];
        this.subject = this.items[0]['subject'];
        this.loader.dismissAll();
      }else{
        this.loader.dismissAll();
  		}
  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismissAll();
  	  });
    });

   
  }

  deleteMyreply(rid){
    
    let confirm = this.alertCtrl.create({
      title: 'Confirmation',
      message: 'Are you sure? you want to remove this reply'+rid,
      buttons: [
        {
          text: 'Yes',
          handler: () => {
            
            this.loader = this.myLoadingControl.create({
              content : "Please wait.."
            });

            this.loader.present().then(() => {
              
              let deletePostData = {schoolid: window.localStorage.getItem('schoolid'), replyid: rid};
              this.authservice.postData(deletePostData, 'admissionenquiries/delete').then((result)=>{
                
              this.responseData = result;
              console.log(this.responseData);
                if(this.responseData['response'] == 1){
                  
                  this.loader.dismissAll();
                  
                  let alert = this.alertCtrl.create({
                    title: 'Successful!',
                    subTitle: 'Selected reply has been removed successfully.',
                    buttons: ['OK']
                  });
                  alert.present();


                  let index = 0;
                  for(let i=0;i<this.replys.length;i++)
                  {
                    if (this.replys[i].replyid == rid)
                    {
                      index = i;
                      break;
                    }
                  }
                  
                  this.replys.splice(index, 1);

                }
                else
                {
                  this.loader.dismissAll();
                  let toast = this.toastCtrl.create({
                      message: "Sorry! we are unable to process your request",
                      duration: 3000
                    });
                  toast.present();
                  this.loader.dismissAll();
                }

              },(err)=> {
                  //alert('failled '+err);
                  let toast = this.toastCtrl.create({
                      message: err,
                      duration: 3000
                    });
                  toast.present();
                  this.loader.dismissAll();
              });
              
            });

          }
        },
        {
          text: 'No',
          handler: () => {
            console.log('Agree clicked');
          }
        }
      ]
    });
    confirm.present();

  }

}

@Component({
  selector: 'page-replydetail',
  template: `<ion-header>
                <ion-navbar>
                <ion-title>Reply on Enquiry</ion-title>
                <ion-buttons end>
                    <button ion-button (click)="modalDismiss()">
                      <ion-icon name="close"></ion-icon>
                    </button>
                  </ion-buttons>
                </ion-navbar>                
             </ion-header>
            
            <ion-content>
              <ion-list>
                <ion-item>
                <ion-label floating>Enter your reply</ion-label>
                <ion-textarea name="txtdescription" [(ngModel)]="replyPostData.txtdescription"></ion-textarea>
                </ion-item>
              </ion-list>
            </ion-content>
            <ion-footer>
              <ion-toolbar>
                <ion-buttons end>
                  <button ion-button icon-right color="royal" (click)="addToEnquiryreply()">
                    Submit
                    <ion-icon name="send"></ion-icon>
                  </button>
                </ion-buttons>
              </ion-toolbar>
            </ion-footer>`
})


export class Addcontactquiryreply {
  
  childLoader: any;
  myChildLoadingControl: any;
  replyPostData: any;
  childResponseData: any;
  submitcurriculum: any;
  myReplys: any;
  myCurrid: any;
  
  constructor(
              public navCtrl: NavController,
              public navParams: NavParams,
              public authservice: AuthServiceProvider,
              // public childLoadingCtrl: LoadingController,
              public toastCtrl: ToastController,
              public modalCtrl: ModalController,
              public viewCtrl: ViewController,
              public alertCtrl: AlertController,
              public mLoadingCtrl: LoadingController
             )
  {
    this.replyPostData = {enquiryid: 0 ,schoolid: window.localStorage.getItem('schoolid'),userid:window.localStorage.getItem('useremail'), txtdescription: '', schoolname: window.localStorage.getItem('schoolname'), useremailid: '', username: '', subject: ''};
    this.replyPostData.txtdescription = "";
    this.myReplys = navParams.get('myObj');
    this.myCurrid = navParams.get('cuid');
    this.replyPostData.enquiryid = navParams.get('cuid');
    this.replyPostData.useremailid = navParams.get('uemailid');
    this.replyPostData.username = navParams.get('uname');
    this.replyPostData.subject = navParams.get('subject');
  }
  modalDismiss()
  {
    this.viewCtrl.dismiss();
  }

  addToEnquiryreply()
  {
   
      if (this.replyPostData.txtdescription == '')
      {
          let toast = this.toastCtrl.create({
              message: "Please enter enquiry reply",
              duration: 3000
            });
          toast.present();
          return false;
      }

      let mloader = this.mLoadingCtrl.create({
        content : "Please wait.."
      });

      mloader.present().then(() => {

        this.authservice.postData(this.replyPostData, 'contactqueries/reply').then((result)=>{
            
            this.childResponseData = result;
            console.log(this.childResponseData);
            if(this.childResponseData['response'] == 1){
              
              mloader.dismissAll();

              let alert = this.alertCtrl.create({
                title: 'Successful!',
                subTitle: 'Reply has been added successfully.',
                buttons: [
                  {
                    text: 'Ok',
                    handler: () => {
                      
                      this.myReplys.loadMessages();
                      this.modalDismiss();
                    }
                  }
                ]
              });
              alert.present();
      
            }
            else
            {
              mloader.dismissAll();
              let toast = this.toastCtrl.create({
                  message: "Sorry! we are unable to process your request",
                  duration: 3000
                });
              toast.present();
            }          

          },(err)=> {
            
            mloader.dismissAll();
            let toast = this.toastCtrl.create({
                  message: err,
                  duration: 3000
              });
            toast.present();
          });

      }, err => {
        mloader.dismissAll();
        let toast = this.toastCtrl.create({
          message: err,
          duration: 3000
        });
        toast.present();
      });

    }

    
}
