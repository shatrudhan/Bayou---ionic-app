import { SigninPage } from '../signin/signin';
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-school-temp-regis-confirmation',
  templateUrl: 'school-temp-regis-confirmation.html',
})
export class SchoolTempRegisConfirmationPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SchoolTempRegisConfirmationPage');
  }

  goToLoginPage()
  {
    this.navCtrl.setRoot(SigninPage, {}, {animate:true,animation:'transition',duration:300,direction:'forward'});
  }
}
