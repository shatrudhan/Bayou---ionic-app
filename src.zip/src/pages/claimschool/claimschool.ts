import { SchoolsignupPage } from './../schoolsignup/schoolsignup';
import { SchoolslistPage } from './../schoolslist/schoolslist';
import { SigninPage } from './../signin/signin';
import { ToastController } from 'ionic-angular/components/toast/toast-controller';
import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { LoadingController, ModalController } from 'ionic-angular';
//import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
//import { LoadingController } from 'ionic-angular/umd/components/loading/loading-controller';

/**
 * Generated class for the ClaimschoolPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-claimschool',
  templateUrl: 'claimschool.html',
})
export class ClaimschoolPage {

  states: Array<{statename: string}>;
  cities: Array<{cityname: string}>;
  schoolinfo: any;
  loader: any;
  submitPostData: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public myLoadingCtrl: LoadingController, public authservice: AuthServiceProvider, public toastCtrl: ToastController, public modalCtrl: ModalController) {
    this.states = [];
    this.cities = [];
    this.schoolinfo = {schoolname: '', schoolid: 0, website: ''};
    this.submitPostData = {statename: '', cityname: ''};
    this.getInformation();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ClaimschoolPage');
  }

  getInformation(){
    
      this.loader = this.myLoadingCtrl.create({
        content : "Please wait.."
      });
  
      this.loader.present().then(() => {
  
        let submitData = {schoolid: 0};
        this.authservice.postData(submitData, 'basicinformation/getstates').then((result)=>{
          
          if(result['response'] == 1){          
              this.states = result['states'];
          }
  
          this.loader.dismiss();
  
        },(err)=> {
            let toast = this.toastCtrl.create({
                message: err,
                duration: 3000
              });
            toast.present();
            this.loader.dismiss();
        });
        
      });
        
  }

  /* modalDismiss()
  {
    this.viewCtrl.dismiss();
  } */

  getCities()
  {
    this.loader = this.myLoadingCtrl.create({
      content : "Loading cities.."
    });

    this.loader.present().then(() => {

      let statedata = {state: this.submitPostData.statename};
      
      this.authservice.postData(statedata, 'basicinformation/getcities').then((result)=>{
        
        if(result['response'] == 1){
          this.cities = result['cities'];
        }

        this.loader.dismiss();

      },(err)=> {
          let toast = this.toastCtrl.create({
              message: err,
              duration: 3000
            });
          toast.present();
          this.loader.dismiss();
      });
      
    });
  }

  getSchool()
  {
    if (this.submitPostData.cityname == "")
    {
      let toast = this.toastCtrl.create({
        message: "Please select city first",
        duration: 3000
      });
      toast.present();
      return false;
    }
    let modal = this.modalCtrl.create(SchoolslistPage, {myObj: this, state: this.submitPostData.statename, city: this.submitPostData.cityname});
    modal.present();
    modal.onDidDismiss((result) => {
      //let nav = modal.g
      //nav.popAll();
      // do something with result
      /* let toast = this.toastCtrl.create({
        message: result.schoolname,
        duration: 3000
      });
      toast.present(); */
      if (result != null)
      {
        this.schoolinfo.schoolname = result.schoolname;
        this.schoolinfo.schoolid = result.schoolid;
      }
    });
  }

  gotoClaim()
  {
    if (this.schoolinfo.schoolid == 0)
    {
      let toast = this.toastCtrl.create({
        message: "Please select your school from list to proceed for signup",
        duration: 3000
      });
      toast.present();
      return false;
    }

    let loader = this.myLoadingCtrl.create({
      content : "Please wait.."
    });

    loader.present().then(() => {

      let regdata = {schoolid: this.schoolinfo.schoolid};
      
      this.authservice.postData(regdata, 'isSchoolClaimed').then((result)=>{
        
        if(result['response'] == 1){
          
          let toast = this.toastCtrl.create({
            message: result['msg'],
            //duration: 3000
            position: "center",
            showCloseButton: true,
            closeButtonText: "Ok"
          });
          toast.present();

        }
        else if (result['response'] == 2)
        {
          this.navCtrl.push(SchoolsignupPage, {schoolid: this.schoolinfo.schoolid, schoolname: this.schoolinfo.schoolname, state: this.submitPostData.statename, city: this.submitPostData.cityname, website: this.schoolinfo.website, isclaim: 1}, {animate:true,animation:'transition',duration:300,direction:'forward'});
        }
        else
        {
          let toast = this.toastCtrl.create({
            message: result['msg'],
            duration: 3000
          });
          toast.present();
        }

        loader.dismiss();

      },(err)=> {
          let toast = this.toastCtrl.create({
              message: err,
              duration: 3000
            });
          toast.present();
          loader.dismiss();
      });
      
    });
  }

}
