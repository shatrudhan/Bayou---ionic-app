import { Component,Pipe } from '@angular/core';
import { DatePipe } from '@angular/common';
import { NavController, NavParams, ViewController, LoadingController, ToastController, AlertController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { FirebasedbProvider } from './../../providers/firebasedb/firebasedb';
import { parse } from 'url';


@Pipe({
  name: 'dateFormatPipe',
})


@Component({
  selector: 'page-classfees',
  templateUrl: 'classfees.html',
})
export class ClassfeesPage {
  lastDate: number;
  currentDate: string;
  //selectedItem: any;
  categories: Array<{categoryid: number}>;
  items: Array<{classname: string, sectionname: string}>;
  myLoadingControl: any;
  loader: any;
  responseData: any;
  postData: any;
  submitPostData: any;
  classes: any;

  constructor(public fbProvider: FirebasedbProvider,public navCtrl: NavController, public navParams: NavParams, public viewCtrl: ViewController, public loadingCtrl: LoadingController, public authservice: AuthServiceProvider, public toastCtrl: ToastController, public alertCtrl: AlertController) {
    //this.selectedItem = navParams.get('item');
    //this.loader
    this.myLoadingControl = loadingCtrl;

    this.items = [];
    this.classes = [];
    this.postData = {schoolid: window.localStorage.getItem('schoolid')};
    this.submitPostData = {schoolid: window.localStorage.getItem('schoolid'), title: '', description: '', amount: 0, useremail: window.localStorage.getItem('useremail'), studentcategory: '', classes: ''};
    this.submitPostData.lastdate = new Date().toISOString();
    this.submitPostData.studentcategory = [];
    this.submitPostData.classes = [];
    this.loadClasses();
     
    var datePipe = new DatePipe("en-US");
    this.currentDate = datePipe.transform(Date.now(), 'yyyy');
    this.lastDate = parseInt(this.currentDate)+parseInt('5');
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ClassfeesPage');
  }

  loadClasses(){
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {
      this.authservice.postData(this.postData, 'getfeeprerequisites').then((result)=>{
    		this.responseData = result;
    		console.log(this.responseData);
    		if(this.responseData['response'] == 1){
          this.classes = this.responseData['classes'];
          if (this.responseData['iscategory'] > 0)
            this.items = this.responseData['studentcategories'];
          this.loader.dismiss();
    		}else{
          this.loader.dismiss();
    		}
  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismiss();
  	  });
    });
  }

  submitFees(){
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {
      this.authservice.postData(this.submitPostData, 'fee/addclassfees').then((result)=>{
  		this.responseData = result;
      console.log(this.responseData);

      this.authservice.postData({'schoolid':localStorage.getItem('schoolid'),'studentcategory':this.submitPostData.studentcategory,'studentclass':this.submitPostData.classes}, 'getAllSchoolStudentsByClassSectionCategories').then((result)=>{
        if(result['responseData']){
          var schoolid = this.submitPostData.schoolid;
          var title = this.submitPostData.title;
          var amount = this.submitPostData.amount;
          var lastdate = this.submitPostData.lastdate;
          console.log(result['responseData']);
          // this.fbProvider.GeneralizeFeePushNotification(schoolid,title,amount,lastdate,result['responseData']);
        }
      });

  		if(this.responseData['response'] == 1){
        let doAlert = this.alertCtrl.create({
          title: 'Successful!',
          message: this.responseData['message'],
          buttons: [
                    {
                      text: 'Ok',
                      handler: () => {
                        this.dismiss();
                      }
                    }
                  ]
        });
        doAlert.present();
        this.loader.dismiss();
  		}else{
        this.loader.dismiss();
  		}
  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismiss();
  	  });
    });
  }

  dismiss() {
    this.viewCtrl.dismiss();
  }

}
