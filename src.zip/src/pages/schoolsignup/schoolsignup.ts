import { SchoolclaimconfirmationPage } from './../schoolclaimconfirmation/schoolclaimconfirmation';
import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { ToastController } from 'ionic-angular/components/toast/toast-controller';
import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, AlertController } from 'ionic-angular';
import { SchoolTempRegisConfirmationPage } from '../school-temp-regis-confirmation/school-temp-regis-confirmation';

@Component({
  selector: 'page-schoolsignup',
  templateUrl: 'schoolsignup.html',
})
export class SchoolsignupPage {

  schoolinfo: any;

  constructor(
              public navCtrl: NavController, 
              public navParams: NavParams, 
              public toastCtrl: ToastController, 
              public myLoadingCtrl: LoadingController, 
              public authservice: AuthServiceProvider,
              public alertCtrl: AlertController,              
            ) 
  {

    if (this.navParams.get('isclaim') == 1){
      this.schoolinfo = {emailid: '', password: '', mobileno: '', confirmpassword: '', name: '', usertype: '', title: '', updates: false, offers: false, schoolid: navParams.get('schoolid'), schoolname: navParams.get('schoolname'), state: navParams.get('state'), city: navParams.get('city'), schoolwebsite: navParams.get('website')};
    }
    if (navParams.get('isclaim') == 0){
      let schoolTempRegJson = this.navParams.get('schoolTempRegJson');
      this.schoolinfo = {emailid: '', password: '', mobileno: '', confirmpassword: '', name: '', usertype: '', title: '', updates: false, offers: false, 
                          schoolid: 0, 
                          schoolname: schoolTempRegJson['schoolname'],
                          schoolemail: schoolTempRegJson['schoolemail'],                           
                          state: schoolTempRegJson['statename'], 
                          city: schoolTempRegJson['cityname'], 
                          schoolwebsite: schoolTempRegJson['schoolwebsite'],
                          schooltype1: schoolTempRegJson['schooltype1'],
                          estyear: schoolTempRegJson['estyear'],
                          principlename: schoolTempRegJson['principlename'],
                          schoolboard: schoolTempRegJson['schoolboard'].toString(),
                          schooltype2: schoolTempRegJson['schooltype2'],
                          schoolcategory: schoolTempRegJson['schoolcategory'].toString(),
                          schoolmedium: schoolTempRegJson['schoolmedium'],
                          schoolgender: schoolTempRegJson['schoolgender'],
                          contactno: schoolTempRegJson['contactno'],
                          address: schoolTempRegJson['address'],
                          countryname: schoolTempRegJson['countryname'],
                          areaname: schoolTempRegJson['areaname'],
                          pincode: schoolTempRegJson['pincode']
                        };
    }
      
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SchoolsignupPage');
  }

  submit()
  {
    if (this.schoolinfo.emailid == "")
    {
      let toast = this.toastCtrl.create({
        message: "Please enter the email id",
        duration: 3000
      });
      toast.present();
      return false;
    }
    if (this.schoolinfo.password == "")
    {
      let toast = this.toastCtrl.create({
        message: "Please enter the login password",
        duration: 3000
      });
      toast.present();
      return false;
    }
    if (this.schoolinfo.confirmpassword == "")
    {
      let toast = this.toastCtrl.create({
        message: "Please retype the password",
        duration: 3000
      });
      toast.present();
      return false;
    }
    if (this.schoolinfo.password != this.schoolinfo.confirmpassword)
    {
      let toast = this.toastCtrl.create({
        message: "Password is not same! please retype password",
        duration: 3000
      });
      toast.present();
      return false;
    }
    if (this.schoolinfo.name == "")
    {
      let toast = this.toastCtrl.create({
        message: "Please enter your name",
        duration: 3000
      });
      toast.present();
      return false;
    }
    if (this.schoolinfo.mobileno == "")
    {
      let toast = this.toastCtrl.create({
        message: "Please enter 10 digit mobile no.",
        duration: 3000
      });
      toast.present();
      return false;
    }
    if (this.schoolinfo.mobileno.length != 10)
    {
      let toast = this.toastCtrl.create({
        message: "Mobile no. must be of 10 digit",
        duration: 3000
      });
      toast.present();
      return false;
    }
    if (this.schoolinfo.title == "")
    {
      let toast = this.toastCtrl.create({
        message: "Please select your title or role in school",
        duration: 3000
      });
      toast.present();
      return false;
    }

    
    let loader = this.myLoadingCtrl.create({
      content : "Please wait.."
    });

    loader.present().then(() => {

      let regdata = {emailid: this.schoolinfo.emailid};
      
      this.authservice.postData(regdata, 'isEmailRegistered').then((result)=>{
        
        if(result['response'] == 1){
          let toast = this.toastCtrl.create({
            message: result['msg'],
            duration: 3000
          });
          toast.present();
        }
        else if (result['response'] == 2)
        {
          // school claim registration condition    
          if (this.navParams.get('isclaim') == 1){
            this.navCtrl.push(SchoolclaimconfirmationPage, {emailid: this.schoolinfo.emailid, password: this.schoolinfo.password, mobileno: this.schoolinfo.mobileno, name: this.schoolinfo.name, usertype: this.schoolinfo.usertype, title: this.schoolinfo.title, updates: true, offers: true, schoolid: this.schoolinfo.schoolid, schoolname: this.schoolinfo.schoolname, state: this.schoolinfo.state, city: this.schoolinfo.city, schoolwebsite: this.schoolinfo.schoolwebsite}, {animate:true,animation:'transition',duration:300,direction:'forward'});
          }
          // school temp registration condition
          if (this.navParams.get('isclaim') == 0){
              this.authservice.postData(this.schoolinfo, 'SchoolTempRegistration').then((result)=>{
                if(result['response'] == 1){
                  // let toast = this.toastCtrl.create({ message: result['msg'], duration: 3000 });
                  // toast.present();
                  this.navCtrl.setRoot(SchoolTempRegisConfirmationPage, {}, {animate:true,animation:'transition',duration:300,direction:'forward'});
                }
              });
          }
        }
        else
        {
          let toast = this.toastCtrl.create({
            message: result['msg'],
            duration: 3000
          });
          toast.present();
        }

        loader.dismiss();

      },(err)=> {
          let toast = this.toastCtrl.create({
              message: err,
              duration: 3000
            });
          toast.present();
          loader.dismiss();
      });
      
    });
  
  }

}
