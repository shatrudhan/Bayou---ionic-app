import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, ToastController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';

@Component({
  selector: 'page-list',
  templateUrl: 'list.html'
})
export class ListPage {
  selectedItem: any;
  icons: string[];
  items: Array<{title: string, note: string, icon: string, srno: number, sectionname: string}>;
  myLoadingControl: any;
  loader: any;
  responseData: any;
  postData: any;
  isAdmin: any;
  teacherName: string;
  schoolName: string;

  constructor(public navCtrl: NavController, public navParams: NavParams, public loadingCtrl: LoadingController, public authservice: AuthServiceProvider, public toastCtrl: ToastController) {
    // If we navigated to this page, we will have an item available as a nav param
    this.selectedItem = navParams.get('item');
    this.loader
    this.myLoadingControl = loadingCtrl;
    this.schoolName = window.localStorage.getItem('schoolname');

    // Let's populate this page with some filler content for funzies
    this.icons = ['flask', 'wifi', 'beer', 'football', 'basketball', 'paper-plane',
    'american-football', 'boat', 'bluetooth', 'build'];

    this.items = [];
    /*for (let i = 1; i < 11; i++) {
      this.items.push({
        title: 'Item ' + i,
        note: 'This is item #' + i,
        icon: this.icons[Math.floor(Math.random() * this.icons.length)],
        srno: i
      });
    }*/
    this.isAdmin = window.localStorage.getItem('isadmin');
    if (parseInt(window.localStorage.getItem('isadmin')) == 0)
    {
      this.postData = {teacherid: window.localStorage.getItem('teacherid'), schoolid: window.localStorage.getItem('schoolid')};
      this.teacherName = "";
    }
    else
    {
      this.postData = {teacherid: navParams.get('teacherid'), schoolid: window.localStorage.getItem('schoolid')};
      this.teacherName = navParams.get('teachername');
    }

    

    this.loadPeriods();
  }

  itemTapped(event, item) {
    // That's right, we're pushing to ourselves!
    this.navCtrl.push(ListPage, {
      item: item
    });
  }

  loadPeriods(){
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {
      this.authservice.postData(this.postData, 'mytimetable/myperiods').then((result)=>{
  		this.responseData = result;
  		console.log(this.responseData);
  		if(this.responseData['response'] == 1){
        for(let data of this.responseData['periods'])
        {
          let periodname = data['periodname'].split(" ")[0];
          if (data['isfree'] == 0)
          {
            this.items.push({
              title: data['subjectname'],
              note: data['classname'],
              icon: this.icons[Math.floor(Math.random() * this.icons.length)],
              srno: periodname,
              sectionname: data['sectionname']
            });
          }
          else
          {
            this.items.push({
              title: 'Free Period',
              note: 'Not Available',
              icon: this.icons[Math.floor(Math.random() * this.icons.length)],
              srno: periodname,
              sectionname: ''
            });
          }
          //alert(data['periodid']);
        }
        this.loader.dismiss();
  		}else{
        this.loader.dismiss();
  		}
  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismiss();
  	  });
    });
  }

}
