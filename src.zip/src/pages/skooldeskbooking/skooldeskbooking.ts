import { Component } from '@angular/core';
import { NavController, NavParams, AlertController, LoadingController } from 'ionic-angular';
import { ToastController } from 'ionic-angular/components/toast/toast-controller';
import { global } from '../../app/global';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
/**
 * Generated class for the SkooldeskbookingPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-skooldeskbooking',
  templateUrl: 'skooldeskbooking.html',
})
export class SkooldeskbookingPage {

  postData: any;
  constructor(public navCtrl: NavController, public navParams: NavParams, public toastCtrl: ToastController, public alertCtrl: AlertController, public myLoadingCtrl: LoadingController, public authservice: AuthServiceProvider) {
    this.postData = {schoolid: window.localStorage.getItem('schoolid'), mobileno: '', emailid: window.localStorage.getItem('useremail')};
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SkooldeskbookingPage');
  }

  showMessage(option)
  {
    let message = "";

    if (option == 1)
      message = "This option will show teacher's daily time table.";
    else if (option == 2)
      message = "Using this option, teacher will be able to take student attendance.Parent will get notification on mobile application";
    else if (option == 3)
      message = "Using this option, teacher will be able to take student bus attendance.Parent will get notification on mobile application";
    else if (option == 4)
      message = "Using this option, teacher will be able to generate report card.";
    else if (option == 5)
      message = "This is the parent teacher communication place where all parent query will be displayed";
    else if (option == 6)
      message = "Using this option, school can create fee alerts which would be directly visible on parent mobile application";
    else if (option == 7)
      message = "Here you can broadcast any notice to parents, which would be publish quickly to all parents application.";
    else if (option == 8)
      message = "Using this option, teacher will be able to create his/her diary.";
    else if (option == 9)
    {
      message = "This is student's handbook where teacher will be able to give daily assignment.";
    }

    if (message != "")  
    {
      let toast = this.toastCtrl.create({
        message: message,
        //duration: 3000,
        position: "center",
        showCloseButton: true,
        closeButtonText: "Ok"
      });
      toast.present();
    }
  }

  bookTrial()
  {
    let prompt = this.alertCtrl.create({
      title: 'Confirm mobile no.',
      message: "Please enter your mobile no.",
      inputs: [
        {
          name: 'mobileno',
          placeholder: 'Mobile no.',
          type: "number"
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            return;
          }
        },
        {
          text: 'Ok',
          handler: adata => {    
            
            if (adata.mobileno == "")
            {
              let toast = this.toastCtrl.create({
                message: "Please enter the mobile no.",
                duration: 3000
              });
              toast.present();
              return false;
            }

            let myLoader = this.myLoadingCtrl.create({
              content : "Please wait.."
            });
            
            myLoader.present().then(() => {

              this.postData.mobileno = adata.mobileno;
              this.authservice.postData(this.postData, 'booktrial/otp').then((result) => {
                if (result['response'] == 1)
                {

                  myLoader.dismissAll();

                  let OTP = result['otp'];

                  let promptOTP = this.alertCtrl.create({
                    title: 'Mobile Verification',
                    message: "Please enter OTP received on given mobile no.",
                    inputs: [
                      {
                        name: 'txtotp',
                        placeholder: 'Enter OTP',
                        type: "number"
                      },
                    ],
                    buttons: [
                      {
                        text: 'Cancel',
                        handler: data => {
                          return;
                        }
                      },
                      {
                        text: 'Ok',
                        handler: odata => { 

                          if (odata.txtotp == "")
                          {
                            let toast = this.toastCtrl.create({
                              message: "Please enter the OTP",
                              duration: 3000
                            });
                            toast.present();
                            return false;
                          }
                          if (odata.txtotp != OTP)
                          {
                            let toast = this.toastCtrl.create({
                              message: "Please enter the correct OTP",
                              duration: 3000
                            });
                            toast.present();
                            return false;
                          }

                          let myOLoader = this.myLoadingCtrl.create({
                            content : "Please wait.."
                          });
                          
                          myOLoader.present().then(() => {

                            this.authservice.postData(this.postData, 'booktrial/submit').then((resultFT) => {

                              myOLoader.dismissAll();

                              if (resultFT['response'] == 1)
                              {
                                let alert = this.alertCtrl.create({
                                  title: 'Successful!',
                                  subTitle: 'Your Free Trial booking request has been submitted successfully!Our executive will contact you with in 24 hours.',
                                  buttons: [
                                    {
                                      text: 'OK',
                                      handler: sucdata => {
                                        this.navCtrl.pop({animate:true,animation:'transition',duration:600,direction:'back'});
                                      }
                                    }
                                  ]
                                });
                                alert.present();

                              }
                              else
                              {
                                let toast = this.toastCtrl.create({
                                  message: "Sorry! unable to process your request",
                                  duration: 3000
                                });
                                toast.present();
                              }

                            });

                          }, (err) => {
                            myOLoader.dismissAll();
                            let toast = this.toastCtrl.create({
                              message: err,
                              duration: 3000
                            });
                            toast.present();
                          });

                        }
                      }
                    ]
                  });
                  promptOTP.present();


                }
              },(err) => {
                let toast = this.toastCtrl.create({
                  message: err,
                  duration: 3000
                });
                toast.present();
                myLoader.dismissAll();
              });  

            }, errL => {
              myLoader.dismissAll();
              let toast = this.toastCtrl.create({
                message: "Error:"+errL,
                duration: 3000
              });
              toast.present();
            });                


          }
        }
      ]
    });
    prompt.present();
  }

}
