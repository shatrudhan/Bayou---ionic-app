
import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, ToastController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';

import { MysubjectsPage } from '../mysubjects/mysubjects';

@Component({
  selector: 'page-teacher-class-section',
  templateUrl: 'teacher-class-section.html',
})
export class TeacherClassSectionPage {

  selectedItem: any;
  icons: string[];
  items: Array<{classname: string, sectionname: string}>;
  myLoadingControl: any;
  loader: any;
  responseData: any;
  postData: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public loadingCtrl: LoadingController, public authservice: AuthServiceProvider, public toastCtrl: ToastController) {
    // If we navigated to this page, we will have an item available as a nav param
    this.selectedItem = navParams.get('item');
    this.loader
    this.myLoadingControl = loadingCtrl;

    this.items = [];
    this.postData = {teacherid: window.localStorage.getItem('teacherid'), schoolid: window.localStorage.getItem('schoolid')};
    this.loadClasses();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MyclassPage');
  }

  loadClasses(){
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {
      this.authservice.postData(this.postData, 'allottedclasses').then((result)=>{
  		this.responseData = result;
  		console.log(this.responseData);
  		if(this.responseData['response'] == 1){
        this.items = this.responseData['classinfo'];
        this.loader.dismiss();
  		}else{
        this.loader.dismiss();
  		}
  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismiss();
  	  });
    });
  }

  itemTapped(event, classid, sectionid, classname, sectionname) {
    // That's right, we're pushing to ourselves!
    this.navCtrl.push(MysubjectsPage, {
      schoolid: localStorage.getItem('schoolid'),
      classid: classid,
      sectionid: sectionid,
      classname: classname,
      sectionname: sectionname,
    });
  }

}
