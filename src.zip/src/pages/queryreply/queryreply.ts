import { Component } from '@angular/core';
import { NavController, NavParams, ViewController, LoadingController, AlertController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { QuerydetailPage } from '../querydetail/querydetail';
/**
 * Generated class for the QueryreplyPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-queryreply',
  templateUrl: 'queryreply.html',
})
export class QueryreplyPage {

  selectedItem: any;
  icons: string[];
  items: Array<{classname: string, sectionname: string}>;
  myLoadingControl: any;
  loader: any;
  responseData: any;
  postData: any;
  submitPostData: any;
  qDetail: any;
  public queryForm: FormGroup;

  txtmessage: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public viewCtrl: ViewController, public loadingCtrl: LoadingController, public authservice: AuthServiceProvider, public alertCtrl: AlertController, public formBuilder: FormBuilder) {
    this.loader
    this.myLoadingControl = loadingCtrl;
    this.qDetail = navParams.get('myObj');
    this.items = [];
    //this.postData = {teacherid: localStorage.getItem('useremail'), schoolid: localStorage.getItem('schoolid'), messageid: navParams.get('messageid')};
    this.submitPostData = {teacherid: localStorage.getItem('useremail'), schoolid: localStorage.getItem('schoolid'), classid: 0, sectionid: 0, studentid: 0, pemailid: '', number: 0, messageid: navParams.get('messageid'), ishead: 0, msgby: 'T', message: ''};
    //this.loadMessages();
    this.queryForm = this.formBuilder.group({
      txtmessage: [null, [Validators.required]]
    });
    
    this.txtmessage = this.queryForm.controls['txtmessage'];

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad QueryreplyPage');
  }

  dismiss() {
    this.viewCtrl.dismiss();
  }

  submitReply()
  {

    this.queryForm.controls['txtmessage'].setErrors({"hasError": true});

    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {
      this.authservice.postData(this.submitPostData, 'parents/submitreply').then((result)=>{
  		this.responseData = result;
  		console.log(this.responseData);
  		if(this.responseData['response'] == 1){
        let doAlert = this.alertCtrl.create({
          title: 'Successful!',
          message: this.responseData['message'],
          buttons: [
                    {
                      text: 'Ok',
                      handler: () => {
                        this.qDetail.loadMessages();
                        this.navCtrl.pop();
                        //this.dismiss();
                      }
                    }
                  ]
        });
        this.loader.dismiss();
        doAlert.onDidDismiss(() => {
          //this.navCtrl.pop();
        });
        doAlert.present();
  		}else{
        let doAlert = this.alertCtrl.create({
          title: 'Sorry!',
          message: this.responseData['message'],
          buttons: ['OK']
        });
        doAlert.present();
        this.loader.dismiss();
  		}
  	  },(err)=> {
  		    //alert('failled '+err);
          let doAlert = this.alertCtrl.create({
            title: 'Successful!',
            message: err,
            buttons: ['OK']
          });
          doAlert.present();
          this.loader.dismiss();
  	  });
    });
  }

}
