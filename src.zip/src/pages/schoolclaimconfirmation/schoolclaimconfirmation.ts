import { SigninPage } from './../signin/signin';
import { AlertController } from 'ionic-angular/components/alert/alert-controller';
import { AuthServiceProvider } from './../../providers/auth-service/auth-service';
import { LoadingController } from 'ionic-angular/components/loading/loading-controller';
import { Component } from '@angular/core';
import { NavController, NavParams, ToastController } from 'ionic-angular';

/**
 * Generated class for the SchoolclaimconfirmationPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-schoolclaimconfirmation',
  templateUrl: 'schoolclaimconfirmation.html',
})
export class SchoolclaimconfirmationPage {

  postData: any;
  responseData: any;
  schoolName: string;
  address: string;
  statecity: string;
  pincode: string;
  contactno: string;
  emailid: string;
  website: string;
  schooltype: string;
  category: string;
  loader: any;
  logo: any;
  profileUrl: string;

  constructor(public navCtrl: NavController, public navParams: NavParams, public myLoadingCtrl: LoadingController, public authservice: AuthServiceProvider, public toastCtrl: ToastController, public alertCtrl: AlertController) {
    this.postData = {emailid: navParams.get('emailid'), password: navParams.get('password'), mobileno: navParams.get('mobileno'), confirmpassword: navParams.get('password'), name: navParams.get('name'), usertype: navParams.get('usertype'), title: navParams.get('title'), updates: false, offers: false, schoolid: navParams.get('schoolid'), schoolname: navParams.get('schoolname'), state: navParams.get('state'), city: navParams.get('city'), schoolwebsite: navParams.get('schoolwebsite')};
    this.getInformation();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SchoolclaimconfirmationPage');
  }

  getInformation(){
    
    let loader = this.myLoadingCtrl.create({
      content : "Please wait.."
    });

    loader.present().then(() => {
      
      this.authservice.postData(this.postData, 'getinformation').then((result)=>{
        
        this.responseData = result;
        console.log(this.responseData);
        if(this.responseData['response'] == 1){

          this.schoolName = this.responseData['basic'][0]['schoolname'];
          this.address = this.responseData['basic'][0]['address'];

          if (this.responseData['basic'][0]['localityarea'] != "")
            this.address = this.address + ', ' + this.responseData['basic'][0]['localityarea'];
          
          this.address = this.address;
          this.statecity = this.responseData['basic'][0]['city'] + ' (' + this.responseData['basic'][0]['state'] + ')-' + this.responseData['basic'][0]['pincode'];

          this.contactno = this.responseData['basic'][0]['contactno'];
          this.emailid = this.responseData['basic'][0]['emailid'];
          this.website = this.responseData['basic'][0]['websitename'];
          this.schooltype = this.responseData['basic'][0]['schooltype'];
          this.category = this.responseData['basic'][0]['category'];

          this.logo = this.responseData['basic'][0]['logopath'];

        } 
        else
        {
          let toast = this.toastCtrl.create({
            message: "Sorry! unable to process your request",
            duration: 3000
          });
          toast.present();
        }

        loader.dismiss();       

      },(err)=> {
          //alert('failled '+err);
          let toast = this.toastCtrl.create({
              message: err,
              duration: 3000
            });
          toast.present();
          loader.dismiss();
      });

      //this.loader.dismiss();
      
    });
    
  }

  signUp(val)
  {
      if (val == 1)
      {
        let loader = this.myLoadingCtrl.create({
          content : "Please wait.."
        });
    
        loader.present().then(() => {
          
          this.authservice.postData(this.postData, 'schoolSignUp').then((result)=>{
            
            this.responseData = result;
            console.log(this.responseData);
            if(this.responseData['response'] == 1){
    
              let alert = this.alertCtrl.create({
                title: 'Successful!',
                subTitle: this.responseData['msg'],
                buttons: [
                  {
                    text: 'OK',
                    handler: sucdata => {
                      //this.navCtrl.pop({animate:true,animation:'transition',duration:600,direction:'back'});
                      window.localStorage.setItem('useremail',this.postData.emailid);
                      window.localStorage.setItem('teacherid', "0");
                      window.localStorage.setItem('schoolid', this.postData.schoolid);
                      window.localStorage.setItem('teachername', this.postData.name);
                      window.localStorage.setItem('busincharge', '');
                      window.localStorage.setItem('busid', "0");
                      window.localStorage.setItem('schoolname', this.postData.schoolname);
                      window.localStorage.setItem('isdriver', '');
                      window.localStorage.setItem('mybusid', "0");
                      window.localStorage.setItem('schoolurl', this.responseData['profileurl']);
                      window.localStorage.setItem('isadmin', "1");
                      window.localStorage.setItem('isactive', "0");

                      this.navCtrl.setRoot(SigninPage, {}, {animate:true,animation:'transition',duration:300,direction:'forward'});

                    }
                  }
                ]
              });
              alert.present();
    
            } 
            else
            {
              let toast = this.toastCtrl.create({
                message: this.responseData['msg'],
                duration: 3000
              });
              toast.present();
            }
    
            loader.dismiss();       
    
          },(err)=> {
              //alert('failled '+err);
              let toast = this.toastCtrl.create({
                  message: err,
                  duration: 3000
                });
              toast.present();
              loader.dismiss();
          });
    
          //this.loader.dismiss();
          
        });
      }
      else if (val == 2)
      {
        let alert = this.alertCtrl.create({
          title: 'Cancel!',
          subTitle: "Are you sure? you want to cancel",
          buttons: [
            {
              text: 'Yes',
              handler: sucdata => {
                this.navCtrl.popToRoot();
              }
            },
            {
              text: 'No',
              handler: sucdata => {
                
              }
            }
          ]
        });
        alert.present();
      }
  }

}
