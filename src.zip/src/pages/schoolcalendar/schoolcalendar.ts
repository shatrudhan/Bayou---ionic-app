import { DatePipe } from '@angular/common';
import { CalendarComponent } from 'ionic2-calendar/calendar';
import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, LoadingController, ToastController, AlertController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';

/**
 * Generated class for the SchoolcalendarPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-schoolcalendar',
  templateUrl: 'schoolcalendar.html',
})
export class SchoolcalendarPage {

  @ViewChild(CalendarComponent) myCalendar: CalendarComponent;

  eventSource: any;
  viewTitle: string;
  selectedDay: any;
  calendar: any;
  months: string[];
  loader: any;
  postData: any;
  responseData: any;
  currentDate: any;
  startTime: any;
  endTime: any;
  studentname: any;
  schoolName: any;
  isOnLoad: number;

  constructor(public navCtrl: NavController, public navParams: NavParams, public myLoadingControl: LoadingController, public authservice: AuthServiceProvider, public toastCtrl: ToastController, public alertCtrl: AlertController, public datepipe: DatePipe) {
    this.isOnLoad = 0;
    this.schoolName = window.localStorage.getItem('schoolname');
    this.loader = myLoadingControl;
    this.postData = {schoolid: window.localStorage.getItem('schoolid'), month: 0, year: 0};
    this.eventSource = [];
    this.responseData = [];
    this.months = ['January', 'February', 'March'];
    this.viewTitle = "Feb";
    this.selectedDay = new Date();
    this.calendar = {
      dateFormatter: {
          formatMonthViewDay: function(date:Date) {
              return date.getDate().toString();
          },
          formatMonthViewTitle: function(date:Date) {
              let monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'Octomber', 'November', 'December'];
              this.selectedDay = date;
              return monthNames[date.getMonth()] + '-' + date.getFullYear();
          },
          formatWeekViewDayHeader: function(date:Date) {
              return 'testWDH';
          },
          formatWeekViewTitle: function(date:Date) {
              return this.months[1];
          },
          formatWeekViewHourColumn: function(date:Date) {
              return 'testWH';
          },
          formatDayViewHourColumn: function(date:Date) {
              return 'testDH';
          },
          formatDayViewTitle: function(date:Date) {
              return 'testDT';
          }
      },
      mode: 'month',
      currentDate: new Date(),
      noEventsLabel: '',
      showEventDetail: false
    }
  }

  loadAttendance(){
    //let calDate = this.calendar.currentDate;
    //this.postData = {studentid: this.navParams.get('studentid'), month: this.selectedDay.getMonth()+1, year: this.selectedDay.getFullYear()};
    this.postData.month = this.selectedDay.getMonth()+1;
    this.postData.year = this.selectedDay.getFullYear();
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.eventSource = [];

    /*let toast = this.toastCtrl.create({
        message: this.calendar.currentDate.getMonth() + '',
        duration: 3000
    });
    toast.present();*/
    let colors: string[] = ['primary', 'danger'];

    this.loader.present().then(() => {
      this.authservice.postData(this.postData, 'calendar/get').then((result)=>{
      this.responseData = result;
      console.log(this.responseData);
      if(this.responseData['response'] == 1)
      {
            try {
                let newDate = new Date();
                let eventType = Math.floor(Math.random() * 2);
                let startDay = Math.floor(Math.random() * 90) - 45;
                let endDay = Math.floor(Math.random() * 2) + startDay;
                for(let data of this.responseData['events'])
                {
                    newDate = new Date(data['eventdate']);
                    //let startMinute = Math.floor(Math.random() * 24 * 60);
                    //let endMinute = Math.floor(Math.random() * 180) + startMinute;
                    let startTime = new Date(Date.UTC(newDate.getFullYear(), newDate.getMonth(), newDate.getDate()));
                    let endTime = new Date(Date.UTC(newDate.getFullYear(), newDate.getMonth(), newDate.getDate()+1));
                    this.eventSource.push({
                        title: data['eventtitle'],
                        startTime: startTime,
                        endTime: endTime,
                        allDay: true,
                        color: "colors[Math.floor(Math.random()*colors.length)]",
                        eventid: data['eventid']
                    });
                    console.log(newDate);
                    //this.calendar.loadEvents();
                }
                /* let toast = this.toastCtrl.create({
                    message: this.eventSource.length + '',
                    duration: 3000
                });
                toast.present(); */
                //this.calendar.currentDate = newDate;
                this.loader.dismiss();
            } catch (error) {
                let toast = this.toastCtrl.create({
                    message: error + '',
                    duration: 3000
                });
                toast.present();
                this.loader.dismiss();
            }            
            
      }else{
            this.loader.dismiss();
      }

        this.myCalendar.loadEvents();
        this.isOnLoad = 1;

      },(err)=> {
          //alert('failled '+err);
          let toast = this.toastCtrl.create({
              message: err,
              duration: 3000
            });
          toast.present();
          this.loader.dismiss();
      });

        
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AttendanceviewPage');
  }

  onRangeChanged(sTime, eTime){
    this.selectedDay = this.myCalendar.currentDate;
    /*let toast = this.toastCtrl.create({
        message: this.selectedDay + '',
        duration: 3000
    });
    toast.present();*/
    //this.calendar.currentDate = this.selectedDay;

    this.loadAttendance();

  }

  onEventSelected(event)
  {

  }

  onViewTitleChanged(title){
    this.viewTitle = title;    

  }

  onTimeSelected(event){
    
  }

  addEvent(date)
  {

    let event_date = this.datepipe.transform(date.date, "dd/MM/yyyy");
    const alertFailure = this.alertCtrl.create({
      title: 'Add Event',
      subTitle: 'Create school event on '+event_date,
      inputs: [
        {
          name: 'title',
          placeholder: 'Title'
        }
      ],
      buttons: [
        {
          text: 'Submit',
          handler: adata => {

            if (adata.title == "")
            {
              let toast = this.toastCtrl.create({
                message: "Please enter the event title",
                duration: 3000
              });
              toast.present();
              return false;
            }

            let myLoader = this.myLoadingControl.create({
              content : "Please wait.."
            });
            
            myLoader.present().then(() => {

              let submitPostData = {'schoolid': window.localStorage.getItem('schoolid'), 'eventtitle': adata.title, 'eventdate': this.datepipe.transform(date.date, "yyyy-MM-dd")};

              this.authservice.postData(submitPostData, 'calendar/add').then((resulta)=>{
                
                //this.responseData = result;
                //console.log(this.responseData);
                if(resulta['response'] == 1){

                  myLoader.dismissAll();

                  let alert = this.alertCtrl.create({
                    title: 'Successful!',
                    subTitle: 'Event has been updated successfully in school calendar!',
                    buttons: [
                      {
                        text: 'Ok',
                        handler: () => {                    
                          this.loadAttendance();
                        }
                      }
                    ]
                  });

                  alert.present();

                }
                else
                {
                  myLoader.dismissAll();
                }          
      
              },(err)=> {
                  //alert('failled '+err);
                  let toast = this.toastCtrl.create({
                      message: err,
                      duration: 3000
                    });
                  toast.present();
                  myLoader.dismissAll();
              });

            }, err => {
              myLoader.dismissAll();
              let toast = this.toastCtrl.create({
                message: "Error:"+err,
                duration: 3000
              });
              toast.present();
            });

          }
        },
        {
          text: 'Cancel',
          handler: data => {
            
          }
        }
      ]
    });
    alertFailure.present();
  }

  onCurrentDateChanged(event){
    //this.myCalendar.loadEvents();
    //this.loadAttendance();
  }

  deleteEvent(eventid)
  {
    let confirm = this.alertCtrl.create({
      title: 'Confirmation',
      message: 'Are you sure? you want to remove this event from calendar',
      buttons: [
        {
          text: 'Yes',
          handler: () => {
            
            this.loader = this.myLoadingControl.create({
              content : "Please wait.."
            });

            this.loader.present().then(() => {
              
              let eventPostData = {eventid: eventid, schoolid: window.localStorage.getItem('schoolid')};
              //this.postData.docid = docId;
              this.authservice.postData(eventPostData, 'calendar/delete').then((result)=>{
                
                if(result['response'] == 1){
                  
                  this.loader.dismissAll();
                  
                  let alert = this.alertCtrl.create({
                    title: 'Successful!',
                    subTitle: 'Selected event has been removed successfully from calendar.',
                    buttons: [{
                      text: 'OK',
                      handler: () => {
                        this.loadAttendance();
                      }
                    }]
                  });
                  alert.present();                  

                }
                else
                {
                  this.loader.dismissAll();
                  let toast = this.toastCtrl.create({
                      message: "Sorry! we are unable to process your request",
                      duration: 3000
                    });
                  toast.present();
                  //this.loader.dismiss();
                }

                

              },(err)=> {
                  //alert('failled '+err);
                  let toast = this.toastCtrl.create({
                      message: err,
                      duration: 3000
                    });
                  toast.present();
                  this.loader.dismiss();
              });
              
            });

          }
        },
        {
          text: 'No',
          handler: () => {
            //console.log('Agree clicked');
          }
        }
      ]
    });
    confirm.present();
  }

}
