import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, ToastController, AlertController, ModalController } from 'ionic-angular';
import { QuerydetailPage } from '../querydetail/querydetail';

import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { global } from '../../app/global';


//  class 1 started from here //
@Component({
  selector: 'page-query',
  templateUrl: 'query.html',
})

export class QueryPage {

schoolid:any; classid:number; sectionid:number; studentid:number;
queries:any;timeago:any;
loader: any;
myLoadingControl: any;
responseData: any;

  constructor(
              public navCtrl: NavController,
              public navParams: NavParams,
              public toastCtrl: ToastController,
              public authservice: AuthServiceProvider,
              public loadingCtrl: LoadingController,
              public alertCtrl: AlertController,
              public modalCtrl: ModalController
             )
  {

    this.schoolid = localStorage.getItem('schoolid');
    this.myLoadingControl = loadingCtrl;

    this.loadQueries();

  }

  loadQueries(){
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {
      this.authservice.postData({'email': localStorage.getItem('useremail'), 'schoolid':this.schoolid}, 'getAllParentQueries').then((result)=>{
  		this.responseData = result;
  		console.log(this.responseData);
  		if(this.responseData['response'] == 1){
        this.queries = this.responseData['queries'];
        this.loader.dismiss();
  		}else{
        this.loader.dismiss();
  		}
  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismiss();
  	  });
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad QueryPage');
  }

  itemTapped(messageId){
    this.navCtrl.push(QuerydetailPage, {messageid: messageId});
  }

};
