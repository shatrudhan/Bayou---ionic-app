import { SigninPage } from './../signin/signin';
import { LoadingController } from 'ionic-angular/components/loading/loading-controller';
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { AlertController } from 'ionic-angular/components/alert/alert-controller';
import { ToastController } from 'ionic-angular/components/toast/toast-controller';
import { ViewController } from 'ionic-angular/navigation/view-controller';


@Component({
  selector: 'page-forgotpassword',
  templateUrl: 'forgotpassword.html',
})
export class ForgotpasswordPage {

  loader: any;
  postData: {usertype: '', userid: ''};
  // usertype: string;
  // userid: string;

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams, 
    public myLoadingControl: LoadingController, 
    public authservice: AuthServiceProvider, 
    public alertCtrl: AlertController, 
    public toastCtrl: ToastController,
    public viewCtrl: ViewController,     
  ) 
  {
    this.postData = {usertype: '', userid: ''};
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ForgotpasswordPage');
  }

  forgotPassword()
  {
      this.loader = this.myLoadingControl.create({
        content : "Please wait.."
      });
      
      if (this.postData.usertype == "")
      {
        let toast = this.toastCtrl.create({
          message: "Please select user type",
          duration: 3000
        });
        toast.present();
        this.loader.dismiss();
        return false;
      }
      if (this.postData.userid == "")
      {
        let toast = this.toastCtrl.create({
          message: "Please enter login id",
          duration: 3000
        });
        toast.present();
        this.loader.dismiss();
        return false;
      }

      this.loader.present().then(() => {

        // this.postData.usertype = this.usertype;
        // this.postData.userid = this.userid;
  
        this.authservice.postData(this.postData, "forgotloginpassword").then((result)=>{
          //this.responseData = result;
          //console.log(this.responseData);
          if(result['response'] == 1){
            let alert = this.alertCtrl.create({
              title: 'Successfully Sent!',
              subTitle: result['msg'],
              buttons: [
                {
                  text: 'Ok',
                  handler: () => {                
                    this.loader.dismiss();
                    this.navCtrl.push(SigninPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
                  }
                }
              ]
            });
            alert.present();
            this.loader.dismiss();
          }else{
            let toast = this.toastCtrl.create({
              message: result['msg'],
              duration: 3000
            });
            toast.present();
            this.loader.dismiss();
          }
        },(err)=> {
            //alert('failled '+err);
            let toast = this.toastCtrl.create({
                message: err,
                duration: 3000
              });
            toast.present();
            this.loader.dismiss();
        });

      });
    
  }

  ModalDismiss()
  {
    this.viewCtrl.dismiss();
  }

}
