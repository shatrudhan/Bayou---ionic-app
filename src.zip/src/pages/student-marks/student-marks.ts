import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, ToastController, AlertController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';

@Component({
  selector: 'page-student-marks',
  templateUrl: 'student-marks.html',
})
export class StudentMarksPage {
 
  studentArray: Array<{ studentname: string, rollno: number, studentid: number, classid: number, schoolid: number, configid: number, totalmarks: number, subjectid: number, obtainMarks: number, enable_disable: any }>;
  addMarksResponse: {};
  submitPostData: any;

  EnabledOrDisabled: boolean;
  postData4: { 'schoolid': any; 'classid': any; 'sectionid': any; 'headtermid': any; 'termid': any; 'examid': any; 'subjectid': any};
  examId: any;
  termId: any;
  headTermId: any;
  allExams: any;
  postData3: { 'schoolid': any; };
  allTerms: any;
  postData2: any;
  postData1: { 'schoolid': any; };
  allHeadTerms: any;

  configid: any; totalmarks: any;
  schoolid: any; classid: any; sectionid: any; subjectid: any;

  items: Array<{studentname: string, rollno: number, sid: number, reason: string}>;
  myLoadingControl: any;
  loader: any;
  responseData: any;
  postData: any;

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams, 
    public loadingCtrl: LoadingController, 
    public authservice: AuthServiceProvider, 
    public toastCtrl: ToastController,
    public alertCtrl: AlertController
  )
  {

    this.schoolid = this.navParams.get('schoolid');
    this.classid = this.navParams.get('classid');
    this.sectionid = this.navParams.get('sectionid');
    this.subjectid = this.navParams.get('subjectid');
   
    this.myLoadingControl = loadingCtrl;
    this.items = [];
    this.postData = {classid: navParams.get('classid'), schoolid: window.localStorage.getItem('schoolid'), sectionid: navParams.get('sectionid')};
    this.getStudents();

    this.headTerms();
    this.exam();
    this.EnabledOrDisabled = true;
    this.studentArray = [];
    this.submitPostData = {students: ''};
    this.submitPostData.students = [];

  }

  ionViewDidLoad() 
  {
    console.log('ionViewDidLoad StudentMarksPage');
  }

  // GETTING ALL HEAD-TERM
  headTerms()
  {
    this.postData1 = {'schoolid':this.schoolid}
    this.authservice.postData(this.postData1,'getAllHeadTerms').then((result)=>{
      if(result['response'] == 1){
        this.allHeadTerms = result['headterms'];
      }else{
        let toast = this.toastCtrl.create({ message: 'Please update head term first !', 'cssClass':'toastText', duration: 5000 });
        toast.present();
      }
      },(err)=> {
          let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 3000 });
          toast.present();
      });
  }

  // GETTING ALL TERM RELATED TO THE HEAD
  terms(headtermid)
  {
    this.headTermId = headtermid;
    this.CheckReportcardConfig();
    this.postData2 = {'schoolid':this.schoolid, 'htId':headtermid}
    this.authservice.postData(this.postData2,'getAllTermsByHeadTerm').then((result)=>{
      if(result['response'] == 1){
        this.allTerms = result['terms'];
      }else{
        this.allTerms = result['terms'];
        let toast = this.toastCtrl.create({ message: 'Please update term first !', 'cssClass':'toastText', duration: 5000 });
        toast.present();
      }
      },(err)=> {
          let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 3000 });
          toast.present();
      });
  }

  // GETTING ALL EXAMS
  exam()
  {
    this.postData3 = {'schoolid':this.schoolid}
    this.authservice.postData(this.postData3,'getAllExam').then((result)=>{
      if(result['response'] == 1){
        this.allExams = result['exams'];
      }else{
        let toast = this.toastCtrl.create({ message: 'Please update exam first !', 'cssClass':'toastText', duration: 5000 });
        toast.present();
      }
      },(err)=> {
          let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 3000 });
          toast.present();
      });
  }

  // ON CHANGE TERM
  OnChangeTerms(termid)
  {
    this.termId = termid;
    this.CheckReportcardConfig();
  }

  // ON CHANGE EXAM
  OnChangeExam(examid)
  {
    this.examId = examid;
    this.CheckReportcardConfig();
  }

  // CHECKING THAT REPORT CARD CONFIG EXIST OR NOT
  CheckReportcardConfig()
  {
    if((this.headTermId != undefined) && (this.termId != undefined) && (this.examId != undefined))
    {
      this.postData4 = { 'schoolid':this.schoolid, 'classid':this.classid, 'sectionid':this.sectionid, 'headtermid':this.headTermId, 'termid':this.termId, 'examid':this.examId, 'subjectid':this.subjectid  }
      this.authservice.postData(this.postData4, 'getReportcardConfigExistance').then((result)=>{
        if(result['response'] == 1){
          let confidtotalmarks = result['configidWITHtotalmarks'];
          let ct = confidtotalmarks.split(',');
          this.configid = ct[0];
          this.totalmarks = ct[1];
          this.EnabledOrDisabled = false;
          this.getObtainMarks(this.configid,this.subjectid);
        }else if(result['response'] == 0){
          this.studentArray = [];
          this.getStudents();
          this.EnabledOrDisabled = true;
          let toast = this.toastCtrl.create({ message: 'Update report card config first !', 'cssClass':'toastText', duration: 3000 });
          toast.present();
        }else{
          this.EnabledOrDisabled = true;
          let toast = this.toastCtrl.create({ message: 'Sorry ! something went wrong.', 'cssClass':'toastText', duration: 3000 });
          toast.present();
        }
        },(err)=> {
            let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 3000 });
            toast.present();
        });
    }
  }
  
  // GETTING STUDENT'S OBTAIN MARKS ACCORDING TO THE CONFIG ID ONLY
  getObtainMarks(configid,subjectid)
  {
    this.loader = this.myLoadingControl.create({
      content : "Loading.."
    });

    this.loader.present().then(() => {
      this.authservice.postData({'configid':configid, 'subjectid':subjectid}, 'getObtainMarks').then((result)=>{
        if(result['response'] == 1){
          this.studentArray = [];
          for(let val of result['obMarks'])
          {
            this.studentArray.push({
              rollno: val['rollno'],
              studentname: val['studentname'], 
              obtainMarks: val['obtainmark'],           
              studentid: val['stdid'],
              classid: val['classid'], 
              schoolid: val['schoolid'], 
              configid: val['configid'], 
              totalmarks: val['totalmark'], 
              subjectid: val['subid'],
              enable_disable: false
            });
          }
          //this.EnabledOrDisabled = false;
          this.loader.dismiss();
        }else{
          this.loader.dismiss();
          this.studentArray = [];
          this.getStudents();
          //this.EnabledOrDisabled = true;
        }
      },(err)=> {
        let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 3000 });
        toast.present();
        this.loader.dismiss();
      });
    });
  }

  getStudents()
  {
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {
      this.authservice.postData(this.postData, 'getstudents').then((result)=>{
      this.responseData = result;
      if(this.responseData['response'] == 1){
        this.items = this.responseData['studentinfo'];
        for(let val of this.responseData['studentinfo'])
        {
          this.studentArray.push({
            rollno: val['rollno'],
            studentname: val['studentname'], 
            obtainMarks: 0,           
            studentid: val['sid'],
            classid:this.classid, 
            schoolid: this.schoolid, 
            configid: this.configid, 
            totalmarks: this.totalmarks, 
            subjectid: this.subjectid,
            enable_disable: false
          });
        }
        this.loader.dismiss();
      }else{
        this.EnabledOrDisabled = true;
        this.loader.dismiss();
      }
      },(err)=> {
          let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 3000 });
          toast.present();
          this.loader.dismiss();
      });
    });
  }
    
  absentOrNot(event,stid)
  {
    if (!event.checked){
      let index = 0;
      for(let i=0;i<this.studentArray.length;i++) {
        if (this.studentArray[i].studentid == stid){
          index = i; break;
        }
      }
      this.studentArray[index].obtainMarks = 0;
      this.studentArray[index].enable_disable = false;
    }else{
      let index = 0;
      for(let i=0;i<this.studentArray.length;i++){
        if (this.studentArray[i].studentid == stid){
          index = i; break;
        }
      }
      this.studentArray[index].obtainMarks = 0;
      this.studentArray[index].enable_disable = true;
    }
  }

  addStudentMarks()
  {
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    for(let i=0;i<this.studentArray.length;i++){
     this.studentArray[i].configid = this.configid;
     this.studentArray[i].totalmarks = this.totalmarks;
    }   
    this.submitPostData.students = this.studentArray;
    
    this.loader.present().then(() => {
      this.authservice.postData(this.submitPostData, 'submitObtainMarks').then((result)=>{
        this.addMarksResponse = result;
        if(this.addMarksResponse['response'] == 1){
          let toast = this.toastCtrl.create({ message: "Marks added successfully !", 'cssClass':'toastText', duration: 3000 });
          toast.present();
          this.loader.dismiss();
        }else{
          let toast = this.toastCtrl.create({ message: "Sorry! something went wrong.", 'cssClass':'toastText', duration: 3000 });
          toast.present();
          this.loader.dismiss();
        }
        },(err)=> {
            let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText',  duration: 3000 });
            toast.present();
            this.loader.dismiss();
        });
    });
  }
    




}
