import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, ToastController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { StudentMarksPage } from '../student-marks/student-marks';

 
@Component({
  selector: 'page-mysubjects',
  templateUrl: 'mysubjects.html',
})
export class MysubjectsPage {
  
  schoolid: any; classid: any; sectionid: any; classname: any; sectionname: any;
  subjects: any;
  postData: { 'schoolid': any; 'classid': any; 'sectionid': any; };
  myLoadingControl: any; loader: any;

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams, 
    public loadingCtrl: LoadingController, 
    public authservice: AuthServiceProvider, 
    public toastCtrl: ToastController
  )
  {

    this.schoolid = this.navParams.get('schoolid');
    this.classid = this.navParams.get('classid');
    this.sectionid = this.navParams.get('sectionid');
    this.classname = this.navParams.get('classname');
    this.sectionname = this.navParams.get('sectionname');
    
    this.myLoadingControl = loadingCtrl;
    this.allSubjects();
    
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MysubjectsPage');
  }

  allSubjects()
  {
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {
      this.postData = {'schoolid':this.schoolid, 'classid':this.classid, 'sectionid':this.sectionid}
      this.authservice.postData(this.postData, 'getTeachersAllSubjects').then((result)=>{
  		if(result['response'] == 1){
        this.subjects = result['subjects'];
        this.loader.dismiss();
  		}else{
        let toast = this.toastCtrl.create({ message: 'Sorry ! unable to find any subject.', duration: 3000 });
        toast.present();
        this.loader.dismiss();
  		}
  	  },(err)=> {
          let toast = this.toastCtrl.create({ message: err, duration: 3000 });
    			toast.present();
          this.loader.dismiss();
  	  });
    });
  }

  goToStudentlist(subjectid)
  {
    this.navCtrl.push(StudentMarksPage, {
      schoolid: this.schoolid,
      classid: this.classid,
      sectionid: this.sectionid,
      subjectid: subjectid,
    });
  }



}
