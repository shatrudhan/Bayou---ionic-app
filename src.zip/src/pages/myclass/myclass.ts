import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, ToastController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';

import { AttendancePage } from '../attendance/attendance';
/**
 * Generated class for the MyclassPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-myclass',
  templateUrl: 'myclass.html',
})
export class MyclassPage {

  selectedItem: any;
  icons: string[];
  items: Array<{classname: string, sectionname: string}>;
  myLoadingControl: any;
  loader: any;
  responseData: any;
  postData: any;
  schoolName: string;
  myClasses: string;

  constructor(public navCtrl: NavController, public navParams: NavParams, public loadingCtrl: LoadingController, public authservice: AuthServiceProvider, public toastCtrl: ToastController) {
    // If we navigated to this page, we will have an item available as a nav param
    this.selectedItem = navParams.get('item');
    this.loader
    this.myLoadingControl = loadingCtrl;
    this.schoolName = window.localStorage.getItem('schoolname');
    
    if (parseInt(window.localStorage.getItem('isadmin')) == 0)
      this.myClasses = "My classes";
    else
      this.myClasses = "List of classes";

    this.items = [];
    this.postData = {teacherid: window.localStorage.getItem('teacherid'), schoolid: window.localStorage.getItem('schoolid')};
    this.loadClasses();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MyclassPage');
  }

  loadClasses(){
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.loader.present().then(() => {

      let url = "";

      if (parseInt(window.localStorage.getItem('isadmin')) == 0)
        url = "allottedclasses";
      else
        url = "allottedclasses/all";

      this.authservice.postData(this.postData, url).then((result)=>{
  		this.responseData = result;
  		console.log(this.responseData);
  		if(this.responseData['response'] == 1){
        this.items = this.responseData['classinfo'];
        this.loader.dismiss();
  		}else{
        this.loader.dismiss();
  		}
  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismiss();
  	  });
    });
  }

  itemTapped(event, classid, sectionid) {
    // That's right, we're pushing to ourselves!
    this.navCtrl.push(AttendancePage, {
      classid: classid,
      sectionid: sectionid
    });
  }

}
