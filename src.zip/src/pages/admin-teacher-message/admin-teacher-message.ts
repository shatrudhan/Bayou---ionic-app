import { Component } from '@angular/core';
import { ViewController, ModalController, NavController, NavParams, LoadingController, ToastController, Platform, AlertController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { global } from '../../app/global';


@Component({
  selector: 'page-admin-teacher-message',
  templateUrl: 'admin-teacher-message.html',
})
export class AdminTeacherMessagePage {
  messageArray: Array<{ id: number, message: any, messageDate: any, isTeacherOrNot: string  }>;
  super_admin: string;
  admin: string;
  teacher: string;
  isAdmin: any;
  isTeacher: any;
  schoolid: string;

  loader: any;
  myLoadingControl: any;

  constructor(
              public navCtrl: NavController,
              public navParams: NavParams,
              public authservice: AuthServiceProvider,
              public loadingCtrl: LoadingController,
              public toastCtrl: ToastController,
              public platform: Platform,  
              public alertCtrl: AlertController,  
              public modalCtrl: ModalController,
              public viewCtrl: ViewController,                
  ) 
  {
    this.platform.ready().then(() => {      
      this.myLoadingControl = loadingCtrl;
      this.schoolid = localStorage.getItem('schoolid');

      this.isTeacher = localStorage.getItem('teacherid');
      this.isAdmin = localStorage.getItem('isadmin');
      // case-1 (for teacher)
      if(this.isTeacher != 0 && this.isAdmin == 0){
        this.teacher = 'yes'
      }else{
        this.teacher = 'no'
      }
      // case-2 (for admin)
      if(this.isTeacher == 0 && this.isAdmin != 0){
        this.admin = 'yes'
      }
      // case-3 (when a teacher also admin)
      if(this.isTeacher != 0 && this.isAdmin != 0){
        this.super_admin = 'yes'
      }
      this.getAllMessage();
      this.messageArray = [];
    });
  }

  ionViewDidLoad() 
  {
    console.log('ionViewDidLoad AdminTeacherMessagePage');
  }

  getAllMessage()
  {
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });
    
    this.loader.present().then(() => {
      this.authservice.postData({schoolid:this.schoolid}, 'getAllAdminTeacherMessage').then((result)=>{
        if(result['response'] == 1){
          this.messageArray = [];          
          for(let val of result['messages'])
          {
            this.messageArray.push({
              id: val['id'],
              message: val['message'],
              messageDate: val['MessageDate'], 
              isTeacherOrNot: this.teacher,               
            });
          }
          this.loader.dismiss();
        }else{
          let toast = this.toastCtrl.create({ message: 'No records found.', 'cssClass':'toastText', duration: 3000 });
          toast.present();
          this.loader.dismiss();
        }
    	},(err)=> {
        let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 3000 });
        toast.present();
        this.loader.dismiss();
    	});
    });
  }

  deleteMessage(messageid)
  {
    this.loader = this.myLoadingControl.create({
      content : "Deleting..."
    });

    this.loader.present().then(() => {
      let alert = this.alertCtrl.create({
        title: 'Confirmation !',
        message: 'Do you really want to delete this message?',
        buttons: [
          {
            text: 'Cancel',
            role: 'cancel',
            handler: () => {
              this.loader.dismiss();
            }
          },
          {
            text: 'Ok',
            handler: () => {
              this.authservice.postData({schoolid:this.schoolid,messageid:messageid}, 'deleteAdminTeacherMessage').then((result)=>{
                if(result['response'] == 1){
                  this.loader.dismiss();
                  this.getAllMessage();          
                }else{
                  let toast = this.toastCtrl.create({ message: 'Sorry! something went wrong.', 'cssClass':'toastText', duration: 3000 });
                  toast.present();
                  this.loader.dismiss();
                }
              },(err)=> {
                let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 3000 });
                toast.present();
                this.loader.dismiss();
              });
            }
          }
        ]
      });
      alert.present();
    });
  }

  adminMessageForm()
  {
    let modal = this.modalCtrl.create(messageFormModal, {'MessagePageObj': this});
    modal.present();   
  }

}


///// admin form modal opens from here ////////

@Component({
  selector: 'page-admin-teacher-message',
  template: `<ion-header>
              <ion-toolbar>
                <ion-title>
                  Teacher's message
                </ion-title>
                <ion-buttons start>
                  <button ion-button (click)="modalDismiss()">
                    <span ion-text color="primary" showWhen="ios">Cancel</span>
                    <ion-icon name="md-close" showWhen="android,windows"></ion-icon>
                  </button>
                </ion-buttons>
              </ion-toolbar>
            </ion-header>

            <ion-content padding>
                <ion-list>
                    <ion-item>
                      <ion-textarea placeholder="Enter a message ..." name="message" [(ngModel)]="mData.message"></ion-textarea>
                    </ion-item>
                </ion-list>
                <div style="padding-left: 15px;padding-right:0px;">
                  <button ion-button block type="button" (click)="SubmitMessage()">Submit</button>
                </div>
            </ion-content>
            `
})


export class messageFormModal {
  mData: { schoolid: string; message: string; };
  MessagePageObj: any;
  isAdmin: string;
  isTeacher: string;
  schoolid: string;

  loader: any;
  myLoadingControl: any;
  constructor(
              public navCtrl: NavController,
              public navParams: NavParams,
              public authservice: AuthServiceProvider,
              public loadingCtrl: LoadingController,
              public toastCtrl: ToastController,
              public platform: Platform,  
              public alertCtrl: AlertController,  
              public modalCtrl: ModalController,
              public viewCtrl: ViewController,                
  )
  {
    this.myLoadingControl = loadingCtrl;
    this.MessagePageObj = this.navParams.get('MessagePageObj');
    this.schoolid = localStorage.getItem('schoolid');
    this.isTeacher = localStorage.getItem('teacherid');
    this.isAdmin = localStorage.getItem('isadmin');
    this.mData = {schoolid:this.schoolid, message:''}
  }

  modalDismiss()
  {
    this.viewCtrl.dismiss();
  }

  SubmitMessage()
  {
    this.loader = this.myLoadingControl.create({
        content : "Please wait.."
    });
    this.loader.present().then(() => {
      if(this.mData.message == '' || this.mData.message == null || this.mData.message == 'undefined'){
        let toast = this.toastCtrl.create({ message: 'Please enter message.', 'cssClass':'toastText', duration: 3000 });
        toast.present();
        this.loader.dismiss();
      }else{
        this.authservice.postData(this.mData,'addAdminTeacherMessage').then((result)=>{
          if(result['response'] == 1){
            let toast = this.toastCtrl.create({ message: 'Message submitted successfully.', 'cssClass':'toastText', duration: 3000 });
            toast.present();
            this.MessagePageObj.getAllMessage();
            this.modalDismiss();
            this.loader.dismiss();                
          }else{
            this.loader.dismiss();                
          }
        },(err)=> {
          alert('failled : '+err);
          this.loader.dismiss();    
        });
      }
      
    });
  }

}
