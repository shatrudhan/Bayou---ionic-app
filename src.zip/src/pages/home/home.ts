import { SchoolbusesPage } from './../schoolbuses/schoolbuses';
import { SocialSharing } from '@ionic-native/social-sharing';
import { PopoverController } from 'ionic-angular/components/popover/popover-controller';
import { PopoverPage } from './../popover/popover';
import { SchoolpanelPage } from './../schoolpanel/schoolpanel';
import { FirebasedbProvider } from './../../providers/firebasedb/firebasedb';
import { AttendanceviewPage } from './../attendanceview/attendanceview';
import { Component } from '@angular/core';
import { NavController, ToastController, ModalController } from 'ionic-angular';

import { ListPage } from "../list/list";
import { AttendancePage } from "../attendance/attendance";
import { BusattendancePage } from "../busattendance/busattendance";
import { MyclassPage } from "../myclass/myclass";
import { MydiaryPage } from "../mydiary/mydiary";
import { QueryPage } from "../query/query";
import { FeeshomePage } from "../feeshome/feeshome";
import { SigninPage } from "../signin/signin";
import { TeacherClassSectionPage } from "../teacher-class-section/teacher-class-section";
import { SchoolteachersPage } from '../schoolteachers/schoolteachers';
import { NoticeBoardTeacherPage } from "../notice-board-teacher/notice-board-teacher";
import { HandBookTeacherPage } from "../hand-book-teacher/hand-book-teacher";
import { AdminTeacherMessagePage } from '../admin-teacher-message/admin-teacher-message';
import { AuthServiceProvider as p_AuthServiceProvider } from '../../providers/parent/auth-service/auth-service';
import { PasswordPage } from '../password/password';


@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  schoolAdmin: any;
  socialSharing: any;

  super_admin: string;
  admin: string;
  teacher: string;
  isAdmin: any;
  isTeacher: any;

  constructor(
            public navCtrl: NavController, 
            public toastCtrl: ToastController, 
            public fbProvider: FirebasedbProvider, 
            public popoverCtrl: PopoverController, 
            public socialShare: SocialSharing,
            public modalCtrl: ModalController,
            public p_authservice : p_AuthServiceProvider,
  ) 
  {
    /*let toast = this.toastCtrl.create({
        message: localStorage.getItem('useremail'),
        duration: 3000
      });
    toast.present();*/

    // alert('teacher : '+localStorage.getItem('teacherid')+' , admin :'+localStorage.getItem('isadmin'));

    this.isTeacher = localStorage.getItem('teacherid');
      this.isAdmin = localStorage.getItem('isadmin');
      // case-1 (for teacher)
      if(this.isTeacher != 0 && this.isAdmin == 0){
        this.teacher = 'yes'
      }else{
        this.teacher = 'no'
      }
      // case-2 (for admin)
      if(this.isTeacher == 0 && this.isAdmin != 0){
        this.admin = 'yes'
      }else{
        this.admin = 'no'
      }
      // case-3 (when a teacher also admin)
      if(this.isTeacher != 0 && this.isAdmin != 0){
        this.super_admin = 'yes'
      }else{
        this.super_admin = 'no'
      }

    this.socialSharing = socialShare;
    this.schoolAdmin = window.localStorage.getItem('isadmin');
    if (window.localStorage.getItem('isdriver') != '0')
      fbProvider.startTracking();
  }

  openPage(p)
  {
    if (p == 1)
    {
      if (this.schoolAdmin == 0)
        this.navCtrl.push(ListPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
      else
        this.navCtrl.push(SchoolteachersPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    }
    else if (p == 2)
      this.navCtrl.push(MyclassPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (p == 3)
    {
      if (this.schoolAdmin == 0)
        this.navCtrl.push(BusattendancePage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
      else 
        this.navCtrl.push(SchoolbusesPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    }
    else if (p == 4)
      this.navCtrl.push(MydiaryPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (p == 5)
      this.navCtrl.push(QueryPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (p == 6)
      this.navCtrl.push(FeeshomePage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (p == 15)
      this.navCtrl.push(TeacherClassSectionPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (p == 10)
    {
      window.localStorage.removeItem('useremail');
      window.localStorage.removeItem('isdriver');
      window.localStorage.clear();
      window.localStorage.setItem('useremail', '');
      this.navCtrl.setRoot(SigninPage);      
    }
    else if (p == 16)
      this.navCtrl.push(SchoolpanelPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (p == 17)
      this.navCtrl.push(NoticeBoardTeacherPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (p == 18)
      this.navCtrl.push(HandBookTeacherPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (p == 19)
      this.navCtrl.push(AdminTeacherMessagePage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});
    else if (p == 20)
      this.password();
    else if (p == 21)
      this.logout();
  }

  shareSchool()
  {
    let message = "Please visit our school profile link " + window.localStorage.getItem('schoolurl') + " and give your valuable review to help parents to know about the school.\r\n\r\n" + window.localStorage.getItem('schoolname');
    this.socialSharing.share(message);
  }

  MorePopOver(myEvent) 
  {
    let popover = this.popoverCtrl.create(PopoverPage);
    popover.present({
      ev: myEvent
    });
  }

  password()
  {
    let modal = this.modalCtrl.create(PasswordPage);
    modal.present();
  }

  logout()
  {
    this.p_authservice.postData({'useremail':localStorage.getItem('useremail'),'usertype':'teacher'}, 'ParentDeviceTokenDestroy').then((result)=>{
      if(result['response'] == 1){
        console.log('token destroy');
      }else{
        console.log('token destroy failed');
      }
    },(err)=> {
      alert('failled '+err);
    });
    localStorage.clear();
    this.navCtrl.setRoot(SigninPage);
  }



}
