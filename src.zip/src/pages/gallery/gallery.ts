import { Component } from '@angular/core';
import { AlertController, ModalController, NavController, NavParams, LoadingController, ToastController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { FileChooser } from '@ionic-native/file-chooser';
import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer';
import { global } from '../../app/global';
import { FilePath } from '@ionic-native/file-path';
import { File } from '@ionic-native/file';
import { ImagePicker } from '@ionic-native/image-picker';

import { GalleryModal } from 'ionic-gallery-modal';
import { setTimeout } from 'timers';


@Component({
  selector: 'page-gallery',
  templateUrl: 'gallery.html',
})
export class GalleryPage {
  // loaded: boolean;
  GalleryPhotoArray: Array<{ url: string}>;
  
  SelectAllBtn: boolean;
  DeselectAllBtn: boolean;
  customLoader: LoadingController;
  loading1: any;
  disabled: boolean;
  photoid: any[];
  DeletePhotoArray: any;
  checkShowOrHide: boolean;
  galleries: string;
  backoffice_url: any;
  loading2: any;  
  videoUploadBtn: boolean;
  PhotoUploadBtn: boolean;
  schoolid: string;
  schoolname: any;
  images: any;
  constructor(
      public navCtrl: NavController, 
      public navParams: NavParams, 
      public authservice: AuthServiceProvider, 
      public loadingCtrl: LoadingController, 
      public toastCtrl: ToastController,
      public fileChooser: FileChooser,
      public fileTransfer: FileTransfer,
      public filePath: FilePath,   
      public file: File,
      public modalCtrl: ModalController,
      public alertCtrl: AlertController,
      public imagePicker: ImagePicker,
  )
  {
    this.GalleryPhotoArray = [];  
    this.customLoader = loadingCtrl;
    this.schoolname = window.localStorage.getItem('schoolname');
    this.schoolid = window.localStorage.getItem('schoolid');
    this.PhotoGallerySegmentClick();
    // set up default photo gallery segment
    this.galleries = "pgs";
    this.checkShowOrHide = false;
    this.DeletePhotoArray= [];
    this.SelectAllBtn = true;
  }

  ionViewDidLoad(){
    console.log('ionViewDidLoad GalleryPage');
  }

  PhotoGallerySegmentClick()
  {
    this.PhotoUploadBtn = true;
    this.videoUploadBtn = false;    
    this.authservice.postData({'schoolid': window.localStorage.getItem('schoolid')}, 'GetSchoolAllPhotoGalleries').then((result)=>{
      if(result['response'] == 1){
        this.backoffice_url = result['backoffice_url'];
        this.images = result['photos'];
        this.checkShowOrHide = false; 
        for(let val of result['photos'])
        {
          this.GalleryPhotoArray.push({
            url: this.backoffice_url+'/'+val['PhotoPath'],
          });
        }
      }
    },(err)=> {
        let toast = this.toastCtrl.create({ message: err, 'cssClass':'toastText', duration: 3000 });
        toast.present();
     });
  }

  VideoGallerySegmentClick()
  {
    this.videoUploadBtn = true;
    this.PhotoUploadBtn = false;
    this.checkShowOrHide = false;
    this.DeletePhotoArray.push({
      'photoid':'',
      'schoolid':''
    });

  }

  public presentToast(text) 
  {
    let toast = this.toastCtrl.create({
      message: text,
      duration: 3000,
      position: 'bottom'
    });
    toast.present();
  }

  public createFileName(filename,fextension) 
  {
    var d = new Date(),
    n = d.getTime(),
    newFileName =  n + "."+fextension;
    return newFileName;
  }

  UploadPhotoVideo()
  {
    // PHOTO UPLOAD CONDITION
    if(this.PhotoUploadBtn == true && this.videoUploadBtn == false){

      var optionss = {
        maximumImagesCount:5,
      };

      this.loading1 = this.customLoader.create({content: 'Uploading...',});
      this.loading1.present().then(() => {
        this.imagePicker.getPictures(optionss).then((results) => {

          if(results == ''){
            if(this.loading1){
              this.loading1.dismiss();
              this.loading1 = null;
            }
          }else{
            for (var i = 0; i < results.length; i++) 
            {
                var lastIteration = results.length - 1;
                const uri = results[i];
                this.filePath.resolveNativePath(uri).then(path => {
                  
                  // Destination URL
                  let url = global.apiUrl+'PhotoGalleryUpload';
                  // File name only
                  var filename = path.substring(path.lastIndexOf('/') + 1, path.length );
                  // file extension
                  var fileExtension = path.substring(path.lastIndexOf('.') + 1, path.length );
                  var newFileName = this.createFileName(filename,fileExtension);
                  // File for Upload path
                  var targetPath = path;      
                  var extenCaps = fileExtension.toUpperCase();
                  var options: FileUploadOptions  = {
                    fileKey: "file",
                    fileName: newFileName,
                    chunkedMode: false,
                    mimeType: "multipart/form-data",
                    params : {'fileName': newFileName, 'schoolid': window.localStorage.getItem('schoolid')}
                  };
                  const fileTransfer: FileTransferObject = this.fileTransfer.create();
                  // Use the FileTransfer to upload the image
                  fileTransfer.upload(targetPath, url, options ).then((data) => {
                    this.PhotoGallerySegmentClick();
                    if(i = lastIteration){
                      if(this.loading1){
                        this.loading1.dismiss();
                        this.loading1 = null;
                      }
                    }else{
                      if(this.loading1){
                        this.loading1.dismiss();
                        this.loading1 = null;
                      }
                    }
                  }, err => {
                    if(i = lastIteration){
                      if(this.loading1){
                        this.loading1.dismiss();
                        this.loading1 = null;
                      }
                    }else{
                      if(this.loading1){
                        this.loading1.dismiss();
                        this.loading1 = null;
                      }
                    }
                    this.presentToast('File uploading failled !');
                  });    
                });
            }
        }
        }, (err) => {
          alert('error : '+err);
        });
      });      
    }

    // VIDEO UPLOAD CONDITION    
    if(this.videoUploadBtn == true && this.PhotoUploadBtn == false){
      //this.navCtrl.push(YoutubeVideoPage, {}, {animate:true,animation:'transition',duration:600,direction:'forward'});      
    }
  }

  longPress(index,photoid)
  {
    this.images[index].delete_chk = true;
    this.checkShowOrHide = true;
  }
  
  DeletePhotoVideo()
  {
    // delete photo gallery
    if(this.PhotoUploadBtn == true && this.videoUploadBtn == false){
      this.photoid = [];
      for (var index = 0; index < this.images.length; index++) {
        var element = this.images[index];
          if(element['delete_chk'] == true){
            this.photoid.push({
              'photoid': element['PhotoId'],
              'photopath': element['PhotoPath'] 
            });
          }
      }
      if(this.photoid.length != 0){
          let alert = this.alertCtrl.create({
            title: 'Confirmation !',
            message: 'Are you sure want to delete selected photo(s) ?',
            buttons: [
              {
                text: 'Cancel',
                role: 'cancel',
                handler: () => {
                }
              },
              {
                text: 'Delete',
                handler: () => {
                  this.loading2 = this.customLoader.create({content: 'Deleting...',});
                  //this.loading2.present();
                  this.loading2.present().then(() => {        
                    this.authservice.postData(this.photoid, 'deletePhotoGalleries').then((result)=>{
                      if(result['response']){
                        this.loading2.dismissAll();
                        this.presentToast('Photo deleted successfully.');
                        this.PhotoGallerySegmentClick();
                      }else{
                        this.loading2.dismissAll();
                        this.presentToast('Sorry! something went wrong.');
                      }
                    },(err)=> {
                        this.loading2.dismissAll();                    
                        this.presentToast(err);
                    });
                  });
                }
              }
            ]
          });
          alert.present();
      }else{
        this.presentToast('Please select photo to delete !');
      }

    }
    
    // delete video gallery
    if(this.PhotoUploadBtn == false && this.videoUploadBtn == true){

    }
  }

  selectAllPhoto()
  {
    // select all photo's to delete
    for (var index = 0; index < this.images.length; index++){
      var element = this.images[index];
      this.images[index].delete_chk = true;
    }
    this.DeselectAllBtn = true;
    this.SelectAllBtn = false;
  }

  deselectAllPhoto()
  {
    // deselect all photo's
    for (var index = 0; index < this.images.length; index++){
      var element = this.images[index];
      this.images[index].delete_chk = false;
    }
    this.SelectAllBtn = true;
    this.DeselectAllBtn = false;
  }

  ZoomWithSlide(i)
  {
    this.loading1 = this.customLoader.create({content: 'loading...',});
    this.loading1.present().then(() => {
      let modal = this.modalCtrl.create(GalleryModal, {
        photos: this.GalleryPhotoArray,
        initialSlide: i
      });
      this.loading1.dismiss();
      modal.present();
    });
  
  }






}
