import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, ModalController, LoadingController, ToastController, Content } from 'ionic-angular';
import { QueryreplyPage } from "../queryreply/queryreply";
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
/**
 * Generated class for the QuerydetailPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-querydetail',
  templateUrl: 'querydetail.html',
})
export class QuerydetailPage {

  @ViewChild(Content) content: Content;

  selectedItem: any;
  icons: string[];
  items: Array<{classname: string, sectionname: string}>;
  myLoadingControl: any;
  loader: any;
  responseData: any;
  postData: any;


  constructor(public navCtrl: NavController, public navParams: NavParams, public modalCtrl: ModalController, public loadingCtrl: LoadingController, public authservice: AuthServiceProvider, public toastCtrl: ToastController) {
    this.loader
    this.myLoadingControl = loadingCtrl;
    
    this.items = [];
    this.postData = {teacherid: window.localStorage.getItem('useremail'), schoolid: window.localStorage.getItem('schoolid'), messageid: navParams.get('messageid')};
    this.loadMessages();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad QuerydetailPage');
  }

  ionViewDidEnter(){
    //setTimeout(()=>{this.content.scrollToBottom();},100);
  }

  openModel(){
    let modal = this.modalCtrl.create(QueryreplyPage, {messageid: this.postData.messageid, myObj: this});
    modal.present();
  }

  loadMessages(){
    this.loader = this.myLoadingControl.create({
      content : "Please wait.."
    });

    this.loader.onDidDismiss(() => {
      //setTimeout(()=>{this.content.scrollToBottom();},100);
      this.content.scrollToBottom();
    })

    this.loader.present().then(() => {
      this.authservice.postData(this.postData, 'parents/getmessages').then((result)=>{
  		this.responseData = result;
  		console.log(this.responseData);
  		if(this.responseData['response'] == 1){
        this.items = this.responseData['messages'];
        this.loader.dismiss();
        //let dimensions = this.content.getContentDimensions();
        //this.content.scrollTo(0, dimensions.scrollHeight+220,150);
        //this.content.scrollToBottom();
  		}else{
        this.loader.dismiss();
  		}
  	  },(err)=> {
  		    //alert('failled '+err);
          let toast = this.toastCtrl.create({
    				  message: err,
    				  duration: 3000
    				});
    			toast.present();
          this.loader.dismiss();
  	  });
    });
  }

}
